PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE topic(topic_name VARCHAR(64), questionnarie VARCHAR(8), section VARCHAR(64), `Variable` VARCHAR(64), `Description` TEXT, `Values` TEXT);
INSERT INTO "topic" VALUES('Pre-selected variables','Q1','BACKGROUND & ENVIRONMENT','age_at_baseline','Q2 Age at Q1 (fillx -birthx)','22-104
-99=Missing');
INSERT INTO "topic" VALUES('Pre-selected variables','Q1','BACKGROUND & ENVIRONMENT','adopted','Q3 Were you adopted?','A=No
B=Yes
C=Don''t Know
-99=Missing');
INSERT INTO "topic" VALUES('Pre-selected variables','Q1','BACKGROUND & ENVIRONMENT','twin','Q4 Are you a twin?','A=California
B=Other US or Canada
C=Mexico, South America, Central America or the Carribean
D=Asia or Pacific Islands
E=Eastern Europe
F=Western Europe
G=Middle East or Israel
H=Africa
I=Other
-88=Unable to assign value
-99=Missing');
INSERT INTO "topic" VALUES('Pre-selected variables','Q1','BACKGROUND & ENVIRONMENT','birthplace','Q5 Where were you born?','A=California
B=Other US or Canada
C=Mexico, South America, Central America or the Carribean
D=Asia or Pacific Islands
E=Eastern Europe
F=Western Europe
G=Middle East or Israel
H=Africa
I=Other
-88=Unable to assign value
-99=Missing');
INSERT INTO "topic" VALUES('Pre-selected variables','Q1','BACKGROUND & ENVIRONMENT','birthplace_mom','Q5 Where was your father born?','A=California
B=Other US or Canada
C=Mexico, South America, Central America or the Carribean
D=Asia or Pacific Islands
E=Eastern Europe
F=Western Europe
G=Middle East or Israel
H=Africa
I=Other
-88=Unable to assign value
-99=Missing');
INSERT INTO "topic" VALUES('Pre-selected variables','Q1','BACKGROUND & ENVIRONMENT','birthplace_dad','Q5 Where was your mother born?','A=Cal, B=othUS/Can, C=Mx/S,C Am/Car, D=As/Pac, E=Eeur, F=Weur, G=MdEst/Isr, H=Afr, I=Oth, Z=Problem');
INSERT INTO "topic" VALUES('Pre-selected variables','Q1','BACKGROUND & ENVIRONMENT','participant_race','Q6 RECONSTITUTED - Teachers Race','0-6
0=None reported
1=White
2=Black
3=Hispanic
4=Native American
5=Asian or Pacific Islander
6=Other/Mixed');
INSERT INTO "topic" VALUES('Pre-selected variables','Q1','BACKGROUND & ENVIRONMENT','nih_ethnic_cat','Q6 For grant inclusion enrollment report: Part A-Ethnic Category','1=Hispanic
2=Not Hispanic
3=Unknown
-99=Missing');
INSERT INTO "topic" VALUES('Pre-selected variables','Q1','BACKGROUND & ENVIRONMENT','age_mom','Q7 How old was mom when you were born?','A=<20
B=20-24
C=25-29
D=30-34
E=35-39
F=40-44
G=45+
H=Don''t Know
-88=Unable to assign value
-99=Missing');
INSERT INTO "topic" VALUES('Pre-selected variables','Q1','BACKGROUND & ENVIRONMENT','age_dad','Q7 How old was dad when you were born?','A=<20
B=20-24
C=25-29
D=30-34
E=35-39
F=40-44
G=45+
H=Don''t Know
-88=Unable to assign value
-99=Missing');
INSERT INTO "topic" VALUES('Pre-selected variables','Q1','REPRODUCTIVE HISTORY','FMP','Q21 AGE AT MENARCHE','1-10, 1=NoFMP, 2=<10, 3=10, 4=11, 5=12, 6=13, 7=14, 8=15, 9=16, 10=17+, .A=FP_Blnk, .B=P4B_P5A, .C=Q Blnk, .D=M_Ans, .E=Unk');
INSERT INTO "topic" VALUES('Pre-selected variables','Q1','REPRODUCTIVE HISTORY','ROCYN15','Q24-26 EVER USED OC','0-4, 0=NO,<=1915, 1=Y_Curr, 2=Y_Pst, 4=Y_Cur?_Pst?, .A=FP_Blnk, .B=PG_Blnk, .C=NVR_Q2426B, .U=Unk_Rev');
INSERT INTO "topic" VALUES('Pre-selected variables','Q1','REPRODUCTIVE HISTORY','RTOCYRS15','Q24-26 TOTAL YRS USED OC','0-8, 0=No OC, 1=<1, 2=1-2, 3=3-4, 4=5-9, 5=10-14, 6=15-19, 7=20-24, 8=25+, .A=FP_Blnk, .B=PG_Blnk, .C=NVR_Q2426B, .H=H:OC15Y_NoYrs,  .U=Unk_Rev');
INSERT INTO "topic" VALUES('Pre-selected variables','Q1','REPRODUCTIVE HISTORY','EVPRG','Q28 EVER PREGNANT','0-1, 0=Nv Prg, 1=Evr Prg, .A=FP_Blnk, .B=P4BP5ANoP, .C=QB_P5Blnk, .D=QB_P5ANoP, .Z=GrdPrb');
INSERT INTO "topic" VALUES('Pre-selected variables','Q1','REPRODUCTIVE HISTORY','AGEFFTP','Q27-28 AGE 1ST FULL TERM PREG(LB,SB)','14-46, .A=FP_Blnk, .B=P4BP5ANoP, .C=QB_P5Blnk, .D=QB_P5ANoP, .P=NoPrgs, .Q=CP1st, .R=No FTP, .S=HCPrgs, .Z=GrdPrb');
INSERT INTO "topic" VALUES('Pre-selected variables','Q1','REPRODUCTIVE HISTORY','TOTPRG','Q28 Total Number of Pregnancies','0-15, .A=FP_Blnk, .B=P4BP5ANoP, .C=QB_P5Blnk, .D=QB_P5ANoP, .L=TPrb_N3, .M=TPrb_N3, .N=TPrb_N3, .O=TPrb_N3, .P=NoPrgs, .R=TMS_N22, Z=GrdPrb');
INSERT INTO "topic" VALUES('Pre-selected variables','Q1','REPRODUCTIVE HISTORY','RMENOVARC','Q34-36,41,56 MENOPAUSAL STATUS INCLUDE TYPE OF MENOPAUSE (REVISED 6-2008)','1-11, 1=Pre, 2=Peri_NTL, 3=Peri_M,C,R, 4=Peri_Oth, 5=Post_NTL, 6=Post_BO, 7=Post_M,C,R, 8=Post_Oth, 9=Post_Hyst_56+, 10=Pst56+_Hys<56,  11=Post_Unk_Type, .G=Hyst<56, .H=Unk_Meno stat due to HT, .U=Unk
');
INSERT INTO "topic" VALUES('Pre-selected variables','Q1','HEALTH HISTORY','HEIGHTX','Q65 RECONSTITUTED - Height today','45-81, .D=Cant fix, .Z=Problem');
INSERT INTO "topic" VALUES('Pre-selected variables','Q1','HEALTH HISTORY','WEIGHTX','Q65 RECONSTITUTED - Weight today','67-450, .D=Cant fix, .Z=Problem');
INSERT INTO "topic" VALUES('Pre-selected variables','Q1','HEALTH HISTORY','bmi','Q65 BODY MASS INDEX (KG/M**2)','16.0-75.0');
INSERT INTO "topic" VALUES('Pre-selected variables','Q1','PERSONAL & FAMILY MEDICAL HISTORY','DIABSELF','Q67 Have you ever had Diabetes?','A=Yes');
INSERT INTO "topic" VALUES('Pre-selected variables','Q1','PERSONAL & FAMILY MEDICAL HISTORY','HIPFSELF','Q67 Have you ever had Hip Fracture?','A=Yes');
INSERT INTO "topic" VALUES('Pre-selected variables','Q1','PHYSICAL ACTIVITY','SPMP3YR','Q68, 69 S+M HRS/WK OVR YR PST 3YRS','0-24,  .A=FP_Blnk, .B=LSDBlnk, .M=S&M_Miss, .Y=YNG');
INSERT INTO "topic" VALUES('Pre-selected variables','Q1','PHYSICAL ACTIVITY','SPMHRLT','Q68, 69 S+M HRS/WK OVR YR FOR LIFETIME','0-24,  .A=FP_Blnk, .B=LSDBlnk, .M=S&M_Miss, .Y=YNG');
INSERT INTO "topic" VALUES('Pre-selected variables','Q1','DIET','vitgrp','Q71-72 multivit and single vit use variable','1-4, 1=Non-user, 2=Curr, Sing vit only, 3=Curr, Multvit only, 4=Curr, Both mult & sing vit use');
INSERT INTO "topic" VALUES('Pre-selected variables','Q1','ALCOHOL & TOBACCO USE','ALCYRC','Q83 CAT OF ALCOHOL G/D PAST YR FOR BC ANALYSIS','0-2, 0=None, 1=<20 g/d, 2=≥20 g/d');
INSERT INTO "topic" VALUES('Pre-selected variables','Q1','ALCOHOL & TOBACCO USE','SMKEXP','Q84, 87, 88 SMOKING EXPOSURE CATEGORIES','1-4, 1=NoExp, 2=Passive, 3=Former, 4=Current');
INSERT INTO "topic" VALUES('Pre-selected variables','Q1','ALCOHOL & TOBACCO USE','TYRSSMK','Q2, 84, 85 TOTAL YEARS SMOKED','0.5-75 ');
INSERT INTO "topic" VALUES('Pre-selected variables','Q1','ALCOHOL & TOBACCO USE','AVGCIGDY','Q84-86 AVG NUMBER OF CIGARETTES SMOKED PER DAY','0.5-40');
INSERT INTO "topic" VALUES('Pre-selected variables','Q1','ALCOHOL & TOBACCO USE','TPACKYRS','Q2, 84-86 TOTAL PACK YEARS OF SMOKING','0.0125-140');
INSERT INTO "topic" VALUES('Participant characteristics','Q1','BACKGROUND & ENVIRONMENT','age_at_baseline','Q2 Age at Q1 (fillx -birthx)','22-104
-99=Missing');
INSERT INTO "topic" VALUES('Participant characteristics','Q1','BACKGROUND & ENVIRONMENT','adopted','Q3 Were you adopted?','A=No
B=Yes
C=Don''t Know
-99=Missing');
INSERT INTO "topic" VALUES('Participant characteristics','Q1','BACKGROUND & ENVIRONMENT','twin','Q4 Are you a twin?','A=California
B=Other US or Canada
C=Mexico, South America, Central America or the Carribean
D=Asia or Pacific Islands
E=Eastern Europe
F=Western Europe
G=Middle East or Israel
H=Africa
I=Other
-88=Unable to assign value
-99=Missing');
INSERT INTO "topic" VALUES('Participant characteristics','Q1','BACKGROUND & ENVIRONMENT','birthplace','Q5 Where were you born?','A=California
B=Other US or Canada
C=Mexico, South America, Central America or the Carribean
D=Asia or Pacific Islands
E=Eastern Europe
F=Western Europe
G=Middle East or Israel
H=Africa
I=Other
-88=Unable to assign value
-99=Missing');
INSERT INTO "topic" VALUES('Participant characteristics','Q1','BACKGROUND & ENVIRONMENT','birthplace_mom','Q5 Where was your father born?','A=California
B=Other US or Canada
C=Mexico, South America, Central America or the Carribean
D=Asia or Pacific Islands
E=Eastern Europe
F=Western Europe
G=Middle East or Israel
H=Africa
I=Other
-88=Unable to assign value
-99=Missing');
INSERT INTO "topic" VALUES('Participant characteristics','Q1','BACKGROUND & ENVIRONMENT','birthplace_dad','Q5 Where was your mother born?','A=Cal, B=othUS/Can, C=Mx/S,C Am/Car, D=As/Pac, E=Eeur, F=Weur, G=MdEst/Isr, H=Afr, I=Oth, Z=Problem');
INSERT INTO "topic" VALUES('Participant characteristics','Q1','BACKGROUND & ENVIRONMENT','participant_race','Q6 RECONSTITUTED - Teachers Race','0-6
0=None reported
1=White
2=Black
3=Hispanic
4=Native American
5=Asian or Pacific Islander
6=Other/Mixed');
INSERT INTO "topic" VALUES('Participant characteristics','Q1','BACKGROUND & ENVIRONMENT','father_race','Q6 RECONSTITUTED - Fathers race','0-6
0=None reported
1=White
2=Black
3=Hispanic
4=Native American
5=Asian or Pacific Islander
6=Other/Mixed');
INSERT INTO "topic" VALUES('Participant characteristics','Q1','BACKGROUND & ENVIRONMENT','mother_race','Q6 RECONSTITUTED - Mothers race','0-6
0=None reported
1=White
2=Black
3=Hispanic
4=Native American
5=Asian or Pacific Islander
6=Other/Mixed');
INSERT INTO "topic" VALUES('Participant characteristics','Q1','BACKGROUND & ENVIRONMENT','nih_ethnic_cat','Q6 For grant inclusion enrollment report: Part A-Ethnic Category','1=Hispanic
2=Not Hispanic
3=Unknown
-99=Missing');
INSERT INTO "topic" VALUES('Participant characteristics','Q1','BACKGROUND & ENVIRONMENT','nih_race_cat','Q6 For grant inclusion enrollment report: Part A-Racial Category','1=American Indian/Alaska Native
2=Asia
3=Native Hawaiian/Pacific Islander
4=Black
5=White
6=2+ Races
7=Unknown
-99=Missing');
INSERT INTO "topic" VALUES('Participant characteristics','Q1','BACKGROUND & ENVIRONMENT','nih_hispanic_enrollment','Q6 For grant inclusion enrollment report: Part B-Hispanic Enrollment','White
-99=Missing');
INSERT INTO "topic" VALUES('Participant characteristics','Q1','BACKGROUND & ENVIRONMENT','age_mom','Q7 How old was mom when you were born?','A=<20
B=20-24
C=25-29
D=30-34
E=35-39
F=40-44
G=45+
H=Don''t Know
-88=Unable to assign value
-99=Missing');
INSERT INTO "topic" VALUES('Participant characteristics','Q1','BACKGROUND & ENVIRONMENT','age_dad','Q7 How old was dad when you were born?','A=<20
B=20-24
C=25-29
D=30-34
E=35-39
F=40-44
G=45+
H=Don''t Know
-88=Unable to assign value
-99=Missing');
INSERT INTO "topic" VALUES('Participant characteristics','Q1','BACKGROUND & ENVIRONMENT','older_bros','Q8 # of brothers born before you?','A=0
B=1
C=2
D=3
E=4
F=5+
-88=Unable to assign value
-99=Missing');
INSERT INTO "topic" VALUES('Participant characteristics','Q1','BACKGROUND & ENVIRONMENT','older_sis','Q8 # of sisters born before you?','A=0
B=1
C=2
D=3
E=4
F=5+
-88=Unable to assign value
-99=Missing');
INSERT INTO "topic" VALUES('Participant characteristics','Q1','BACKGROUND & ENVIRONMENT','younger_bros','Q8 # of brothers born after you?','A=0
B=1
C=2
D=3
E=4
F=5+
-88=Unable to assign value
-99=Missing');
INSERT INTO "topic" VALUES('Participant characteristics','Q1','BACKGROUND & ENVIRONMENT','younger_sis','Q8 # of sisters born after you?','A=0
B=1
C=2
D=3
E=4
F=5+
-88=Unable to assign value
-99=Missing');
INSERT INTO "topic" VALUES('Participant characteristics','Q3','STRESS AND SOCIAL SUPPORT','q3_marital_status','Q8 Current marital status','A=Married/living with partner
B=Divorced
C=Separated
D=Widowed
E=Never married
-88=Unable to assign value
-99=Missing');
INSERT INTO "topic" VALUES('Participant characteristics','Q4','GENERAL','q4_ppl_support_house_income','Q52 How many people, including yourself, are supported by this income? ','A=1
B=2
C=3
D=4
E=5
F=6
G=7+
-88=Unable to assign value
-99=Missing');
INSERT INTO "topic" VALUES('Participant characteristics','Q4','GENERAL','q4_minor_support_house_inc','Q52 How many people under the age of 18 are supported by this income? ','A=None
B=1
C=2
D=3
E=4
F=5
G=6
H=7+
-88=Unable to assign value
-99=Missing');
INSERT INTO "topic" VALUES('Participant characteristics','Q4','GENERAL','q4_senior_support_house_inc','Q52 How many people over the age of 64 are supported by this income? ','A=None
B=1
C=2
D=3
E=4
F=5
G=6
H=7+
-88=Unable to assign value
-99=Missing');
INSERT INTO "topic" VALUES('Participant characteristics','Q4','GENERAL','medicare','Q47 GENERATED VARIABLE FOR Medicare health insurance?','Y=Yes
N=No
YN=Both Yes/No
-88=Unable to assign value
-99=Missing');
INSERT INTO "topic" VALUES('Participant characteristics','Q4','GENERAL','health_insur_combo','Q47 GENERATED VARIABLE FOR HEALTH INSURANCE ANSWER COMBINATIONS','A=Medicare
B=Medical/Medicaid
C=HMO/IPA plan/managed care
D=Private insurance
E=Champus/military/VA
F=Other
N=No insurance
-88=Unable to assign value
-99=Missing
Answers are combinations of A to F, for example. AB=Medicare & Medical/Medicaid ');
INSERT INTO "topic" VALUES('Participant characteristics','Q4','GENERAL','retired','Q48 GENERATED VARIABLE FOR Are you retired?','Y=Yes
N=No
YN=Both Yes/No
-88=Unable to assign value
-99=Missing');
INSERT INTO "topic" VALUES('Participant characteristics','Q4','GENERAL','retired_spouse','Q49 GENERATED VARIABLE FOR Is your spouse/partner retired?','A=No
B=Yes
Ab=Both Yes/No
C=Not Applicable
-88=Unable to assign value
-99=Missing');
INSERT INTO "topic" VALUES('Participant characteristics','Q4','GENERAL','education','Q50 GENERATED VARIABLE FOR Highest Education - Self','A=PhD/EdD
B= MD/DDS/DVD/LLB/JD
C=Masters Degree
D=Bachelors Degree
E=AA Degree/Some College
F=Technical/High School Diploma
G=Less than High School Diploma
U=Unknown/Not Applicable
-99=Missing');
INSERT INTO "topic" VALUES('Participant characteristics','Q4','GENERAL','education_combo','Q50 GENERATED VARIABLE FOR Advanced Degree Combo Education - Self','A=PhD/EdD
B= MD/DDS/DVD/LLB/JD
C=Masters Degree
AB=PhD/MD
AC=PhD/Masters
ABC=Phd/MD/Masters
BC=MD/Masters
D=Bachelors Degree or less
U=Unknown/Not Applicable
-99=Missing');
INSERT INTO "topic" VALUES('Participant characteristics','Q4','GENERAL','edu_spouse','Q50 GENERATED VARIABLE FOR Highest Education - Spouse/Partner','A=PhD/EdD
B= MD/DDS/DVD/LLB/JD
C=Masters Degree
D=Bachelors Degree
E=AA Degree/Some College
F=Technical/High School Diploma
G=Less than High School Diploma
U=Unknown/Not Applicable
-99=Missing');
INSERT INTO "topic" VALUES('Participant characteristics','Q4','GENERAL','edu_spouse_combo','Q50 GENERATED VARIABLE FOR Advanced Degree Combo Education - Spouse/Partner','A=PhD/EdD
B= MD/DDS/DVD/LLB/JD
C=Masters Degree
AB=PhD/MD
AC=PhD/Masters
ABC=Phd/MD/Masters
BC=MD/Masters
D=Bachelors Degree or less
U=Unknown/Not Applicable
-99=Missing');
INSERT INTO "topic" VALUES('Participant characteristics','Q4','GENERAL','edu_mother','Q50 GENERATED VARIABLE FOR Highest Education - Mother','A=PhD/EdD
B= MD/DDS/DVD/LLB/JD
C=Masters Degree
D=Bachelors Degree
E=AA Degree/Some College
F=Technical/High School Diploma
G=Less than High School Diploma
U=Unknown/Not Applicable
-99=Missing');
INSERT INTO "topic" VALUES('Participant characteristics','Q4','GENERAL','edu_mother_combo','Q50 GENERATED VARIABLE FOR Advanced Degree Combo Education - Mother','A=PhD/EdD
B= MD/DDS/DVD/LLB/JD
C=Masters Degree
AB=PhD/MD
AC=PhD/Masters
ABC=Phd/MD/Masters
BC=MD/Masters
D=Bachelors Degree or less
U=Unknown/Not Applicable
-99=Missing');
INSERT INTO "topic" VALUES('Participant characteristics','Q4','GENERAL','edu_father','Q50 GENERATED VARIABLE FOR Highest Education - Father','A=PhD/EdD
B= MD/DDS/DVD/LLB/JD
C=Masters Degree
D=Bachelors Degree
E=AA Degree/Some College
F=Technical/High School Diploma
G=Less than High School Diploma
U=Unknown/Not Applicable
-99=Missing');
INSERT INTO "topic" VALUES('Participant characteristics','Q4','GENERAL','edu_father_combo','Q50 GENERATED VARIABLE FOR Advanced Degree Combo Education - Father','A=PhD/EdD
B= MD/DDS/DVD/LLB/JD
C=Masters Degree
AB=PhD/MD
AC=PhD/Masters
ABC=Phd/MD/Masters
BC=MD/Masters
D=Bachelors Degree or less
U=Unknown/Not Applicable
-99=Missing');
INSERT INTO "topic" VALUES('Participant characteristics','Q4','GENERAL','q4_income','Q51 GENERATED VARIABLE FOR Current household income','A=<25,000
B=25,000-49,999
C=50,000-74,999
D=75,000-99,999
E=100,000-149,999
F=150,000-199,999
G=200,000+
-88=Unable to assign value
-99=Missing');
INSERT INTO "topic" VALUES('Participant characteristics','Q5','RESIDENCY, MARITAL STATUS AND EMPLOYMENT','q5_marital_status','Q3 What is your current marital status?','1=Married
2=Divorced
3=Separated
4=Widowed
5=Never married
-88=Unable to assign value
-99=Missing');
INSERT INTO "topic" VALUES('Participant characteristics','Q6','RESIDENCY, MARITAL STATUS AND EMPLOYMENT','Q6Web_marital_status','Marital status','0 = Skipped
1 = Married or living with partner
2 = Divorced 
3 = Separated
4 = Widowed 
5 = Never Married ');
INSERT INTO "topic" VALUES('Participant characteristics','Q6','INCOME','Q6Web_household_income','Household annual income','0 = Skipped
1 = Less than $25,000 
2 = $25,000 to $49,999 
3 = $50,000 to $74,999 
4 = $75,000 to $99,999
5 = $100,000 to $149,999 
6 = $150,000 to $199,999
7 = $200,000 or more
8 = Prefer not to answer ');
INSERT INTO "topic" VALUES('Participant characteristics','Q6','INCOME','Q6Web_ppl_support_house_income','Number of people supported by household income','0 = Skipped
1 = None 
2 = 1 
3 = 2
4 = 3 
5 = 4
6 = 5
7 = 6
8 = 7+ ');
INSERT INTO "topic" VALUES('Participant characteristics','Q6','INCOME','Q6Web_minor_support_house_inc','Number of minors supported by household income','0 = Skipped
1 = None 
2 = 1 
3 = 2
4 = 3 
5 = 4
6 = 5
7 = 6
8 = 7+ ');
INSERT INTO "topic" VALUES('Participant characteristics','Q6','INCOME','Q6Web_senior_support_house_inc','Number of individuals over 64 supported by household income','0 = Skipped
1 = None 
2 = 1 
3 = 2
4 = 3 
5 = 4
6 = 5
7 = 6
8 = 7+ ');
INSERT INTO "topic" VALUES('Anthropomorphic measurements','Q1','HEALTH HISTORY','HEIGHTX','Q65 RECONSTITUTED - Height today','45-81, .D=Cant fix, .Z=Problem');
INSERT INTO "topic" VALUES('Anthropomorphic measurements','Q1','HEALTH HISTORY','WEIGHTX','Q65 RECONSTITUTED - Weight today','67-450, .D=Cant fix, .Z=Problem');
INSERT INTO "topic" VALUES('Anthropomorphic measurements','Q1','HEALTH HISTORY','HTAT_18X','Q65 RECONSTITUTED - Height age 18','46-81, .D=Cant fix, .Z=Problem');
INSERT INTO "topic" VALUES('Anthropomorphic measurements','Q1','HEALTH HISTORY','WTAT_18X','Q65 RECONSTITUTED - Weight age 18','65-350, .D=Cant fix, .Z=Problem');
INSERT INTO "topic" VALUES('Anthropomorphic measurements','Q1','HEALTH HISTORY','bmi','Q65 BODY MASS INDEX (KG/M**2)','16.0-75.0');
INSERT INTO "topic" VALUES('Anthropomorphic measurements','Q1','HEALTH HISTORY','bmi18','Q65 BODY MASS INDEX (KG/M**2) AGE 18','15.0-54.8');
INSERT INTO "topic" VALUES('Anthropomorphic measurements','Q2','BODY MEASUREMENTS','HIP','Q27 Average of BDBUTT1 and BDBUTT2','20-87, .A=both missing,.B=invalid,.C=big diff mses,.H=Preg');
INSERT INTO "topic" VALUES('Anthropomorphic measurements','Q2','BODY MEASUREMENTS','WAIST','Q27 Average of BDWAIST1 and BDWAIST2','20-77.A=both missing,.B=invalid,.C=big diff mses,.H=Preg');
INSERT INTO "topic" VALUES('Anthropomorphic measurements','Q2','BODY MEASUREMENTS','WAISTHIP','Q27 Waist to hip ratio calc as waist/hip','0.3965454102-2.1953125000, .A=both missing,.B=waist missing,.C=hip missing,.D=Waist/hip invalid,.H=Preg');
INSERT INTO "topic" VALUES('Anthropomorphic measurements','Q2','BODY MEASUREMENTS','ELIGWAISTHIP','Indicator of waist hip eligibility','0=missing/unlikely waisthip, 1=valid waisthip');
INSERT INTO "topic" VALUES('Anthropomorphic measurements','Q4','WEIGHT','LOST20LB','Q30 Since age 18, excluding pregnancies or illnesses, how many times have you lost 20 or more pounds within a 12 month period? ','A=0, B=1, C=2, D=3, E=4, F=5, G=6, H=7+, X=Unclear Answer');
INSERT INTO "topic" VALUES('Anthropomorphic measurements','Q4','WEIGHT','GAIN20LB','Q30 Since age 18, excluding pregnancies or illnesses, how many times have you gained 20 or more pounds within a 12 month period? ','A=0, B=1, C=2, D=3, E=4, F=5, G=6, H=7+, X=Unclear Answer');
INSERT INTO "topic" VALUES('Anthropomorphic measurements','Q4','WEIGHT','Q4WTX','Q28 Generated variable for weight today. ','74-520 (with .=Irresolvable, .Z=BMI <16 weight set to .Z)');
INSERT INTO "topic" VALUES('Anthropomorphic measurements','Q4','WEIGHT','q4bmi','Q28 BODY MASS INDEX (KG/M**2) at Q4','16-95.3');
INSERT INTO "topic" VALUES('Anthropomorphic measurements','Q4','WEIGHT','bodyyoub50','Q31 GENERATED VARIABLE FOR Usual body size of you before age 50','A=Very underweight, B=Underweight, C=Normal weight, D=Slightly overweight, E=Moderately overweight, F=Very overweight, G=Not applicable or don’t know, W=Unreasonable based on other data, X=Irresolveable, Y=Value for after age 50, but Age<50');
INSERT INTO "topic" VALUES('Anthropomorphic measurements','Q4','WEIGHT','bodyyoua50','Q31 GENERATED VARIABLE FOR Usual body size of you after age 50','A=Very underweight, B=Underweight, C=Normal weight, D=Slightly overweight, E=Moderately overweight, F=Very overweight, G=Not applicable or don’t know, W=Unreasonable based on other data, X=Irresolveable, Y=Value for after age 50, but Age<50');
INSERT INTO "topic" VALUES('Anthropomorphic measurements','Q4mini','REAR COVER','WTQ4miniTDY','Q7 Generated variable for weight today. ','000, 10-555, *=Problem');
INSERT INTO "topic" VALUES('Anthropomorphic measurements','Q5','BODY SIZE','Q46a','Q46 Have you lost height as you have aged? (no yes)','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Anthropomorphic measurements','Q5','BODY SIZE','Q46b','Q46 How much height have you lost as you have aged?','* 0=Less than 1 inch, 1=1, 2=2, 3=3 or more ');
INSERT INTO "topic" VALUES('Anthropomorphic measurements','Q5','BODY SIZE','Q47a','Q47 Have you had gastric bypass or lap-band surgery? (no yes)','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Anthropomorphic measurements','Q5','BODY SIZE','Q47b','Q47 What type of gastric bypass or lap-band surgery have you had?','* 1=Lap-band, 2=Roux-en-Y bypass, 3=Other gastric bypass surgery');
INSERT INTO "topic" VALUES('Anthropomorphic measurements','Q5','BODY SIZE','BMIcleanQ5','Q44 BMI (cleaned) at Q5 (kg/m2)','Range: 16.1-54.8
Unknown: .A');
INSERT INTO "topic" VALUES('Anthropomorphic measurements','Q5','BODY SIZE','WeightcleanQ5','Q44 Weight (cleaned) at Q5 (pounds)','Range: 73-387
Unknown: .A');
INSERT INTO "topic" VALUES('Anthropomorphic measurements','Q5','BODY SIZE','HeightcleanQ5','Q46 Height (cleaned) at Q5 (inches)','Range: 48-77
Unknown: .A');
INSERT INTO "topic" VALUES('Anthropomorphic measurements','Q6','BODY SIZE','Q6Web_weight','Current weight in pounds','-88 = Unable to assign value
0 - 999');
INSERT INTO "topic" VALUES('Anthropomorphic measurements','Q6','BODY SIZE','Q6Web_height_feet','Current height in feet','-88 = Unable to assign value
0 - 9');
INSERT INTO "topic" VALUES('Anthropomorphic measurements','Q6','BODY SIZE','Q6Web_height_inches','Current height in inches','-88 = Unable to assign value
00 - 99');
INSERT INTO "topic" VALUES('Employment','Q1','BACKGROUND & ENVIRONMENT','NUMSCHL','Q10 How many schools employed at?','A=1, B=2-3, C=4-5, D=6-8, E=9-12, F=13+');
INSERT INTO "topic" VALUES('Employment','Q1','BACKGROUND & ENVIRONMENT','EMPCAPCR','Q9 Capacity employed in CA schools currently?','A=Preschool, B=Elem, C=Jr High, D=High, E=Other, F=Pupil Svc, G=Admin,  H=Pre/Elm/Oth, I=JrH/Hi/Oth, J=Multi, K=PS/Adm, L=PS/Adm/Tch, M=Unk');
INSERT INTO "topic" VALUES('Employment','Q1','BACKGROUND & ENVIRONMENT','EMPCAPL','Q9 Capacity employed in CA schools longest?','A=Preschool, B=Elem, C=Jr High, D=High, E=Other, F=Pupil Svc, G=Admin, H=Pre/Elm/Oth, I=JrH/Hi/Oth, J=Multi, K=PS/Adm, L=PS/Adm/Tch, M=Unk');
INSERT INTO "topic" VALUES('Employment','Q1','BACKGROUND & ENVIRONMENT','TCHTYPX','Q9 RECONSTITUTED- Teacher type','A=Presch  B=Elem  C=Junior Hi  D=High E=Oth F=Pupil Servcs G=Admin H=Multi I=Unk');
INSERT INTO "topic" VALUES('Employment','Q1','BACKGROUND & ENVIRONMENT','YRSCHL','Q11 How many years total empl in CA school sys?','A=<1, B=1-4, C=5-9, D=10-14, E=15-19, F=20+');
INSERT INTO "topic" VALUES('Employment','Q3','STRESS AND SOCIAL SUPPORT','EMPRET','Q2 Currently retired?','Y');
INSERT INTO "topic" VALUES('Employment','Q3','STRESS AND SOCIAL SUPPORT','EMPUN','Q2 Currently unemployed?','Y');
INSERT INTO "topic" VALUES('Employment','Q3','STRESS AND SOCIAL SUPPORT','EMPHOM','Q2 Currently homemaker?','Y');
INSERT INTO "topic" VALUES('Employment','Q3','STRESS AND SOCIAL SUPPORT','EMPDIS','Q2 Currently disabled?','Y');
INSERT INTO "topic" VALUES('Employment','Q3','STRESS AND SOCIAL SUPPORT','EMPFTT','Q2 Currently full time teaching?','Y');
INSERT INTO "topic" VALUES('Employment','Q3','STRESS AND SOCIAL SUPPORT','EMPPTT','Q2 Currently part time teaching?','Y');
INSERT INTO "topic" VALUES('Employment','Q3','STRESS AND SOCIAL SUPPORT','EMPFTO','Q2 Currently full time other school job?','Y');
INSERT INTO "topic" VALUES('Employment','Q3','STRESS AND SOCIAL SUPPORT','EMPPTO','Q2 Currently part time other school job?','Y');
INSERT INTO "topic" VALUES('Employment','Q3','STRESS AND SOCIAL SUPPORT','EMPFTE','Q2 Currently full time employmt not school?','Y');
INSERT INTO "topic" VALUES('Employment','Q3','STRESS AND SOCIAL SUPPORT','EMPPTE','Q2 Currently part time employmt not school?','Y');
INSERT INTO "topic" VALUES('Employment','Q3','STRESS AND SOCIAL SUPPORT','EMPSE','Q2 Currently self employed?','Y');
INSERT INTO "topic" VALUES('Employment','Q3','STRESS AND SOCIAL SUPPORT','LASTJOB','Q4 Number of years since last worked?','A=2yr or less, B=3-5, C=6-10, D=11-15, E=16+, Z=Unk');
INSERT INTO "topic" VALUES('Employment','Q3','STRESS AND SOCIAL SUPPORT','JOB1','Q5 Learn new things in current job?','A=Strongly disagree, B=Disagree, C=Agree, D=Strongly agree, Z=Unk');
INSERT INTO "topic" VALUES('Employment','Q3','STRESS AND SOCIAL SUPPORT','JOB2','Q5 Repetitive work in current job?','A=Strongly disagree, B=Disagree, C=Agree, D=Strongly agree, Z=Unk');
INSERT INTO "topic" VALUES('Employment','Q3','STRESS AND SOCIAL SUPPORT','JOB3','Q5 Creative in current job?','A=Strongly disagree, B=Disagree, C=Agree, D=Strongly agree, Z=Unk');
INSERT INTO "topic" VALUES('Employment','Q3','STRESS AND SOCIAL SUPPORT','JOB4','Q5 Make a lot of decisions in current job?','A=Strongly disagree, B=Disagree, C=Agree, D=Strongly agree, Z=Unk');
INSERT INTO "topic" VALUES('Employment','Q3','STRESS AND SOCIAL SUPPORT','JOB5','Q5 High level of skill in current job?','A=Strongly disagree, B=Disagree, C=Agree, D=Strongly agree, Z=Unk');
INSERT INTO "topic" VALUES('Employment','Q3','STRESS AND SOCIAL SUPPORT','JOB6','Q5 Little freedom in current job?','A=Strongly disagree, B=Disagree, C=Agree, D=Strongly agree, Z=Unk');
INSERT INTO "topic" VALUES('Employment','Q3','STRESS AND SOCIAL SUPPORT','JOB7','Q5 Do a variety of things in current job?','A=Strongly disagree, B=Disagree, C=Agree, D=Strongly agree, Z=Unk');
INSERT INTO "topic" VALUES('Employment','Q3','STRESS AND SOCIAL SUPPORT','JOB8','Q5 A lot of say in current job?','A=Strongly disagree, B=Disagree, C=Agree, D=Strongly agree, Z=Unk');
INSERT INTO "topic" VALUES('Employment','Q3','STRESS AND SOCIAL SUPPORT','JOB9','Q5 Opportunity to develop in current job?','A=Strongly disagree, B=Disagree, C=Agree, D=Strongly agree, Z=Unk');
INSERT INTO "topic" VALUES('Employment','Q3','STRESS AND SOCIAL SUPPORT','JOB10','Q5 Work fast in current job?','A=Strongly disagree, B=Disagree, C=Agree, D=Strongly agree, Z=Unk');
INSERT INTO "topic" VALUES('Employment','Q3','STRESS AND SOCIAL SUPPORT','JOB11','Q5 Work hard in current job?','A=Strongly disagree, B=Disagree, C=Agree, D=Strongly agree, Z=Unk');
INSERT INTO "topic" VALUES('Employment','Q3','STRESS AND SOCIAL SUPPORT','JOB12','Q5 Physical effort in current job?','A=Strongly disagree, B=Disagree, C=Agree, D=Strongly agree, Z=Unk');
INSERT INTO "topic" VALUES('Employment','Q3','STRESS AND SOCIAL SUPPORT','JOB13','Q5 Not excessive work in current job?','A=Strongly disagree, B=Disagree, C=Agree, D=Strongly agree, Z=Unk');
INSERT INTO "topic" VALUES('Employment','Q3','STRESS AND SOCIAL SUPPORT','JOB14','Q5 Enough time in current job?','A=Strongly disagree, B=Disagree, C=Agree, D=Strongly agree, Z=Unk');
INSERT INTO "topic" VALUES('Employment','Q3','STRESS AND SOCIAL SUPPORT','JOB15','Q5 Good job security in current job?','A=Strongly disagree, B=Disagree, C=Agree, D=Strongly agree, Z=Unk');
INSERT INTO "topic" VALUES('Employment','Q3','STRESS AND SOCIAL SUPPORT','JOB16','Q5 Feel safe in current job?','A=Strongly disagree, B=Disagree, C=Agree, D=Strongly agree, Z=Unk');
INSERT INTO "topic" VALUES('Employment','Q3','STRESS AND SOCIAL SUPPORT','JOB17','Q5 Free of conflicting demands?','A=Strongly disagree, B=Disagree, C=Agree, D=Strongly agree, Z=Unk');
INSERT INTO "topic" VALUES('Employment','Q3','STRESS AND SOCIAL SUPPORT','JOB18','Q5 Competent people in current job?','A=Strongly disagree, B=Disagree, C=Agree, D=Strongly agree, Z=Unk');
INSERT INTO "topic" VALUES('Employment','Q3','STRESS AND SOCIAL SUPPORT','JOB19','Q5 People take an interest in me in job?','A=Strongly disagree, B=Disagree, C=Agree, D=Strongly agree, Z=Unk');
INSERT INTO "topic" VALUES('Employment','Q3','STRESS AND SOCIAL SUPPORT','JOB20','Q5 Friendly people in current job?','A=Strongly disagree, B=Disagree, C=Agree, D=Strongly agree, Z=Unk');
INSERT INTO "topic" VALUES('Employment','Q3','STRESS AND SOCIAL SUPPORT','JOB21','Q5 Helpful people in current job?','A=Strongly disagree, B=Disagree, C=Agree, D=Strongly agree, Z=Unk');
INSERT INTO "topic" VALUES('Employment','Q3','STRESS AND SOCIAL SUPPORT','JOB22','Q5 Current supervisor concerned for staff?','A=Strongly disagree, B=Disagree, C=Agree, D=Strongly agree, E=N/A or DK');
INSERT INTO "topic" VALUES('Employment','Q3','STRESS AND SOCIAL SUPPORT','JOB23','Q5 Current supervisor pays attention?','A=Strongly disagree, B=Disagree, C=Agree, D=Strongly agree, E=N/A or DK');
INSERT INTO "topic" VALUES('Employment','Q3','STRESS AND SOCIAL SUPPORT','JOB24','Q5 Current supervisor helpful?','A=Strongly disagree, B=Disagree, C=Agree, D=Strongly agree, E=N/A or DK');
INSERT INTO "topic" VALUES('Employment','Q3','STRESS AND SOCIAL SUPPORT','JOB25','Q5 Current supervisor gets people together?','A=Strongly disagree, B=Disagree, C=Agree, D=Strongly agree, E=N/A or DK');
INSERT INTO "topic" VALUES('Employment','Q3','STRESS AND SOCIAL SUPPORT','JABSENT','Q6 Times ill from work in last year','A=Not working, B=No time, C=A few days, D=About a week, E=A few weeks, F=A month or more, Z=Unk');
INSERT INTO "topic" VALUES('Employment','Q5','RESIDENCY, MARITAL STATUS AND EMPLOYMENT','Q4a','Q4 Current employment status answser of currently employed in public, charter, or private schools','1=Currently employed in public, charter, or private schools');
INSERT INTO "topic" VALUES('Employment','Q5','RESIDENCY, MARITAL STATUS AND EMPLOYMENT','Q4b','Q4 Current employment status answser of other employment','1=Other employment');
INSERT INTO "topic" VALUES('Employment','Q5','RESIDENCY, MARITAL STATUS AND EMPLOYMENT','Q4c','Q4 Current employment status answser of not currently working, but plannin to re-enter the work force','1=Not currently working, but planning to re-enter work force');
INSERT INTO "topic" VALUES('Employment','Q5','RESIDENCY, MARITAL STATUS AND EMPLOYMENT','Q4d','Q4 Current employment status answser of unable to work','1=Unable to work');
INSERT INTO "topic" VALUES('Employment','Q5','RESIDENCY, MARITAL STATUS AND EMPLOYMENT','Q4e','Q4 Current employment status answser of homemaker','1=Homemaker');
INSERT INTO "topic" VALUES('Employment','Q5','RESIDENCY, MARITAL STATUS AND EMPLOYMENT','Q4f','Q4 Current employment status answser of retired','1=Retired');
INSERT INTO "topic" VALUES('Employment','Q6','RESIDENCY, MARITAL STATUS AND EMPLOYMENT','Q6Web_employ_school','Participant is currently employed in public, charter, or private schools','-88 = Unable to assign value
0 = Skipped
1 = Yes
2 = No');
INSERT INTO "topic" VALUES('Employment','Q6','RESIDENCY, MARITAL STATUS AND EMPLOYMENT','Q6Web_employ_other','Participant is currently employed in another occupation','-88 = Unable to assign value
0 = Skipped
1 = Yes
2 = No');
INSERT INTO "topic" VALUES('Employment','Q6','RESIDENCY, MARITAL STATUS AND EMPLOYMENT','Q6Web_employ_not_currently','Participant is not currently working','-88 = Unable to assign value
0 = Skipped
1 = Yes
2 = No');
INSERT INTO "topic" VALUES('Employment','Q6','RESIDENCY, MARITAL STATUS AND EMPLOYMENT','Q6Web_employ_homemaker','Participant is a homemaker','-88 = Unable to assign value
0 = Skipped
1 = Yes
2 = No');
INSERT INTO "topic" VALUES('Employment','Q6','RESIDENCY, MARITAL STATUS AND EMPLOYMENT','Q6Web_employ_unable_work','Participant is unable to work','-88 = Unable to assign value
0 = Skipped
1 = Yes
2 = No');
INSERT INTO "topic" VALUES('Employment','Q6','RESIDENCY, MARITAL STATUS AND EMPLOYMENT','Q6Web_employ_retired','Participant is retired','-88 = Unable to assign value
0 = Skipped
1 = Yes
2 = No');
INSERT INTO "topic" VALUES('Environment','Q1','BACKGROUND & ENVIRONMENT','NEARCHEM','Q13 Ever lived/worked w/i 1/2 mile chem plant?','N/Y/Z');
INSERT INTO "topic" VALUES('Environment','Q1','BACKGROUND & ENVIRONMENT','NEARPWR','Q13 Ever lived/worked w/i 1/2 mile power plant?','N/Y/Z');
INSERT INTO "topic" VALUES('Environment','Q1','BACKGROUND & ENVIRONMENT','NEARPULP','Q13 Ever lived/worked w/i 1/2 mile pulp mill?','N/Y/Z');
INSERT INTO "topic" VALUES('Environment','Q1','BACKGROUND & ENVIRONMENT','NEAROIL','Q13 Ever lived/worked w/i 1/2 mile oil refinery?','N/Y/Z');
INSERT INTO "topic" VALUES('Environment','Q1','BACKGROUND & ENVIRONMENT','NEARLDFL','Q13 Ever lived/worked w/i 1/2 mile landfill?','N/Y/Z');
INSERT INTO "topic" VALUES('Environment','Q1','BACKGROUND & ENVIRONMENT','PWRSCHLC','Q14 Types of ovhd pwr lines w/i 1 blk of cur school?','A=No pwr lns, B=On poles, C=On towers, D=On poles & towers, E=Don''t Know, Z=Problem');
INSERT INTO "topic" VALUES('Environment','Q1','BACKGROUND & ENVIRONMENT','PWRSCHLL','Q14 Types of ovhd pwr lines w/i 1 blk of long school?','A=No pwr lns, B=On poles, C=On towers, D=On poles & towers, E=Don''t Know, Z=Problem');
INSERT INTO "topic" VALUES('Environment','Q1','BACKGROUND & ENVIRONMENT','PWRRESC','Q15 Types of overhead pwr lines w/i 1 blk of cur res?','A=No pwr lns, B=On poles, C=On towers, D=On poles & towers, E=Don''t Know, Z=Problem');
INSERT INTO "topic" VALUES('Environment','Q1','BACKGROUND & ENVIRONMENT','PWRRESL','Q15 Types of overhead pwr lines w/i 1 blk of lng res?','A=No pwr lns, B=On poles, C=On towers, D=On poles & towers, E=Don''t Know, Z=Problem');
INSERT INTO "topic" VALUES('Environment','Q1','BACKGROUND & ENVIRONMENT','PSTSKN15','Q16 Use insect repellent on skin/clothing - under 15?','A=No, B=Yes/occasionally, C=Yes/frequent, Y=Ans both (B) & (C), Z=Problem');
INSERT INTO "topic" VALUES('Environment','Q1','BACKGROUND & ENVIRONMENT','PSTSKNM','Q16 Use insect repellent on skin/clothing - 15-35?','A=No, B=Yes/occasionally, C=Yes/frequent, Y=Ans both (B) & (C), Z=Problem');
INSERT INTO "topic" VALUES('Environment','Q1','BACKGROUND & ENVIRONMENT','PSTSKN35','Q16 Use insect repellent on skin/clothing - over 35?','A=No, B=Yes/occasionally, C=Yes/frequent, Y=Ans both (B) & (C), Z=Problem');
INSERT INTO "topic" VALUES('Environment','Q1','BACKGROUND & ENVIRONMENT','PSTHOM15','Q16 Use pest/herbicides in home - under 15?','A=No, B=Yes/occasionally, C=Yes/frequent, Y=Ans both (B) & (C), Z=Problem');
INSERT INTO "topic" VALUES('Environment','Q1','BACKGROUND & ENVIRONMENT','PSTHOMM','Q16 Use pest/herbicides in home - 15-35?','A=No, B=Yes/occasionally, C=Yes/frequent, Y=Ans both (B) & (C), Z=Problem');
INSERT INTO "topic" VALUES('Environment','Q1','BACKGROUND & ENVIRONMENT','PSTHOM35','Q16 Use pest/herbicides in home - over 35?','A=No, B=Yes/occasionally, C=Yes/frequent, Y=Ans both (B) & (C), Z=Problem');
INSERT INTO "topic" VALUES('Environment','Q1','BACKGROUND & ENVIRONMENT','PSTCLD15','Q16 Ever in a cloud of pest spray - under 15?','A=No, B=Yes/occasionally, C=Yes/frequent, Y=Ans both (B) & (C), Z=Problem');
INSERT INTO "topic" VALUES('Environment','Q1','BACKGROUND & ENVIRONMENT','PSTCLDM','Q16 Ever in a cloud of pest spray - 15-35?','A=No, B=Yes/occasionally, C=Yes/frequent, Y=Ans both (B) & (C), Z=Problem');
INSERT INTO "topic" VALUES('Environment','Q1','BACKGROUND & ENVIRONMENT','PSTCLD35','Q16 Ever in a cloud of pest spray - over 35?','A=No, B=Yes/occasionally, C=Yes/frequent, Y=Ans both (B) & (C), Z=Problem');
INSERT INTO "topic" VALUES('Environment','Q1','BACKGROUND & ENVIRONMENT','PSTFRM15','Q16 Use pest/herbicides on farm - under 15?','A=No, B=Yes/occasionally, C=Yes/frequent, Y=Ans both (B) & (C), Z=Problem');
INSERT INTO "topic" VALUES('Environment','Q1','BACKGROUND & ENVIRONMENT','PSTFRMM','Q16 Use pest/herbicides on farm - 15-35?','A=No, B=Yes/occasionally, C=Yes/frequent, Y=Ans both (B) & (C), Z=Problem');
INSERT INTO "topic" VALUES('Environment','Q1','BACKGROUND & ENVIRONMENT','PSTFRM35','Q16 Use pest/herbicides on farm - over 35?','A=No, B=Yes/occasionally, C=Yes/frequent, Y=Ans both (B) & (C), Z=Problem');
INSERT INTO "topic" VALUES('Environment','Q1','BACKGROUND & ENVIRONMENT','ELBLKT','Q17 Used elect blanket while sleeping?','N/Y/Z');
INSERT INTO "topic" VALUES('Environment','Q1','BACKGROUND & ENVIRONMENT','ELBED','Q17 Used elect water bed while sleeping?','N/Y/Z');
INSERT INTO "topic" VALUES('Environment','Q1','BACKGROUND & ENVIRONMENT','ELROOM','Q17 Used elect room heat while sleeping?','N/Y/Z');
INSERT INTO "topic" VALUES('Environment','Q1','BACKGROUND & ENVIRONMENT','ELLITE','Q17 Used elect light while sleeping?','N/Y/Z');
INSERT INTO "topic" VALUES('Environment','Q1','BACKGROUND & ENVIRONMENT','SUNPROT','Q18 What happens to skin in sun w/o protection?','A=SevBrn w/bls, B=SevBrn w/o bls, C=Mld brn/tan, D=No brn then tan, E=No brn/tan, X=Ans both (A) & (B), Y=Ans both (D) & (E), Z=Problem
');
INSERT INTO "topic" VALUES('Environment','Q1','BACKGROUND & ENVIRONMENT','SUNREP','Q19 What happens to skin in sun repeatedly?','A=Deep tan, B=Mod tan, C=Lt tan, D=No tan, Y=Ans any combination of (A) (B) (C), Z=Problem');
INSERT INTO "topic" VALUES('Environment','Q1','BACKGROUND & ENVIRONMENT','SUNBLIST','Q20 Ever sunburned enough to cause blistering?','N/Y');
INSERT INTO "topic" VALUES('Environment','Q1','BACKGROUND & ENVIRONMENT','SUNFIRST','Q20 What age did this first occur?','A=5 or less, B=6-10, C=11-15, D=16-20, E=21-25, F=26+, Z=Problem');
INSERT INTO "topic" VALUES('Environment','Q1','BACKGROUND & ENVIRONMENT','SUNTIMES','Q20 How many times did this occur?','A=1-2, B=3-4, C=5-9, D=10+');
INSERT INTO "topic" VALUES('Environment','Q4','RESIDENCY','BEDR6M','Q4 How many siblings or other people usually slept in the same bedroom as you at age 6 months?','A=0, B=1-2, C=3-5, D=6+, E=>0, X=Image covered, Z=Problem');
INSERT INTO "topic" VALUES('Environment','Q4','RESIDENCY','BEDR3','Q4 How many siblings or other people usually slept in the same bedroom as you at age 3 years?','A=0, B=1-2, C=3-5, D=6+, E=>0, X=Image covered, Z=Problem');
INSERT INTO "topic" VALUES('Environment','Q4','RESIDENCY','BEDR5','Q4 How many siblings or other people usually slept in the same bedroom as you at age 5 years?','A=0, B=1-2, C=3-5, D=6+, E=>0, X=Image covered, Z=Problem');
INSERT INTO "topic" VALUES('Environment','Q4','RESIDENCY','BEDR12','Q4 How many siblings or other people usually slept in the same bedroom as you at age 12 years?','A=0, B=1-2, C=3-5, D=6+, E=>0, X=Image covered, Z=Problem');
INSERT INTO "topic" VALUES('Environment','Q4','RESIDENCY','BEDR30','Q4 How many siblings or other people usually slept in the same bedroom as you at age 30 years?','A=0, B=1-2, C=3-5, D=6+, E=>0, X=Image covered, Z=Problem');
INSERT INTO "topic" VALUES('Environment','Q4','RESIDENCY','BEDRNOW','Q4 How many siblings or other people usually slept in the same bedroom as you at the present time?','A=0, B=1-2, C=3-5, D=6+, E=>0, X=Image covered, Z=Problem');
INSERT INTO "topic" VALUES('Environment','Q4','RESIDENCY','DAYC6M','Q4 Did you regularly attend a preschool, kindergaren, daycare, or other regular gathering of at least 4 other children at age 6 months?','Y=Yes, N=No, Z=Problem');
INSERT INTO "topic" VALUES('Environment','Q4','RESIDENCY','DAYC3','Q4 Did you regularly attend a preschool, kindergaren, daycare, or other regular gathering of at least 4 other children at age 3 years?','Y=Yes, N=No, Z=Problem');
INSERT INTO "topic" VALUES('Environment','Q4','RESIDENCY','DAYC5','Q4 Did you regularly attend a preschool, kindergaren, daycare, or other regular gathering of at least 4 other children at age 5 years?','Y=Yes, N=No, Z=Problem');
INSERT INTO "topic" VALUES('Environment','Q4','RESIDENCY','PET6M','Q4 Did you have a cat or dog living inside your home at age 6 months?','Y=Yes, N=No, Z=Problem');
INSERT INTO "topic" VALUES('Environment','Q4','RESIDENCY','PET3','Q4 Did you have a cat or dog living inside your home at age 3 years?','Y=Yes, N=No, Z=Problem');
INSERT INTO "topic" VALUES('Environment','Q4','RESIDENCY','PET5','Q4 Did you have a cat or dog living inside your home at age 5 years?','Y=Yes, N=No, Z=Problem');
INSERT INTO "topic" VALUES('Environment','Q4','RESIDENCY','PET12','Q4 Did you have a cat or dog living inside your home at age 12 years?','Y=Yes, N=No, Z=Problem');
INSERT INTO "topic" VALUES('Environment','Q4','RESIDENCY','PET30','Q4 Did you have a cat or dog living inside your home at age 30 years?','Y=Yes, N=No, Z=Problem');
INSERT INTO "topic" VALUES('Environment','Q4','RESIDENCY','PETNOW','Q4 Did you have a cat or dog living inside your home at the present time?','Y=Yes, N=No, Z=Problem');
INSERT INTO "topic" VALUES('Environment','Q4','RESIDENCY','HOOF6M','Q4 Did you live within a half-mile of stables or pens where horses, cows, pigs, or other hoofed animals were kept at age 6 months?','Y=Yes, N=No, Z=Problem');
INSERT INTO "topic" VALUES('Environment','Q4','RESIDENCY','HOOF3','Q4 Did you live within a half-mile of stables or pens where horses, cows, pigs, or other hoofed animals were kept at age 3 years?','Y=Yes, N=No, Z=Problem');
INSERT INTO "topic" VALUES('Environment','Q4','RESIDENCY','HOOF5','Q4 Did you live within a half-mile of stables or pens where horses, cows, pigs, or other hoofed animals were kept at age 5 years?','Y=Yes, N=No, Z=Problem');
INSERT INTO "topic" VALUES('Environment','Q4','RESIDENCY','HOOF12','Q4 Did you live within a half-mile of stables or pens where horses, cows, pigs, or other hoofed animals were kept at age 12 years?','Y=Yes, N=No, Z=Problem');
INSERT INTO "topic" VALUES('Environment','Q4','RESIDENCY','HOOF30','Q4 Did you live within a half-mile of stables or pens where horses, cows, pigs, or other hoofed animals were kept at age 30 years?','Y=Yes, N=No, Z=Problem');
INSERT INTO "topic" VALUES('Environment','Q4','RESIDENCY','HOOFNOW','Q4 Did you live within a half-mile of stables or pens where horses, cows, pigs, or other hoofed animals were kept at the present time?','Y=Yes, N=No, Z=Problem');
INSERT INTO "topic" VALUES('Environment','Q4','RESIDENCY','RENT6MX','Q4 GENERATED VARIABLE FOR Lived in rented house/apt at age 6 months?','Y=Yes, N=No, YN=Both Yes/No, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Environment','Q4','RESIDENCY','RENT3X','Q4 GENERATED VARIABLE FOR Lived in rented house/apt at age 3?','Y=Yes, N=No, YN=Both Yes/No, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Environment','Q4','RESIDENCY','RENT5X','Q4 GENERATED VARIABLE FOR Lived in rented house/apt at age 5?','Y=Yes, N=No, YN=Both Yes/No, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Environment','Q4','RESIDENCY','RENT12X','Q4 GENERATED VARIABLE FOR Lived in rented house/apt at age 12?','Y=Yes, N=No, YN=Both Yes/No, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Environment','Q4','RESIDENCY','RENT30X','Q4 GENERATED VARIABLE FOR Lived in rented house/apt at age 30?','Y=Yes, N=No, YN=Both Yes/No, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Environment','Q4','RESIDENCY','RENTNOWX','Q4 GENERATED VARIABLE FOR Live in rented house/apt now?','Y=Yes, N=No, YN=Both Yes/No, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Environment','Q4','RESIDENCY','RURL6Mx','Q4 GENERATED VARIABLE FOR Lived in Rural/Urban area at age 6 months?','A=Rural, B=Town, C=Suburb, D=Urban, E=Non-rural, ABC=Rural/Town/Suburb, ABCD=Rural/Town/Suburb/Urban, V=Questionnaire section blank, Z=Non-Contiguous Responses, X=Unknown, Image covered');
INSERT INTO "topic" VALUES('Environment','Q4','RESIDENCY','RURL3x','Q4 GENERATED VARIABLE FOR Lived in Rural/Urban area at age 3?','A=Rural, B=Town, C=Suburb, D=Urban, E=Non-rural, ABC=Rural/Town/Suburb, ABCD=Rural/Town/Suburb/Urban, V=Questionnaire section blank, Z=Non-Contiguous Responses, X=Unknown, Image covered');
INSERT INTO "topic" VALUES('Environment','Q4','RESIDENCY','RURL5x','Q4 GENERATED VARIABLE FOR Lived in Rural/Urban area at age 5?','A=Rural, B=Town, C=Suburb, D=Urban, E=Non-rural, ABC=Rural/Town/Suburb, ABCD=Rural/Town/Suburb/Urban, V=Questionnaire section blank, Z=Non-Contiguous Responses, X=Unknown, Image covered');
INSERT INTO "topic" VALUES('Environment','Q4','RESIDENCY','RURL12x','Q4 GENERATED VARIABLE FOR Lived in Rural/Urban area at age 12?','A=Rural, B=Town, C=Suburb, D=Urban, E=Non-rural, ABC=Rural/Town/Suburb, ABCD=Rural/Town/Suburb/Urban, V=Questionnaire section blank, Z=Non-Contiguous Responses, X=Unknown, Image covered');
INSERT INTO "topic" VALUES('Environment','Q4','RESIDENCY','RURL30x','Q4 GENERATED VARIABLE FOR Lived in Rural/Urban area at age 30?','A=Rural, B=Town, C=Suburb, D=Urban, E=Non-rural, ABC=Rural/Town/Suburb, ABCD=Rural/Town/Suburb/Urban, V=Questionnaire section blank, Z=Non-Contiguous Responses, X=Unknown, Image covered');
INSERT INTO "topic" VALUES('Environment','Q4','RESIDENCY','RURLNOWx','Q4 GENERATED VARIABLE FOR Live in Rural/Urban area now?','A=Rural, B=Town, C=Suburb, D=Urban, E=Non-rural, ABC=Rural/Town/Suburb, ABCD=Rural/Town/Suburb/Urban, V=Questionnaire section blank, Z=Non-Contiguous Responses, X=Unknown, Image covered');
INSERT INTO "topic" VALUES('Environment','Q5','CURRENT LIFE EXPERIENCES','Q12','Q12 How often do you get colds, compared with other people your age? ','1=Less often, 2=About the same, 3=More often');
INSERT INTO "topic" VALUES('Environment','Q5','CURRENT LIFE EXPERIENCES','Q13','Q13 On average, how many hours a week do you spend with at least one child under 5 years of age?','1=<1 hour/wk, 2=1-5 hours/wk, 3=6-10 hours/wk, 4=11-15 hours/wk, 5=16-20 hours/wk, 6=>20 hours/wk');
INSERT INTO "topic" VALUES('Environment','Q5','PERSONAL CARE PRACTICES','Q48a_Type','Q48a Do/did you ever use facial creams/makeup with SPF?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Environment','Q5','PERSONAL CARE PRACTICES','Q48a_totyr','Q48a For how many years total have you used facial creams/makeup with SPF routinely?','* 0=Under 1 year, 1=1-5, 2=6-10, 3=11-20, 4=21+');
INSERT INTO "topic" VALUES('Environment','Q5','PERSONAL CARE PRACTICES','Q48a_15','Q48a How often when you were age <15 did you use facial creams/makeup with SPF?','* 0=Never, 1=Sometimes, 2=Often, 3=Always');
INSERT INTO "topic" VALUES('Environment','Q5','PERSONAL CARE PRACTICES','Q48a_25','Q48a How often when you were ages 15-25 did you use facial creams/makeup with SPF?','* 0=Never, 1=Sometimes, 2=Often, 3=Always');
INSERT INTO "topic" VALUES('Environment','Q5','PERSONAL CARE PRACTICES','Q48a_40','Q48a How often when you were ages 26-40 did you use facial creams/makeup with SPF?','* 0=Never, 1=Sometimes, 2=Often, 3=Always');
INSERT INTO "topic" VALUES('Environment','Q5','PERSONAL CARE PRACTICES','Q48a_60','Q48a How often when you were age 41-60 did you use facial creams/makeup with SPF?','* 0=Never, 1=Sometimes, 2=Often, 3=Always');
INSERT INTO "topic" VALUES('Environment','Q5','PERSONAL CARE PRACTICES','Q48a_61','Q48a How often when you were age 61 or older did you use facial creams/makeup with SPF?','* 0=Never, 1=Sometimes, 2=Often, 3=Always');
INSERT INTO "topic" VALUES('Environment','Q5','PERSONAL CARE PRACTICES','Q48b_Type','Q48b Do/did you ever apply sunscreen when spending time in the sun?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Environment','Q5','PERSONAL CARE PRACTICES','Q48b_totyr','Q48b For how many years total have you routinely applied sunscreen when spending time in the sun?','* 0=Under 1 year, 1=1-5, 2=6-10, 3=11-20, 4=21+');
INSERT INTO "topic" VALUES('Environment','Q5','PERSONAL CARE PRACTICES','Q48b_15','Q48b How often when you were age <15 did you apply sunscreen when spending time in the sun?','* 0=Never, 1=Sometimes, 2=Often, 3=Always');
INSERT INTO "topic" VALUES('Environment','Q5','PERSONAL CARE PRACTICES','Q48b_25','Q48b How often when you were ages 15-25 did you apply sunscreen when spending time in the sun?','* 0=Never, 1=Sometimes, 2=Often, 3=Always');
INSERT INTO "topic" VALUES('Environment','Q5','PERSONAL CARE PRACTICES','Q48b_40','Q48b How often when you were aged 26-40 did you apply sunscreen when spending time in the sun?','* 0=Never, 1=Sometimes, 2=Often, 3=Always');
INSERT INTO "topic" VALUES('Environment','Q5','PERSONAL CARE PRACTICES','Q48b_60','Q48b How often when you were ages 41-60 did you apply sunscreen when spending time in the sun?','* 0=Never, 1=Sometimes, 2=Often, 3=Always');
INSERT INTO "topic" VALUES('Environment','Q5','PERSONAL CARE PRACTICES','Q48b_61','Q48b How often when you were age 61 or older did you apply sunscreen when spending time in the sun?','* 0=Never, 1=Sometimes, 2=Often, 3=Always');
INSERT INTO "topic" VALUES('Environment','Q5','PERSONAL CARE PRACTICES','Q48c_Type','Q48c Do/did you ever use a tanning bed or tanning booth?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Environment','Q5','PERSONAL CARE PRACTICES','Q48c_totyr','Q48c For how many years total have you routinely used a tanning bed or tanning booth?','* 0=Under 1 year, 1=1-5, 2=6-10, 3=11-20, 4=21+');
INSERT INTO "topic" VALUES('Environment','Q5','PERSONAL CARE PRACTICES','Q48c_15','Q48c How often when you were age <15 did you use a tanning bed or tanning booth?','* 0=Never, 1=Sometimes, 2=Often');
INSERT INTO "topic" VALUES('Environment','Q5','PERSONAL CARE PRACTICES','Q48c_25','Q48c How often when you were ages 15-25 did you use a tanning bed or tanning booth?','* 0=Never, 1=Sometimes, 2=Often');
INSERT INTO "topic" VALUES('Environment','Q5','PERSONAL CARE PRACTICES','Q48c_40','Q48c How often when you were ages 26-40 did you use a tanning bed or tanning booth?','* 0=Never, 1=Sometimes, 2=Often');
INSERT INTO "topic" VALUES('Environment','Q5','PERSONAL CARE PRACTICES','Q48c_60','Q48c How often when you were ages 41-60 did you use a tanning bed or tanning booth?','* 0=Never, 1=Sometimes, 2=Often');
INSERT INTO "topic" VALUES('Environment','Q5','PERSONAL CARE PRACTICES','Q48c_61','Q48c How often when you were age 61 or older did you use a tanning bed or tanning booth?','* 0=Never, 1=Sometimes, 2=Often');
INSERT INTO "topic" VALUES('Environment','Q6','DRINKING WATER','Q6Web_usual_glasses_water','Usual intake glass of water ','-88 = Unable to assign value
0 = Skipped
1 = 1 a day
2 = 2 a day
3 = 3 a day
4 = 4 a day
5 = 5 a day
6 = 6+ a day
7 = Occasionally, i.e. not every day
8 = Drank but don''t know how much
9 = Never');
INSERT INTO "topic" VALUES('Environment','Q6','DRINKING WATER','Q6Web_usual_cups_coffee','Usual intake cup of coffee ','-88 = Unable to assign value
0 = Skipped
1 = 1 a day
2 = 2 a day
3 = 3 a day
4 = 4 a day
5 = 5 a day
6 = 6+ a day
7 = Occasionally, i.e. not every day
8 = Drank but don''t know how much
9 = Never');
INSERT INTO "topic" VALUES('Environment','Q6','DRINKING WATER','Q6Web_usual_cups_tea','Usual intake cup of hot tea ','-88 = Unable to assign value
0 = Skipped
1 = 1 a day
2 = 2 a day
3 = 3 a day
4 = 4 a day
5 = 5 a day
6 = 6+ a day
7 = Occasionally, i.e. not every day
8 = Drank but don''t know how much
9 = Never');
INSERT INTO "topic" VALUES('Environment','Q6','DRINKING WATER','Q6Web_usual_glasses_icedtea','Usual intake glass of iced tea ','-88 = Unable to assign value
0 = Skipped
1 = 1 a day
2 = 2 a day
3 = 3 a day
4 = 4 a day
5 = 5 a day
6 = 6+ a day
7 = Occasionally, i.e. not every day
8 = Drank but don''t know how much
9 = Never');
INSERT INTO "topic" VALUES('Environment','Q6','CURRENT HOME WATER','Q6Web_showers_per_week','Average baths or showers per week','-88 = Unable to assign value
0-99');
INSERT INTO "topic" VALUES('Environment','Q6','CURRENT HOME WATER','Q6Web_water_source_curr_home','Current home drinking water source','-88 = Unable to assign value
0 = Skipped
1 = Municipal water
2 = Private well
3 = Bottled water 
4 = Other
5 = Don’t know');
INSERT INTO "topic" VALUES('Environment','Q6','CURRENT HOME WATER','Q6Web_filter_tap_H2O_curr_home','Current home tap water filtered','-88 = Unable to assign value
0 = Skipped
1 = Yes (no further detail)
2 = No
3 = Don’t know
4=Yes, using a filter like Brita or PUR in a pitcher or on a faucet
5=Yes, filtered using water from my refrigerator
6=Yes, using reverse osmosis (under sink or whole house)
7=Yes, filtered with another type of filter (under sink or whole house)
8=Yes, other');
INSERT INTO "topic" VALUES('Residency','Q4','RESIDENCY','RESYRX','Q1 GENERATED VARIABLE FOR Years lived at current residency','A=<1 yr, B=1-4, C=5-9, D=10-14, E=15-19, F=20-29, G=30+, U=Unknown, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Residency','Q4','RESIDENCY','RESYRCAX','Q2 GENERATED VARIABLE FOR Years lived in total in California','A=<1 yr, B=1-4, C=5-9, D=10-14, E=15-19, F=20-29, G=30+, U=Unknown, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Residency','Q5mini','RESIDENCY, MARITAL STATUS AND EMPLOYMENT','Q1','Q1 For how many years have you lived at your current residence?','* 1=<1, 2=1-4, 3=5-9, 4=10-14, 5=15-19, 6=20-29, 7=30+');
INSERT INTO "topic" VALUES('Oral contraceptives','Q1','REPRODUCTIVE HISTORY','ROCYN15','Q24-26 EVER USED OC','0-4, 0=NO,<=1915, 1=Y_Curr, 2=Y_Pst, 4=Y_Cur?_Pst?, .A=FP_Blnk, .B=PG_Blnk, .C=NVR_Q2426B, .U=Unk_Rev');
INSERT INTO "topic" VALUES('Oral contraceptives','Q1','REPRODUCTIVE HISTORY','RTOCYRS15','Q24-26 TOTAL YRS USED OC','0-8, 0=No OC, 1=<1, 2=1-2, 3=3-4, 4=5-9, 5=10-14, 6=15-19, 7=20-24, 8=25+, .A=FP_Blnk, .B=PG_Blnk, .C=NVR_Q2426B, .H=H:OC15Y_NoYrs,  .U=Unk_Rev');
INSERT INTO "topic" VALUES('Oral contraceptives','Q1','REPRODUCTIVE HISTORY','PILLAGFX','Q25 RECONSTITUTED -Age first used birth control','0-69');
INSERT INTO "topic" VALUES('Oral contraceptives','Q1','REPRODUCTIVE HISTORY','PILLAGLX','Q25 RECONSTITUTED -Age last used birth control','0-83, .Z=Problem');
INSERT INTO "topic" VALUES('Oral contraceptives','Q3','CONTRACEPTION AND MENOPAUSE','PILUSEQ3','Q12 Ever used oral contraceptives?','Y/N/Z=Unk');
INSERT INTO "topic" VALUES('Oral contraceptives','Q3','CONTRACEPTION AND MENOPAUSE','PILLMTH','Q13 How many months oral contraceptives?','A=Used but not past 4 yrs, B=1-6 mths, C=7-12 mths, D=13-24 mths, E=25-36 mths, F=37-48 mths, G=<1 mth use, Z=Unk');
INSERT INTO "topic" VALUES('Oral contraceptives','Q3','CONTRACEPTION AND MENOPAUSE','OC15Q3','Q12-13 ORAL CONTRACEPTIVES USES (INCL Q1)','0-6, 0=No OC, 1=CURR, 2=PAST, 3=UNK, 4=USED, 5=CURR, 6=PROB PAST');
INSERT INTO "topic" VALUES('Oral contraceptives','Q5','ORAL CONTRACEPTIVES','Q23a','Q23 Since January 2000, have you used birth control pills for one month or longer?','0=No, 1=Yes, but no longer taking them, 2=Yes, currently taking them');
INSERT INTO "topic" VALUES('Oral contraceptives','Q5','ORAL CONTRACEPTIVES','Q24','Q24 Since January 2000, how many years in total have you used birth control pills?','1=<1 year, 2=1-2, 3=3-4, 4=5-9, 5=10+, 6=Don''t know');
INSERT INTO "topic" VALUES('Oral contraceptives','Q5','ORAL CONTRACEPTIVES','Q23b','Q23 If used birth control pills for one month or longer since January 200, please write in the age you stopped taking the birth control pills. The possibilities for each of the 2 columns are either a *, a blank or a number.','written values see description column');
INSERT INTO "topic" VALUES('Pregnancy','Q1','REPRODUCTIVE HISTORY','PREGNOT','Q32 Ever a time you tried to get preg & couldn''t?','N/Y');
INSERT INTO "topic" VALUES('Pregnancy','Q1','REPRODUCTIVE HISTORY','FDCLOMID','Q33 Ever take fertility drug - Clomid?','A=Yes, Z=Problem');
INSERT INTO "topic" VALUES('Pregnancy','Q1','REPRODUCTIVE HISTORY','FDDANAZ','Q33 Ever take fertility drug - Danazol?','A=Yes, Z=Problem');
INSERT INTO "topic" VALUES('Pregnancy','Q1','REPRODUCTIVE HISTORY','FDDANOC','Q33 Ever take fertility drug - Danocrine?','A=Yes, Z=Problem');
INSERT INTO "topic" VALUES('Pregnancy','Q1','REPRODUCTIVE HISTORY','FDHCG','Q33 Ever take fertility drug - hCG?','A=Yes, Z=Problem');
INSERT INTO "topic" VALUES('Pregnancy','Q1','REPRODUCTIVE HISTORY','FDMILO','Q33 Ever take fertility drug - Milophene?','A=Yes, Z=Problem');
INSERT INTO "topic" VALUES('Pregnancy','Q1','REPRODUCTIVE HISTORY','FDLUPRON','Q33 Ever take fertility drug - Lupron Depot?','A=Yes, Z=Problem');
INSERT INTO "topic" VALUES('Pregnancy','Q1','REPRODUCTIVE HISTORY','FDNOLVA','Q33 Ever take fertility drug - Nolvadex?','A=Yes, Z=Problem');
INSERT INTO "topic" VALUES('Pregnancy','Q1','REPRODUCTIVE HISTORY','FDPERG','Q33 Ever take fertility drug - Pergonal?','A=Yes, Z=Problem');
INSERT INTO "topic" VALUES('Pregnancy','Q1','REPRODUCTIVE HISTORY','FDSERO','Q33 Ever take fertility drug - Serophene?','A=Yes, Z=Problem');
INSERT INTO "topic" VALUES('Pregnancy','Q1','REPRODUCTIVE HISTORY','FDSYNAR','Q33 Ever take fertility drug - Synarel?','A=Yes, Z=Problem');
INSERT INTO "topic" VALUES('Pregnancy','Q1','REPRODUCTIVE HISTORY','FDOTHER','Q33 Ever take fertility drug - Other?','A=Yes, Z=Problem');
INSERT INTO "topic" VALUES('Pregnancy','Q1','REPRODUCTIVE HISTORY','FDNONE','Q33 Ever take fertility drug - None?','A=Yes, Z=Problem');
INSERT INTO "topic" VALUES('Pregnancy','Q1','REPRODUCTIVE HISTORY','TOTLB','Q28 TOTAL NUM OF LIVE BIRTHS','0-13, .A=FP_Blnk, .B=P4BP5ANoP, .C=QB_P5Blnk, .D=QB_P5ANoP, .P=NoPrgs, .Z=GrdPrb');
INSERT INTO "topic" VALUES('Pregnancy','Q1','REPRODUCTIVE HISTORY','TOTSB','Q28 TOTAL NUM OF STILL BIRTHS','0-8, .A=FP_Blnk, .B=P4BP5ANoP, .C=QB_P5Blnk, .D=QB_P5ANoP, .P=NoPrgs, .Z=GrdPrb');
INSERT INTO "topic" VALUES('Pregnancy','Q1','REPRODUCTIVE HISTORY','TOTMS','Q28 TOTAL NUM OF MISCARRIAGES','0-14, .A=FP_Blnk, .B=P4BP5ANoP, .C=QB_P5Blnk, .D=QB_P5ANoP, .L=N22, .P=NoPrgs, .Z=GrdPrb');
INSERT INTO "topic" VALUES('Pregnancy','Q1','REPRODUCTIVE HISTORY','TOTAB','Q28 TOTAL NUM OF ABORTIONS','0-12, .A=FP_Blnk, .B=P4BP5ANoP, .C=QB_P5Blnk, .D=QB_P5ANoP, .P=NoPrgs, .Z=GrdPrb');
INSERT INTO "topic" VALUES('Pregnancy','Q1','REPRODUCTIVE HISTORY','TOTTB','Q28 TOTAL NUM OF TUBAL PREGS','0-2, .A=FP_Blnk, .B=P4BP5ANoP, .C=QB_P5Blnk, .D=QB_P5ANoP, .L=N3, .M=N4, .N=N5, .O=N6, .P=NoPrgs, .Z=GrdPrb');
INSERT INTO "topic" VALUES('Pregnancy','Q1','REPRODUCTIVE HISTORY','TOTFTP','Q28 TOTAL LIV BIRTHS+STILL BIRTHS','0-13, .A=FP_Blnk, .B=P4BP5ANoP, .C=QB_P5Blnk, .D=QB_P5ANoP, .P=NoPrgs, .Z=GrdPrb');
INSERT INTO "topic" VALUES('Pregnancy','Q1','REPRODUCTIVE HISTORY','EVPRG','Q28 EVER PREGNANT','0-1, 0=Nv Prg, 1=Evr Prg, .A=FP_Blnk, .B=P4BP5ANoP, .C=QB_P5Blnk, .D=QB_P5ANoP, .Z=GrdPrb');
INSERT INTO "topic" VALUES('Pregnancy','Q1','REPRODUCTIVE HISTORY','CURPRG','Q28 CURRENTLY PREGNANT','0-1, 0=No, 1=Curpg');
INSERT INTO "topic" VALUES('Pregnancy','Q1','REPRODUCTIVE HISTORY','AGEFMS','Q28 AGE 1ST MISCARRIAGE','14-46, .A=FP_Blnk, .B=P4BP5ANoP, .C=QB_P5Blnk, .D=QB_P5ANoP, .L=N22, .P=NoPrgs, .Q=CP1st, .R=No MS, .S=HCPrgs, .Z=GrdPrb');
INSERT INTO "topic" VALUES('Pregnancy','Q1','REPRODUCTIVE HISTORY','AGEFAB','Q28 AGE 1ST ABORTION','14-46, .A=FP_Blnk, .B=P4BP5ANoP, .C=QB_P5Blnk, .D=QB_P5ANoP, .L=N22, .P=NoPrgs, .Q=CP1st, .R=No MS, .S=HCPrgs, .Z=GrdPrb');
INSERT INTO "topic" VALUES('Pregnancy','Q1','REPRODUCTIVE HISTORY','AGEFFTP','Q27-28 AGE 1ST FULL TERM PREG(LB,SB)','14-46, .A=FP_Blnk, .B=P4BP5ANoP, .C=QB_P5Blnk, .D=QB_P5ANoP, .P=NoPrgs, .Q=CP1st, .R=No FTP, .S=HCPrgs, .Z=GrdPrb');
INSERT INTO "topic" VALUES('Pregnancy','Q1','REPRODUCTIVE HISTORY','AGEFPG','Q27-28 AGE 1ST PREGNANCY','14-46, .A=FP_Blnk, .B=P4BP5ANoP, .C=QB_P5Blnk, .D=QB_P5ANoP, .P=NoPrgs, .Q=CP1st, .S=HCPrgs, .T=NvPrg, .Z=GrdPrb');
INSERT INTO "topic" VALUES('Pregnancy','Q1','REPRODUCTIVE HISTORY','AGELPG','Q28 AGE LAST PREGNANCY(ALL OUTCOMES)','14-46, .A=FP_Blnk, .B=P4BP5ANoP, .C=QB_P5Blnk, .D=QB_P5ANoP, .P=NoPrgs, .Q=CurPrg, .S=HCPrgs, .T=NvPrg, .Z=GrdPrb');
INSERT INTO "topic" VALUES('Pregnancy','Q1','REPRODUCTIVE HISTORY','TOTPRG','Q28 Total Number of Pregnancies','0-15, .A=FP_Blnk, .B=P4BP5ANoP, .C=QB_P5Blnk, .D=QB_P5ANoP, .L=TPrb_N3, .M=TPrb_N3, .N=TPrb_N3, .O=TPrb_N3, .P=NoPrgs, .R=TMS_N22, Z=GrdPrb');
INSERT INTO "topic" VALUES('Pregnancy','Q1','REPRODUCTIVE HISTORY','AGEATLB','Q28 AGE AT FIRST LIVE BIRTH','14-46');
INSERT INTO "topic" VALUES('Pregnancy','Q1','REPRODUCTIVE HISTORY','DESMISC','Q31 Ever taken DES to prevent miscarriage?','N/Y/Z');
INSERT INTO "topic" VALUES('Pregnancy','Q1','REPRODUCTIVE HISTORY','AGEFBF','Q29 AGE 1ST BREAST FED','0-10, 0=0:NvPrg, 1=P_NoLB, 2=LB_NBF, 3=<18, 4=18-19, 5=20-24, 6=25-29, 7=30-34, 8=35-39, 9=40+, 10=BF_DKAG, .A=FP_Blnk, .B=P4BP5ANOP, .C=QB_P5Blnk, .D=QB_P5ANOP, .E=LB_AGBF=Z, .F=QSTNABLE, .P=NoPrgs, .Z=GrdPrb');
INSERT INTO "topic" VALUES('Pregnancy','Q1','REPRODUCTIVE HISTORY','TOTMBF','Q30 TOTAL MTHS BREAST FED','0-10, 0=NvPrg, 1=P_NoLB, 2=LB_NBF, 3=<6M, 4=6-11, 5=12-23, 6=24-35, 7=36-47, 8=48-59, 9=60+, 10=BF_DKAG, .A=FP_Blnk, .B=P4BP5ANOP, .C=QB_P5Blnk, .D=QB_P5ANOP, .E=LB_AGBF=Z, .F=QSTNABLE, .P=NoPrgs, .Z=GrdPrb');
INSERT INTO "topic" VALUES('Pregnancy','Q1','ALCOHOL & TOBACCO USE','SMKPREPRG','Q2, 28, 84, 85 TOTAL YEARS SMOKED PRIOR PREGNANCY','Jan-32');
INSERT INTO "topic" VALUES('Pregnancy','Q1','ALCOHOL & TOBACCO USE','SMKPSTPRG','Q2, 28, 84, 85 TOTAL YEARS SMOKED POST PREGNANCY','Jan-46');
INSERT INTO "topic" VALUES('Pregnancy','Q1','ALCOHOL & TOBACCO USE','SMKPREG','Q2, 28, 84, 85 SMOKING IN RELATION TO FIRST PREGNANCY CATEGORIES','1-4, 1=Never smoker, 2=Smoked postpartum, 3=Smoked prepartum <5y, 4=Smoked prepartum 5+yr');
INSERT INTO "topic" VALUES('Pregnancy','Q2','PREGNANCY UPDATE','PRPREG','Q16 How many times have you been pregnant?','A=0, B=1, C=2, D=3, E=4, F=5, G=6, H=7+, Z=problem');
INSERT INTO "topic" VALUES('Pregnancy','Q2','PREGNANCY UPDATE','PRLSTNON','Q17 Pregnancies since last survey-None','A=Yes');
INSERT INTO "topic" VALUES('Pregnancy','Q2','PREGNANCY UPDATE','PRLSTLIV','Q17 Pregnancies since last survey-Live Birth','A=Yes, Z=problem');
INSERT INTO "topic" VALUES('Pregnancy','Q2','PREGNANCY UPDATE','PRLSTMIS','Q17 Pregnancies since last survey-Miscarriage','A=Yes, Z=problem');
INSERT INTO "topic" VALUES('Pregnancy','Q2','PREGNANCY UPDATE','PRLSTABR','Q17 Pregnancies since last survey-Induced Abortion','A=Yes, Z=problem');
INSERT INTO "topic" VALUES('Pregnancy','Q2','PREGNANCY UPDATE','PRLSTECT','Q17 Pregnancies since last survey-Ectopic Preg','A=Yes');
INSERT INTO "topic" VALUES('Pregnancy','Q2','PREGNANCY UPDATE','PRLSTSTL','Q17 Pregnancies since last survey-Stillbirth','A=Yes, Z=problem');
INSERT INTO "topic" VALUES('Pregnancy','Q2','PREGNANCY UPDATE','PRLSTCUR','Q17 Pregnancies since last survey-Currently Preg','A=Yes');
INSERT INTO "topic" VALUES('Pregnancy','Q2','PREGNANCY UPDATE','PRNAUS','Q18 How many pregs have you had nausea/vomiting?','A=0, B=1, C=2, D=3, E=4, F=5, G=6, H=7+');
INSERT INTO "topic" VALUES('Pregnancy','Q2','PREGNANCY UPDATE','PRNAUSRX','Q19 Have you received treatment for nausea/vomiting?','Y/N');
INSERT INTO "topic" VALUES('Pregnancy','Q2','PREGNANCY UPDATE','PRNAUSMR','Q20 Did you need treatment for most recent preg?','Y/N');
INSERT INTO "topic" VALUES('Pregnancy','Q2','PREGNANCY UPDATE','PRECL','Q21 In all pregs, were you diagnosed w/pre-eclampsia?','Y/N');
INSERT INTO "topic" VALUES('Pregnancy','Q2','PREGNANCY UPDATE','PRECLMMR','Q22 Were you diagnosed for most recent preg?','Y/N');
INSERT INTO "topic" VALUES('Pregnancy','Q4','SMOKING & PREGNANCY','SPEVPRGX','Q46 GENERATED VARIABLE FOR Ever pregnant?','Y=Yes, N=No, U=Unk, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Pregnancy','Q4','SMOKING & PREGNANCY','SPOWNBX','Q46 GENERATED VARIABLE FOR Before preg cigs per day','A=Did not smoke, B=<10, C=10-19, D=20+, V=Questionnaire section blank, Z=Multiple responses');
INSERT INTO "topic" VALUES('Pregnancy','Q4','SMOKING & PREGNANCY','SPOWNDX','Q46 GENERATED VARIABLE FOR During preg cigs per day','A=Did not smoke, B=<10, C=10-19, D=20+, V=Questionnaire section blank, Z=Multiple responses');
INSERT INTO "topic" VALUES('Pregnancy','Q4','SMOKING & PREGNANCY','SPNOSMBX','Q46 GENERATED VARIABLE FOR No-one smoked around me before pregnancy','Y=Yes, U=Wrong page #12, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Pregnancy','Q4','SMOKING & PREGNANCY','SPNOSMDX','Q46 GENERATED VARIABLE FOR No-one smoked around me during pregnancy','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Pregnancy','Q4','SMOKING & PREGNANCY','SPHOMEBX','Q46 GENERATED VARIABLE FOR Others at home smoked before pregnancy','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Pregnancy','Q4','SMOKING & PREGNANCY','SPHOMEDX','Q46 GENERATED VARIABLE FOR Others at home smoked during pregnancy','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Pregnancy','Q4','SMOKING & PREGNANCY','SPWORKBX','Q46 GENERATED VARIABLE FOR Others at work smoked before pregnancy','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Pregnancy','Q4','SMOKING & PREGNANCY','SPWORKDX','Q46 GENERATED VARIABLE FOR Others at work smoked during pregnancy','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Pregnancy','Q4','SMOKING & PREGNANCY','SPOTHRBX','Q46 GENERATED VARIABLE FOR Others smoked around me before pregnancy','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Pregnancy','Q4','SMOKING & PREGNANCY','SPOTHRDX','Q46 GENERATED VARIABLE FOR Others smoked around me during pregnancy','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Pregnancy','Q4','SMOKING & PREGNANCY','SBPRG1X','Q46 GENERATED VARIABLE FOR Did first pregnancy result in a live birth?','Y=Yes, N=No, U=Unk, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Pregnancy','Q4','SMOKING & PREGNANCY','SBEVLBX','Q46 GENERATED VARIABLE FOR Ever preg & live birth?','Y=Yes, N=No, U=Unk, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Pregnancy','Q4','SMOKING & PREGNANCY','SBOWNBX','Q46 GENERATED VARIABLE FOR Own smokg before live birth cigs per day','A=Did not smoke, B=<10, C=10-19, D=20+, V=Questionnaire section blank, Z=Multiple responses');
INSERT INTO "topic" VALUES('Pregnancy','Q4','SMOKING & PREGNANCY','SBOWNDX','Q46 GENERATED VARIABLE FOR Own smokg during live birth cigs per day','A=Did not smoke, B=<10, C=10-19, D=20+, V=Questionnaire section blank, Z=Multiple responses');
INSERT INTO "topic" VALUES('Pregnancy','Q4','SMOKING & PREGNANCY','SBNOSMBX','Q46 GENERATED VARIABLE FOR No-one smoked before live birth','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Pregnancy','Q4','SMOKING & PREGNANCY','SBNOSMDX','Q46 GENERATED VARIABLE FOR No-one smoked during live birth','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Pregnancy','Q4','SMOKING & PREGNANCY','SBHOMEBX','Q46 GENERATED VARIABLE FOR Others at home smoked before live birth','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Pregnancy','Q4','SMOKING & PREGNANCY','SBHOMEDX','Q46 GENERATED VARIABLE FOR Others at home smoked during live birth','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Pregnancy','Q4','SMOKING & PREGNANCY','SBWORKBX','Q46 GENERATED VARIABLE FOR Others at work smoked before live birth','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Pregnancy','Q4','SMOKING & PREGNANCY','SBWORKDX','Q46 GENERATED VARIABLE FOR Others at work smoked during live birth','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Pregnancy','Q4','SMOKING & PREGNANCY','SBOTHRBX','Q46 GENERATED VARIABLE FOR Others smoked around me before live birth','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Pregnancy','Q4','SMOKING & PREGNANCY','SBOTHRDX','Q46 GENERATED VARIABLE FOR Others smoked around me during live birth','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Medications','Q1','REPRODUCTIVE HISTORY','FDCLOMID','Q33 Ever take fertility drug - Clomid?','A=Yes, Z=Problem');
INSERT INTO "topic" VALUES('Medications','Q1','REPRODUCTIVE HISTORY','FDDANAZ','Q33 Ever take fertility drug - Danazol?','A=Yes, Z=Problem');
INSERT INTO "topic" VALUES('Medications','Q1','REPRODUCTIVE HISTORY','FDDANOC','Q33 Ever take fertility drug - Danocrine?','A=Yes, Z=Problem');
INSERT INTO "topic" VALUES('Medications','Q1','REPRODUCTIVE HISTORY','FDHCG','Q33 Ever take fertility drug - hCG?','A=Yes, Z=Problem');
INSERT INTO "topic" VALUES('Medications','Q1','REPRODUCTIVE HISTORY','FDMILO','Q33 Ever take fertility drug - Milophene?','A=Yes, Z=Problem');
INSERT INTO "topic" VALUES('Medications','Q1','REPRODUCTIVE HISTORY','FDLUPRON','Q33 Ever take fertility drug - Lupron Depot?','A=Yes, Z=Problem');
INSERT INTO "topic" VALUES('Medications','Q1','REPRODUCTIVE HISTORY','FDNOLVA','Q33 Ever take fertility drug - Nolvadex?','A=Yes, Z=Problem');
INSERT INTO "topic" VALUES('Medications','Q1','REPRODUCTIVE HISTORY','FDPERG','Q33 Ever take fertility drug - Pergonal?','A=Yes, Z=Problem');
INSERT INTO "topic" VALUES('Medications','Q1','REPRODUCTIVE HISTORY','FDSERO','Q33 Ever take fertility drug - Serophene?','A=Yes, Z=Problem');
INSERT INTO "topic" VALUES('Medications','Q1','REPRODUCTIVE HISTORY','FDSYNAR','Q33 Ever take fertility drug - Synarel?','A=Yes, Z=Problem');
INSERT INTO "topic" VALUES('Medications','Q1','REPRODUCTIVE HISTORY','FDOTHER','Q33 Ever take fertility drug - Other?','A=Yes, Z=Problem');
INSERT INTO "topic" VALUES('Medications','Q1','REPRODUCTIVE HISTORY','FDNONE','Q33 Ever take fertility drug - None?','A=Yes, Z=Problem');
INSERT INTO "topic" VALUES('Medications','Q1','REPRODUCTIVE HISTORY','DESMISC','Q31 Ever taken DES to prevent miscarriage?','N/Y/Z');
INSERT INTO "topic" VALUES('Medications','Q1','HEALTH HISTORY','MEDASPY','Q66 How many total years taking aspirin?','A=Not reg, B=<1, C=1, D=2, E=3-4, F=5-9, G=10+, H=Regular user but duration unknown, Z=Problem ');
INSERT INTO "topic" VALUES('Medications','Q1','HEALTH HISTORY','MEDASPD','Q66 How often on average taking aspirin?','A=1-3 , B=4-6, C=Every day, D=Regular user but frequency of use unknown, X=Didn''t take regularly, Z=Problem');
INSERT INTO "topic" VALUES('Medications','Q1','HEALTH HISTORY','MEDACEY','Q66 How many total years taking acetaminophen?','A=Not reg, B=<1, C=1, D=2, E=3-4, F=5-9, G=10+, H=Regular user but duration unknown, Z=Problem ');
INSERT INTO "topic" VALUES('Medications','Q1','HEALTH HISTORY','MEDACED','Q66 How often on average taking acetaminophen?','A=1-3 , B=4-6, C=Every day, D=Regular user but frequency of use unknown, X=Didn''t take regularly, Z=Problem');
INSERT INTO "topic" VALUES('Medications','Q1','HEALTH HISTORY','MEDIBUY','Q66 How many total years taking ibuprofen?','A=Not reg, B=<1, C=1, D=2, E=3-4, F=5-9, G=10+, H=Regular user but duration unknown, Z=Problem ');
INSERT INTO "topic" VALUES('Medications','Q1','HEALTH HISTORY','MEDIBUD','Q66 How often on average taking ibuprofen?','A=1-3, B=4-6, C=Every day, D=Regular user but frequency of use unknown, X=Didn''t take regularly, Z=Problem');
INSERT INTO "topic" VALUES('Medications','Q1','HEALTH HISTORY','MEDTAGY','Q66 How many total years taking tagamet?','A=Not reg, B=<1, C=1, D=2, E=3-4, F=5-9, G=10+, H=Regular user but duration unknown, Z=Problem ');
INSERT INTO "topic" VALUES('Medications','Q1','HEALTH HISTORY','MEDTAGD','Q66 How often on average taking tagamet?','A=1-3 , B=4-6, C=Every day, D=Regular user but frequency of use unknown, X=Didn''t take regularly, Z=Problem');
INSERT INTO "topic" VALUES('Medications','Q1','HEALTH HISTORY','MEDRESY','Q66 How many total years taking reserpine?','A=Not reg, B=<1, C=1, D=2, E=3-4, F=5-9, G=10+, H=Regular user but duration unknown, Z=Problem ');
INSERT INTO "topic" VALUES('Medications','Q1','HEALTH HISTORY','MEDRESD','Q66 How often on average taking reserpine?','A=1-3 , B=4-6, C=Every day, D=Regular user but frequency of use unknown, X=Didn''t take regularly, Z=Problem');
INSERT INTO "topic" VALUES('Medications','Q1','HEALTH HISTORY','MEDWTRY','Q66 How many total years taking water pills/HBP?','A=Not reg, B=<1, C=1, D=2, E=3-4, F=5-9, G=10+, H=Regular user but duration unknown, Z=Problem ');
INSERT INTO "topic" VALUES('Medications','Q1','HEALTH HISTORY','MEDWTRD','Q66 How often on average taking water pills/HBP?','A=1-3 , B=4-6, C=Every day, D=Regular user but frequency of use unknown, X=Didn''t take regularly, Z=Problem');
INSERT INTO "topic" VALUES('Medications','Q1','HEALTH HISTORY','MEDHBPY','Q66 How many total years taking high blood prs?','A=Not reg, B=<1, C=1, D=2, E=3-4, F=5-9, G=10+, H=Regular user but duration unknown, Z=Problem ');
INSERT INTO "topic" VALUES('Medications','Q1','HEALTH HISTORY','MEDHBPD','Q66 How often on average taking high blood prs?','A=1-3 , B=4-6, C=Every day, D=Regular user but frequency of use unknown, X=Didn''t take regularly, Z=Problem');
INSERT INTO "topic" VALUES('Medications','Q1','HEALTH HISTORY','MEDCALY','Q66 How many total years taking calcium?','A=Not reg, B=<1, C=1, D=2, E=3-4, F=5-9, G=10+, H=Regular user but duration unknown, Z=Problem ');
INSERT INTO "topic" VALUES('Medications','Q1','HEALTH HISTORY','MEDCALD','Q66 How often on average taking calcium?','A=1-3 , B=4-6, C=Every day, D=Regular user but frequency of use unknown, X=Didn''t take regularly, Z=Problem');
INSERT INTO "topic" VALUES('Medications','Q1','HEALTH HISTORY','MEDNSAY','Q66 Total years taking any NSAID','A=Not reg, B=<1, C=1, D=2, E=3-4, F=5-9, G=10+, H=Regular user but duration unknown, Z=Problem ');
INSERT INTO "topic" VALUES('Medications','Q1','HEALTH HISTORY','MEDNSAD','Q66 Days/wk taking any NSAID','A=1-3 , B=4-6, C=Every day, D=Regular user but frequency of use unknown, X=Didn''t take regularly, Z=Problem');
INSERT INTO "topic" VALUES('Medications','Q3','MEDICATION','INSULIN','Q24 Daily Insulin for 2mths?','Y/N/Z=Unk');
INSERT INTO "topic" VALUES('Medications','Q3','MEDICATION','ORALHYP','Q24 Daily oral hypoglycemic for 2mths?','Y/N/Z=Unk');
INSERT INTO "topic" VALUES('Medications','Q3','MEDICATION','DIURET','Q24 Daily Thiazide diuretic for 2mths?','Y/N/Z=Unk');
INSERT INTO "topic" VALUES('Medications','Q3','MEDICATION','LASIX','Q24 Daily Lasix for 2mths?','Y/N/Z=Unk');
INSERT INTO "topic" VALUES('Medications','Q3','MEDICATION','CALCM','Q24 Daily Calcium blocker for 2mths?','Y/N/Z=Unk');
INSERT INTO "topic" VALUES('Medications','Q3','MEDICATION','ACEINHIB','Q24 Daily ACE inhibitor for 2mths?','Y/N/Z=Unk');
INSERT INTO "topic" VALUES('Medications','Q3','MEDICATION','OTHBPRM','Q24 Daily other hi bpr drug for 2mths?','Y/N/Z=Unk');
INSERT INTO "topic" VALUES('Medications','Q3','MEDICATION','TAGAMET','Q24 Daily Cimetidine (Tagamet) for 2mths?','Y/N/Z=Unk');
INSERT INTO "topic" VALUES('Medications','Q3','MEDICATION','H2BLK','Q24 Daily other H2 blocker for 2mths?','Y/N/Z=Unk');
INSERT INTO "topic" VALUES('Medications','Q3','MEDICATION','TAMOX','Q24 Daily Tamoxifen for 2mths?','Y/N/Z=Unk');
INSERT INTO "topic" VALUES('Medications','Q3','MEDICATION','RALOX','Q24 Daily Raloxifene for 2mths?','Y/N/Z=Unk');
INSERT INTO "topic" VALUES('Medications','Q3','MEDICATION','STEROID','Q24 Daily oral steroids for 2mths?','Y/N/Z=Unk');
INSERT INTO "topic" VALUES('Medications','Q3','MEDICATION','BRONDIL','Q24 Daily inhaled bronchodilator for 2mths?','Y/N/Z=Unk');
INSERT INTO "topic" VALUES('Medications','Q3','MEDICATION','CHOLMED','Q24 Daily cholesterol-lower drug for 2mths?','Y/N/Z=Unk');
INSERT INTO "topic" VALUES('Medications','Q3','MEDICATION','ANTIDEP','Q24 Daily antidepressant for 2mths?','Y/N/Z=Unk');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','MEDBABW','Q5 Number of baby aspirin per week you take regularly (at least once a week)?','A=0 or <1, B=1-2, C=3-4, D=5-6, E=7-8, F=9-10, G=11-12, H=13-14, I=15-21, J=22-28, K=29+, Z=Problem');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','MEDASPW','Q5 Number of aspirin or aspirin-containing product per week you take regularly (at least once a week)?','A=0 or <1, B=1-2, C=3-4, D=5-6, E=7-8, F=9-10, G=11-12, H=13-14, I=15-21, J=22-28, K=29+, Z=Problem');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','MEDIBUW','Q5 Number of Ibuprofen per week you take regularly (at least once a week)?','A=0 or <1, B=1-2, C=3-4, D=5-6, E=7-8, F=9-10, G=11-12, H=13-14, I=15-21, J=22-28, K=29+, Z=Problem');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','MEDOTHW','Q5 Number of NSAID per week you take regularly (at least once a week)?','A=0 or <1, B=1-2, C=3-4, D=5-6, E=7-8, F=9-10, G=11-12, H=13-14, I=15-21, J=22-28, K=29+, Z=Problem');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','MEDCOXW','Q5 Number of Cox-2 inhimitor per week you take regularly (at least once a week)?','A=0 or <1, B=1-2, C=3-4, D=5-6, E=7-8, F=9-10, G=11-12, H=13-14, I=15-21, J=22-28, K=29+, Z=Problem');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','MEDACEW','Q5 Number of acetaminophen per week you take regularly (at least once a week)?','A=0 or <1, B=1-2, C=3-4, D=5-6, E=7-8, F=9-10, G=11-12, H=13-14, I=15-21, J=22-28, K=29+, Z=Problem');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','STPBAB','Q6 Did you stop regular use of baby aspirin? This is answer of never took regularly or yes stopped regular use.','N=Never took regularly or didn’t stop, Y=Yes stopped regular use, Z=Problem');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','STPASP','Q6 Did you stop regular use of aspirin or aspirin containing product? This is answer of never took regularly or yes stopped regular use.','N=Never took regularly or didn’t stop, Y=Yes stopped regular use, Z=Problem');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','STPIBU','Q6 Did you stop regular use of Ibuprofen? This is answer of never took regularly or yes stopped regular use.','N=Never took regularly or didn’t stop, Y=Yes stopped regular use, Z=Problem');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','STPOTH','Q6 Did you stop regular use of NSAID? This is answer of never took regularly or yes stopped regular use.','N=Never took regularly or didn’t stop, Y=Yes stopped regular use, Z=Problem');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','STPCOX','Q6 Did you stop regular use of Cox-2 inhibitor? This is answer of never took regularly or yes stopped regular use.','N=Never took regularly or didn’t stop, Y=Yes stopped regular use, Z=Problem');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','STPACE','Q6 Did you stop regular use of acetaminophen? This is answer of never took regularly or yes stopped regular use.','N=Never took regularly or didn’t stop, Y=Yes stopped regular use, Z=Problem');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','STOPBABA','Q6 Did you stop baby aspirin because your condition improved?','Y=Yes');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','STOPASPA','Q6 Did you stop aspirin or aspirin containing product because your condition improved?','Y=Yes');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','STOPIBUA','Q6 Did you stop Ibuprofen because your condition improved?','Y=Yes');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','STOPOTHA','Q6 Did you stop NSAID because your condition improved?','Y=Yes');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','STOPCOXA','Q6 Did you stop Cox-2 inhibitor because your condition improved?','Y=Yes');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','STOPACEA','Q6 Did you stop acetaminophen because your condition improved?','Y=Yes');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','STOPBABB','Q6 Did you stop baby aspirin becaue it didn''t work?','Y=Yes');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','STOPASPB','Q6 Did you stop aspirin or aspirin containing product because it didn''t work?','Y=Yes');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','STOPIBUB','Q6 Did you stop Ibuprofen because it didn''t work?','Y=Yes');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','STOPOTHB','Q6 Did you stop NSAID because it didn''t work?','Y=Yes');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','STOPCOXB','Q6 Did you stop Cox-2 because it didn''t work?','Y=Yes');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','STOPACEB','Q6 Did you stop acetaminophen because it didn''t work?','Y=Yes');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','STOPBABC','Q6 Did you stop baby aspirin because of side effects?','Y=Yes');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','STOPASPC','Q6 Did you stop aspirin or aspirin containing product because of side effects?','Y=Yes');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','STOPIBUC','Q6 Did you stop Ibuprofen because of side effects?','Y=Yes');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','STOPOTHC','Q6 Did you stop NSAID because of side effects?','Y=Yes');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','STOPCOXC','Q6 Did you stop Cox-2 inhibitor because of side effects?','Y=Yes');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','STOPACEC','Q6 Did you stop acetaminophen because of side effects?','Y=Yes');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','STOPBABD','Q6 Did you stop baby aspirin because you heard of side effects?','Y=Yes');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','STOPASPD','Q6 Did you stop aspirin or aspirin containing product because you heard of side effects?','Y=Yes');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','STOPIBUD','Q6 Did you stop Ibuprofen because you heard of side effects?','Y=Yes');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','STOPOTHD','Q6 Did you stop NSAID because you heard of side effects?','Y=Yes');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','STOPCOXD','Q6 Did you stop Cox-2 because you heard of side effects?','Y=Yes');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','STOPACED','Q6 Did you stop acetaminophen because you heard of side effects?','Y=Yes');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','STOPBABE','Q6 Did you stop baby aspirin because it became not available?','Y=Yes');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','STOPASPE','Q6 Did you stop aspirin or aspirin containing product because it became not available?','Y=Yes');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','STOPIBUE','Q6 Did you stop Ibuprofen because it became not available?','Y=Yes');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','STOPOTHE','Q6 Did you stop NSAID because it became not available?','Y=Yes');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','STOPCOXE','Q6 Did you stop Cox-2 because it became not available?','Y=Yes');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','STOPACEE','Q6 Did you stop acetaminophen because it became not available?','Y=Yes');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','STOPBABF','Q6 Did you stop baby aspirin because of some other reason?','Y=Yes');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','STOPASPF','Q6 Did you stop aspirin or aspirin containing product because of some other reason?','Y=Yes');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','STOPIBUF','Q6 Did you stop Ibuprofen because of some other reason?','Y=Yes');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','STOPOTHF','Q6 Did you stop NSAID because of some other reason?','Y=Yes');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','STOPCOXF','Q6 Did you stop Cox-2 inhimitor because of some other reason?','Y=Yes');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','STOPACEF','Q6 Did you stop acetaminophen because of some other reason?','Y=Yes');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','MEDSTAT','Q7 In the past 3 years, have you taken statin medications?','* A=No, B=Yes reg, C=Yes but not reg, Z=Problem');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','MEDSTER','Q7 In the past 3 years, have you taken steroid  medications in pill form?','* A=No, B=Yes reg, C=Yes but not reg, Z=Problem');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','MEDISTER','Q8 During the past year have you used inhaled steroids at least once a week for treatment of breathing problems such as asthma, COPD, bronchitis or emphysema?','Y=Yes, N=No, Z=Problem');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','MEDIANTI','Q8 During the past year have you used other inhaled anti-inflammatory medications at least once a week for treatment of breathing problems such as asthma, COPD, bronchitis or emphysema?','Y=Yes, N=No, Z=Problem');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','MEDOANTI','Q8 During the past year have you used oral anti-inflammatory medications (not steroids) at least once a week for treatment of breathing problems such as asthma, COPD, bronchitis or emphysema?','Y=Yes, N=No, Z=Problem');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','MEDIBRON','Q8 During the past year have you used an inhaled bronchodilator at least once a week for treatment of breathing problems such as asthma, COPD, bronchitis or emphysema?','Y=Yes, N=No, Z=Problem');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','MEDILNGB','Q8 During the past year have you used a long-acting  inhaled bronchodilator at least once a week for treatment of breathing problems such as asthma, COPD, bronchitis or emphysema?','Y=Yes, N=No, Z=Problem');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','MEDABIO','Q9 In the last 10 years, for how many weeks in total did you take antibiotics?','* A=Didn''t take, B=1-2 Wks, C=3-9, D=10-19, E=20-49, F=50+wks, Z=Problem');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','RALTAMEV','Q10 Have you ever used raloxifene or tamoxifen? (No or Yes)','Y=Yes, N=No, Z=Problem');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','RALM','Q10 How many months in total have you used raloxifene?','A=No use, B=1-6 Mos, C=7-12, D=13-24, E=25-60, F=60 mos +, Z=Problem');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','TAMM','Q10 How many months in total have you used tamoxifen?','A=No use, B=1-6 Mos, C=7-12, D=13-24, E=25-60, F=60 mos +, Z=Problem');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','RALTAMC','Q10 Are you currently using either raloxifene or tamoxifen?','A=No, not currently, B=Yes Raloxifene, C=Yes Tamoxifen, Z=Problem');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','OTCHORM','Q11 Are you currently using over-the counter hormonal preparations such as herbal, natural or soy-based products? ( No or Yes)','Y=Yes, N=No, Z=Problem');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','OTCHORMA','Q11 Currently using soy estrogen pills.','Y=Yes');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','OTCHORMB','Q11 Currently using dong quai.','Y=Yes');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','OTCHORMC','Q11 Currently using natural progesterone cream or wild yam cream.','Y=Yes');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','OTCHORMD','Q11 Currently using black cohosh.','Y=Yes');
INSERT INTO "topic" VALUES('Medications','Q4','MEDICATIONS','OTCHORME','Q11 Currently using flaxseed or linseed oil.','Y=Yes');
INSERT INTO "topic" VALUES('Medications','Q4','HEALTH','DBINS','Q16 Are you currently taking insulin? (No or Yes)','Y=Yes, N=No');
INSERT INTO "topic" VALUES('Medications','Q4','HEALTH','DBINSY','Q16 For how many years have you been taking insulin? ','A=<1yr, B=1-4, C=5-9, D=10-14, E=15-19, F=20-29, G=30+');
INSERT INTO "topic" VALUES('Medications','Q4','HEALTH','DBPIL','Q17 Are you currently taking pills to lower your blood sugar? These are sometimes called oral hypoglycemic agents. (No or Yes)','Y=Yes, N=No, C=DK because participating research study');
INSERT INTO "topic" VALUES('Medications','Q4','HEALTH','DBPILY','Q17 For how many years have you been taking these pills to lower your blood pressure? ','A=<1yr, B=1-4, C=5-9, D=10-14, E=15-19, F=20-29, G=30+');
INSERT INTO "topic" VALUES('Medications','Q5','MEDICATIONS','Q20a','Q20 Do you CURRENTLY take ''baby'' or low-dose aspirin regularly (at least once a week)? Answer of No or total tablets per week.','00=No or <1/week, 01=1-2, 02=3-4, 03=5-6, 04=7-8, 05=9-10, 06=11-12, 07=13-14, 08=15-21, 09=22-28, 10=29+');
INSERT INTO "topic" VALUES('Medications','Q5','MEDICATIONS','Q20b','Q20 Do you CURRENTLY take aspirin or aspirin containing product regularly (at least once a week)? Answer of No or total tablets per week.','00=No or <1/week, 01=1-2, 02=3-4, 03=5-6, 04=7-8, 05=9-10, 06=11-12, 07=13-14, 08=15-21, 09=22-28, 10=29+');
INSERT INTO "topic" VALUES('Medications','Q5','MEDICATIONS','Q20c','Q20 Do you CURRENTLY take ibuprofen regularly (at least once a week)? Answer of No or total tablets per week.','00=No or <1/week, 01=1-2, 02=3-4, 03=5-6, 04=7-8, 05=9-10, 06=11-12, 07=13-14, 08=15-21, 09=22-28, 10=29+');
INSERT INTO "topic" VALUES('Medications','Q5','MEDICATIONS','Q20d','Q20 Do you CURRENTLY take naproxen, ketoprofen, meloxicam or other non-steroidal regularly (at least once a week)? Answer of No or total tablets per week.','00=No or <1/week, 01=1-2, 02=3-4, 03=5-6, 04=7-8, 05=9-10, 06=11-12, 07=13-14, 08=15-21, 09=22-28, 10=29+');
INSERT INTO "topic" VALUES('Medications','Q5','MEDICATIONS','Q20e','Q20 Do you CURRENTLY take Cox-2 inhibitor regularly (at least once a week)? Answer of No or total tablets per week.','00=No or <1/week, 01=1-2, 02=3-4, 03=5-6, 04=7-8, 05=9-10, 06=11-12, 07=13-14, 08=15-21, 09=22-28, 10=29+');
INSERT INTO "topic" VALUES('Medications','Q5','MEDICATIONS','Q20f','Q20 Do you CURRENTLY take acetaminophen regularly (at least once a week)? Answer of No or total tablets per week.','00=No or <1/week, 01=1-2, 02=3-4, 03=5-6, 04=7-8, 05=9-10, 06=11-12, 07=13-14, 08=15-21, 09=22-28, 10=29+');
INSERT INTO "topic" VALUES('Medications','Q5','MEDICATIONS','Q20g','Q20 Do you CURRENTLY take prescription pain medication with an opiate and acetaminophen such as hydrocodone with acetaminophen or oxycodone with acetaminophen regularly (at least once a week)? Answer of No or total tablets per week.','00=No or <1/week, 01=1-2, 02=3-4, 03=5-6, 04=7-8, 05=9-10, 06=11-12, 07=13-14, 08=15-21, 09=22-28, 10=29+');
INSERT INTO "topic" VALUES('Medications','Q5','MEDICATIONS','Q21','Q21 Do you CURRENTLY take statin medications?','0=No, 1=Yes, regularly, 3=Yes, not regularly');
INSERT INTO "topic" VALUES('Medications','Q5','MEDICATIONS','Q22a','Q22 Have you EVER taken bisphosphonates or raloxifene to prevent or treat osteoporosis?','0=No, 1=Yes, 2=Don''t know');
INSERT INTO "topic" VALUES('Medications','Q5','MEDICATIONS','Q22b','Q22 Are you currently taking bisphosphonates, answer either no or years of use.','0=No, 1=<1 year, 2=1-2, 3=3-4, 4=5+');
INSERT INTO "topic" VALUES('Medications','Q5','MEDICATIONS','Q22c','Q22 Are you currently taking raloxifene, answer either no or years of use.','0=No, 1=<1 year, 2=1-2, 3=3-4, 4=5+');
INSERT INTO "topic" VALUES('Medications','Q5','MEDICAL CONDITIONS','Q43b_Ever','Q43 Have you ever taken medication for a heart attack?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Medications','Q5','MEDICAL CONDITIONS','Q43b_Cur','Q43 Are you currently taking medication for a heart attack?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Medications','Q5','MEDICAL CONDITIONS','Q43c_Ever','Q43 Have you ever taken medication for a stroke?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Medications','Q5','MEDICAL CONDITIONS','Q43c_Cur','Q43 Are you currently taking medication for a stroke?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Medications','Q5','MEDICAL CONDITIONS','Q43d_Ever','Q43 Have you ever taken medication for a deep vein thrombosis?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Medications','Q5','MEDICAL CONDITIONS','Q43d_Cur','Q43 Are you currently taking medication for a deep vein thrombosis?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Medications','Q5','MEDICAL CONDITIONS','Q43e_Ever','Q43 Have you ever taken medication for COPD?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Medications','Q5','MEDICAL CONDITIONS','Q43e_Cur','Q43 Are you currently taking medication for COPD?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Medications','Q5','MEDICAL CONDITIONS','Q43f_Ever','Q43 Have you ever taken medication for osteoporosis?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Medications','Q5','MEDICAL CONDITIONS','Q43f_Cur','Q43 Are you currently taking medication for osteoporosis?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Medications','Q5','MEDICAL CONDITIONS','Q43g_Ever','Q43 Have you ever taken medication for pneumonia?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Medications','Q5','MEDICAL CONDITIONS','Q43g_Cur','Q43 Are you currently taking medication for pneumonia?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Medications','Q5','MEDICAL CONDITIONS','Q43h_Ever','Q43 Have you ever taken medication for Parkinson''s disease?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Medications','Q5','MEDICAL CONDITIONS','Q43h_Cur','Q43 Are you currently taking medication for Parkinson''s disease?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Medications','Q5','MEDICAL CONDITIONS','Q43i_Ever','Q43 Have you ever taken medication for depression?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Medications','Q5','MEDICAL CONDITIONS','Q43i_Cur','Q43 Are you currently taking medication for depression?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Medications','Q5','MEDICAL CONDITIONS','Q43j_Ever','Q43 Have you ever taken medication for shingles?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Medications','Q5','MEDICAL CONDITIONS','Q43j_Cur','Q43 Are you currently taking medication for shingles?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Medications','Q5','MEDICAL CONDITIONS','Q43k_Ever','Q43 Have you ever taken medication for an ulcer?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Medications','Q5','MEDICAL CONDITIONS','Q43k_Cur','Q43 Are you currently taking medication for an ulcer?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Medications','Q5','MEDICAL CONDITIONS','Q43l_Ever','Q43 Have you ever taken medication for kidney stones?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Medications','Q5','MEDICAL CONDITIONS','Q43l_Cur','Q43 Are you currently taking medication for kidney stones?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Medications','Q5','MEDICAL CONDITIONS','Q43m_Ever','Q43 Have you ever taken medication for kidney disease?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Medications','Q5','MEDICAL CONDITIONS','Q43m_Cur','Q43 Are you currently taking medication for kidney disease?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Medications','Q5','MEDICAL CONDITIONS','Q43n_Ever','Q43 Have you ever taken medication for chronic fatigue syndrome?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Medications','Q5','MEDICAL CONDITIONS','Q43n_Cur','Q43 Are you currently taking medication for chronic fatigue syndrome?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Medications','Q5','MEDICAL CONDITIONS','Q43o_Ever','Q43 Have you ever taken medication for osteoarthritis?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Medications','Q5','MEDICAL CONDITIONS','Q43o_Cur','Q43 Are you currently taking medication for osteoarthritis?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Medications','Q5','MEDICAL CONDITIONS','Q43p_Ever','Q43 Have you ever taken medication for rheumatoid arthritis?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Medications','Q5','MEDICAL CONDITIONS','Q43p_Cur','Q43 Are you currently taking medication for rheumatoid arthritis?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Medications','Q5','MEDICAL CONDITIONS','Q43q_Ever','Q43 Have you ever taken medication for lupus?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Medications','Q5','MEDICAL CONDITIONS','Q43q_Cur','Q43 Are you currently taking medication for lupus?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Medications','Q5','MEDICAL CONDITIONS','Q43r_Ever','Q43 Have you ever taken medication for IBD or Crohn''s disease?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Medications','Q5','MEDICAL CONDITIONS','Q43r_Cur','Q43 Are you currently taking medication for IBD or Crohn''s disease?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Medications','Q5','MEDICAL CONDITIONS','Q43s_Ever','Q43 Have you ever taken medication for multiple sclerosis?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Medications','Q5','MEDICAL CONDITIONS','Q43s_Cur','Q43 Are you currently taking medication for multiple sclerosis?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Medications','Q5','MEDICAL CONDITIONS','Q43t_Ever','Q43 Have you ever taken medication for psoriasis?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Medications','Q5','MEDICAL CONDITIONS','Q43t_Cur','Q43 Are you currently taking medication for psoriasis?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Medications','Q5','MEDICAL CONDITIONS','Q43a_Ever','Q43 Have you ever taken medication for hypertension?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Medications','Q5','MEDICAL CONDITIONS','Q43a_Cur','Q43 Are you currently taking medication for hypertension?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','FMP','Q21 AGE AT MENARCHE','1-10, 1=NoFMP, 2=<10, 3=10, 4=11, 5=12, 6=13, 7=14, 8=15, 9=16, 10=17+, .A=FP_Blnk, .B=P4B_P5A, .C=Q Blnk, .D=M_Ans, .E=Unk');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','PREGNOT','Q32 Ever a time you tried to get preg & couldn''t?','N/Y');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','FDCLOMID','Q33 Ever take fertility drug - Clomid?','A=Yes, Z=Problem');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','FDDANAZ','Q33 Ever take fertility drug - Danazol?','A=Yes, Z=Problem');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','FDDANOC','Q33 Ever take fertility drug - Danocrine?','A=Yes, Z=Problem');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','FDHCG','Q33 Ever take fertility drug - hCG?','A=Yes, Z=Problem');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','FDMILO','Q33 Ever take fertility drug - Milophene?','A=Yes, Z=Problem');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','FDLUPRON','Q33 Ever take fertility drug - Lupron Depot?','A=Yes, Z=Problem');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','FDNOLVA','Q33 Ever take fertility drug - Nolvadex?','A=Yes, Z=Problem');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','FDPERG','Q33 Ever take fertility drug - Pergonal?','A=Yes, Z=Problem');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','FDSERO','Q33 Ever take fertility drug - Serophene?','A=Yes, Z=Problem');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','FDSYNAR','Q33 Ever take fertility drug - Synarel?','A=Yes, Z=Problem');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','FDOTHER','Q33 Ever take fertility drug - Other?','A=Yes, Z=Problem');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','FDNONE','Q33 Ever take fertility drug - None?','A=Yes, Z=Problem');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','PRDSTOP','Q34 Have periods stopped permanently?','A=No, B=Yes w/i 6 mth, C=Yes > 6 mth ago, D=On OC’s to have periods (post meno), Z=Problem');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','PRMEVERG','Q46 Have you ever used Premarin - Green?','N/Y');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','PRMEVERB','Q46 Have you ever used Premarin - Brown/Red?','N/Y');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','PRMEVERW','Q46 Have you ever used Premarin - White?','N/Y');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','PRMEVERY','Q46 Have you ever used Premarin - Yellow/Orange','N/Y');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','PRMEVERP','Q46 Have you ever used Premarin - Purple?','N/Y');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','PRMLONG','Q46 Longest use of Premarin - Which type?','A=Green, B=Brown/Red, C=White, D=Yellow/Orange, E=Purple, F=Ans "A" & "B", G=Ans "B" & "C", H=Ans "C" & "D", I=Ans "D" & "E", J=Ans "A" & "D", K=Ans "C" & "E", L=Ans "B" & "D"      ');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','ESTINJCT','Q47 Ever taken estrogen by injection?','N/Y/Z');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','ESTPATCH','Q47 Ever taken estrogen by patch/implant?','N/Y/Z');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','ESTVAGCM','Q47 Ever taken estrogen by vaginal cream/supp?','N/Y/Z');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','Provera_Dose','Q51, Q55 GENERATED - Usual dose of provera','0=No provera use, 1=2.5mg, 2= 5mg, 3=10 mg, 4=20 mg, 5=Other, 6=Don''t know, 7=Multiple doses selected, 8=Used another type of progestin, 99=Missing');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','TTOREG','Q22 TIME TO REGULAR PERIODS','0-7, 0=No_FMP ,1=NvReg ,2=<1yr ,3=1yr,4=2 yrs ,5=3 yrs ,6=4 yrs ,7=5+ yrs,.A=FP_Blnk ,.B=P4B_P5A ,.C=Q Blnk ,.D=B_NvReg ,.E=B_Reg, .K=NFMP_Reg ,.L=FMP_B, .N=FMP_ToIrrg ,.O=U_Blnk ,.P=U_NvReg ,.Q=U_Reg;');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','PRDAYS','Q23 Days from start of one period to start of next?','A=24 or less, B=25-26, C=27-28, D=29-30, E=31-32, F=33 or more, G=multiple ans, Z=Problem');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','ROCYN15','Q24-26 EVER USED OC','0-4, 0=NO,<=1915, 1=Y_Curr, 2=Y_Pst, 4=Y_Cur?_Pst?, .A=FP_Blnk, .B=PG_Blnk, .C=NVR_Q2426B, .U=Unk_Rev');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','RTOCYRS15','Q24-26 TOTAL YRS USED OC','0-8, 0=No OC, 1=<1, 2=1-2, 3=3-4, 4=5-9, 5=10-14, 6=15-19, 7=20-24, 8=25+, .A=FP_Blnk, .B=PG_Blnk, .C=NVR_Q2426B, .H=H:OC15Y_NoYrs,  .U=Unk_Rev');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','PILLAGFX','Q25 RECONSTITUTED -Age first used birth control','0-69');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','PILLAGLX','Q25 RECONSTITUTED -Age last used birth control','0-83, .Z=Problem');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','TOTLB','Q28 TOTAL NUM OF LIVE BIRTHS','0-13, .A=FP_Blnk, .B=P4BP5ANoP, .C=QB_P5Blnk, .D=QB_P5ANoP, .P=NoPrgs, .Z=GrdPrb');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','TOTSB','Q28 TOTAL NUM OF STILL BIRTHS','0-8, .A=FP_Blnk, .B=P4BP5ANoP, .C=QB_P5Blnk, .D=QB_P5ANoP, .P=NoPrgs, .Z=GrdPrb');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','TOTMS','Q28 TOTAL NUM OF MISCARRIAGES','0-14, .A=FP_Blnk, .B=P4BP5ANoP, .C=QB_P5Blnk, .D=QB_P5ANoP, .L=N22, .P=NoPrgs, .Z=GrdPrb');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','TOTAB','Q28 TOTAL NUM OF ABORTIONS','0-12, .A=FP_Blnk, .B=P4BP5ANoP, .C=QB_P5Blnk, .D=QB_P5ANoP, .P=NoPrgs, .Z=GrdPrb');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','TOTTB','Q28 TOTAL NUM OF TUBAL PREGS','0-2, .A=FP_Blnk, .B=P4BP5ANoP, .C=QB_P5Blnk, .D=QB_P5ANoP, .L=N3, .M=N4, .N=N5, .O=N6, .P=NoPrgs, .Z=GrdPrb');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','TOTFTP','Q28 TOTAL LIV BIRTHS+STILL BIRTHS','0-13, .A=FP_Blnk, .B=P4BP5ANoP, .C=QB_P5Blnk, .D=QB_P5ANoP, .P=NoPrgs, .Z=GrdPrb');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','EVPRG','Q28 EVER PREGNANT','0-1, 0=Nv Prg, 1=Evr Prg, .A=FP_Blnk, .B=P4BP5ANoP, .C=QB_P5Blnk, .D=QB_P5ANoP, .Z=GrdPrb');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','CURPRG','Q28 CURRENTLY PREGNANT','0-1, 0=No, 1=Curpg');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','AGEFMS','Q28 AGE 1ST MISCARRIAGE','14-46, .A=FP_Blnk, .B=P4BP5ANoP, .C=QB_P5Blnk, .D=QB_P5ANoP, .L=N22, .P=NoPrgs, .Q=CP1st, .R=No MS, .S=HCPrgs, .Z=GrdPrb');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','AGEFAB','Q28 AGE 1ST ABORTION','14-46, .A=FP_Blnk, .B=P4BP5ANoP, .C=QB_P5Blnk, .D=QB_P5ANoP, .L=N22, .P=NoPrgs, .Q=CP1st, .R=No MS, .S=HCPrgs, .Z=GrdPrb');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','AGEFFTP','Q27-28 AGE 1ST FULL TERM PREG(LB,SB)','14-46, .A=FP_Blnk, .B=P4BP5ANoP, .C=QB_P5Blnk, .D=QB_P5ANoP, .P=NoPrgs, .Q=CP1st, .R=No FTP, .S=HCPrgs, .Z=GrdPrb');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','AGEFPG','Q27-28 AGE 1ST PREGNANCY','14-46, .A=FP_Blnk, .B=P4BP5ANoP, .C=QB_P5Blnk, .D=QB_P5ANoP, .P=NoPrgs, .Q=CP1st, .S=HCPrgs, .T=NvPrg, .Z=GrdPrb');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','AGELPG','Q28 AGE LAST PREGNANCY(ALL OUTCOMES)','14-46, .A=FP_Blnk, .B=P4BP5ANoP, .C=QB_P5Blnk, .D=QB_P5ANoP, .P=NoPrgs, .Q=CurPrg, .S=HCPrgs, .T=NvPrg, .Z=GrdPrb');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','TOTPRG','Q28 Total Number of Pregnancies','0-15, .A=FP_Blnk, .B=P4BP5ANoP, .C=QB_P5Blnk, .D=QB_P5ANoP, .L=TPrb_N3, .M=TPrb_N3, .N=TPrb_N3, .O=TPrb_N3, .P=NoPrgs, .R=TMS_N22, Z=GrdPrb');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','AGEATLB','Q28 AGE AT FIRST LIVE BIRTH','14-46');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','DESMISC','Q31 Ever taken DES to prevent miscarriage?','N/Y/Z');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','AGEFBF','Q29 AGE 1ST BREAST FED','0-10, 0=0:NvPrg, 1=P_NoLB, 2=LB_NBF, 3=<18, 4=18-19, 5=20-24, 6=25-29, 7=30-34, 8=35-39, 9=40+, 10=BF_DKAG, .A=FP_Blnk, .B=P4BP5ANOP, .C=QB_P5Blnk, .D=QB_P5ANOP, .E=LB_AGBF=Z, .F=QSTNABLE, .P=NoPrgs, .Z=GrdPrb');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','TOTMBF','Q30 TOTAL MTHS BREAST FED','0-10, 0=NvPrg, 1=P_NoLB, 2=LB_NBF, 3=<6M, 4=6-11, 5=12-23, 6=24-35, 7=36-47, 8=48-59, 9=60+, 10=BF_DKAG, .A=FP_Blnk, .B=P4BP5ANOP, .C=QB_P5Blnk, .D=QB_P5ANOP, .E=LB_AGBF=Z, .F=QSTNABLE, .P=NoPrgs, .Z=GrdPrb');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','RMENOVARA','Q34-36,41,56 MENOPAUSAL STATUS BASIC GROUPING (REVISED 6-2008 & 2-2009)','1-3, 1=Pre, 2=Peri, 3=Post, .G=Hyst<56, .H=Unk_HT, .U=UnRecov');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','RMENOVARC','Q34-36,41,56 MENOPAUSAL STATUS INCLUDE TYPE OF MENOPAUSE (REVISED 6-2008)','1-11, 1=Pre, 2=Peri_NTL, 3=Peri_M,C,R, 4=Peri_Oth, 5=Post_NTL, 6=Post_BO, 7=Post_M,C,R, 8=Post_Oth, 9=Post_Hyst_56+, 10=Pst56+_Hys<56,  11=Post_Unk_Type, .G=Hyst<56, .H=Unk_Meno stat due to HT, .U=Unk
');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','RMENOVARD','Q34-36,41,56 MENOPAUSAL STATUS TYPE AND AGE (REVISED 3-2008)','1-58, 1=Pre, 2=Peri_N_LT35, 3=Peri_N_35-39, 4=Peri_N_40-43, 5=Peri_N_44-46, 6=Peri_N_47-49, 7=Peri_N_50-52, 8=Peri_N_53-55, 9=Peri_N_56+, 10=Peri_M, C, R_LT35, 11=Peri_M, C, R_35-39, 12=Peri_M, C, R_40-43, 13=Peri_M, C, R_44-46, 14=Peri_M, C, R_47-49, 15=Peri_M, C, R_50-52, 16=Peri_M, C, R_53-55, 17=Peri_M, C, R_56+, 18=Peri_Oth_LT35, 19=Peri_Oth_35-39, 20=Peri_Oth_40-43, 21=Peri_Oth_44-46, 22=Peri_Oth_47-49, 23=Peri_Oth_50-52, 24=Peri_Oth_53-55, 25=Peri_Oth_56+, 26=Pst_N_LT35, 27=Pst_N_35-39, 28=Pst_N_40-43, 29=Pst_N_44-46, 30=Pst_N_47-49, 31=Pst_N_50-52, 32=Pst_N_53-55, 33=Pst_N_56+, 34=Pst_BO_LT35, 35=Pst_BO_35-39, 36=:Pst_BO_40-43, 37=Pst_BO_44-46, 38=Pst_BO_47-49, 39=Pst_BO_50-52, 40=Pst_BO_53-55, 41=Pst_BO_56+, 42=Pst_M, C, R_LT35, 43=Pst_M, C, R_35-39, 44=Pst_M, C, R_40-43, 45=Pst_M, C, R_44-46, 46=Pst_M, C, R_47-49, 47=Pst_M, C, R_50-52, 48=Pst_M, C, R_53-55, 49=Pst_M, C, R_56+, 50=Pst_Oth_LT35, 51=Pst_Oth_35-39, 52=Pst_Oth_40-43, 53=Pst_Oth_44-46, 54=Pst_Oth_47-49, 55=Pst_Oth_50-52, 56=Pst_Oth_53-55, 57=Pst_Oth_56+, 58=Pst_H_56+, .G=Hyst<56, .H=Unk_HT, .U=Unk');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','PRDLAST','Q35 When was last period?','A=<35, B=35-39, C=40-43, D=44-46, E=47-49, F=50-52, G=53-55, H=56+, Z=Problem');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','PRDSTOPW','Q36 Why did periods stop?','A=Nat,B=Surg,C=Med,D=Rad,E=Oth, F=Rad,Med,G=Nat,Surg,H=Nat,Rad,I=Nat,Med, Rad, J=Nat,Med, K=Nat,Oth, L=Horm, M=Pit Aden, Z=Problem');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','HYSTERAG','Q37 Ever had a hysterectomy? If so, what age?','A=Never, B=<25, C=25-34, D=35-44, E=45-49, F=50-54, G=55-59, H=60-64, I=65+, Z=Problem');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','OVARYRMV','Q38 Have you ever had an ovary removed?','A=No, B=Yes/1, C=Yes/both same time, D=Yes/both diff times, E=Yes/DK which, F=DK, Z=Problem');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','OVARYAGE','Q39 What age did you first have ovary removed?','A=<25, B=25-34, C=35-44, D=45-49, E=50-54, F=55-59, G=60-64, H=65+, Z=Problem');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','TUBALLIG','Q40 Ever have a tubal ligation? At what age?','A=Never, B=<20, C=20-24, D=25-29, E=30-34, F=35-39, G=40-44, H=45+');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','ESTPREMF','Q43 At what age did you first take Premarin?','A=<45, B=45-49, C=50-54, D=55-59, E=60-64, F=65-69, G=70+');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','ESTPREML','Q44 At what age did you last take Premarin?','A=Currently B=<45, C=45-49, D=50-54, E=55-59, F=60-64, G=65-69, H=70+');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','ESTMOUTH','Q47 Ever taken estrogen by mouth?','N/Y/Z');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','PROGUSE','Q51 Ever used progesterone or progestin?','A=No, B=Provera only, C=Another type only, D=Provera & oth type, E=Yes, DK type, Z=Problem');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','PROGAGEF','Q52 What age did you first use progesterone?','A=<40, B=40-44, C=45-49, D=50-54, E=55-59, F=60-64, G=65-69, H=70+');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','PROGAGEL','Q53 What age did you last use progesterone?','A=Currently B=<45, C=45-49, D=50-54, E=55-59, F=60-64, G=65-69, H=70+');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','ESTPREMX','Q45 RECONSTITUTED -Total years taking Premarin','0-56, .Z=Problem');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','PROGDYX','Q56 RECONSTITUTED -Days / month using progestin','0-39, 93=40 days total, 94=≤10 days total, 95=1 shot, every 3 mo., 96=For pregnancy for unknown #days/mo.,  97=14 days, every 3 mo.');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','EALNNPC','Q41-56 E ALONE NEV,PAST,CUR','0-3, 0=No HT, 1=Not this, 2=Past, 3=Cur, .A=Pre, .B=Unk E,P, .C=ToRev,  .D=D:U_This, .U=U:UnRecov');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','EPOVRNPC','Q41-56 E+P OVERLAP NEV,PAST,CUR','0-3, 0=No HT, 1=Not this, 2=Past, 3=Cur, .A=Pre, .B=Unk E,P, .C=ToRev,  .D=D:U_This, .U=U:UnRecov');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','PALNNPC','Q41-56 P ALONE NEV,PAST,CUR','0-3, 0=No HT, 1=Not this, 2=Past, 3=Cur, .A=Pre, .B=Unk E,P, .C=ToRev,  .D=D:U_This, .U=U:UnRecov');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','HTVARB','Q41-56 HT REVIEWED PATTERN OF USE','0-8, 0=No HT, 1=E only, 2=E+P, 3=E_E+P, 4=E+P_E, 5=E_E+P_E, 6=P only, 7=P_E+P, 8=P_E, .A=Pre, .B=Unk HT Ans, .C=ToRev HT, .D=U_This, .U=UnRecov meno status');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','HTVARC','Q41-56 HT ALL PAST, CUR E, CUR E+P, P ONLY','0-4, 0=No HT, 1=Past HT, 2=Cur E, 3=Cur E+P, 4=P only, .A=Pre, .B=Unk HT Ans, .C=ToRev HT, .D=U_This, .U=UnRecov meno status');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','EALNAMT','Q41-56 DURATION OF E ALONE FINAL VAR','0-7, 0=No HT, 1=Not this, 2=<1-2y, 3=3-5y, 4=6-9y, 5=10-14y, 6=15-19y, 7=20+y, .A=Pre, .B=Unk E,P, .C=ToRev, .D=U_This, .U=UnRecov');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','PALNAMT','Q41-56 DURATION OF P ALONE FINAL VAR','0-7, 0=No HT, 1=Not this, 2=<1-2y, 3=3-5y, 4=6-9y, 5=10-14y, 6=15-19y, 7=20+y, .A=Pre, .B=Unk E,P, .C=ToRev, .D=U_This, .U=UnRecov');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','EPOVRAMT','Q41-56 DURATION OF E+P OVERLAP FINAL VAR','0-7, 0=No HT, 1=Not this, 2=<1-2y, 3=3-5y, 4=6-9y, 5=10-14y, 6=15-19y, 7=20+y, .A=Pre, .B=Unk E,P, .C=ToRev, .D=U_This, .U=UnRecov');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','EALNBEG','Q41-56 AGE BEGIN E ALONE FINAL VAR','0-8, 0=No HT, 1=Not this, 2=<45, 3=45-49, 4=50-54, 5=55-59, 6=60-64, 7=65-69, 8=70+, .A=Pre, .B=Unk E,P, .C=ToRev, .D=U_This, .U=UnRecov');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','PALNBEG','Q41-56 AGE BEGIN P ALONE FINAL VAR','0-8, 0=No HT, 1=Not this, 2=<45, 3=45-49, 4=50-54, 5=55-59, 6=60-64, 7=65-69, 8=70+, .A=Pre, .B=Unk E,P, .C=ToRev, .D=U_This, .U=UnRecov');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','EPOVRBEG','Q41-56 AGE BEGIN E+P OVERLAP FINAL VAR','0-8, 0=No HT, 1=Not this, 2=<45, 3=45-49, 4=50-54, 5=55-59, 6=60-64, 7=65-69, 8=70+, .A=Pre, .B=Unk E,P, .C=ToRev, .D=U_This, .U=UnRecov');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','EALNEND','Q41-56 AGE END E ALONE FINAL VAR','0-9, 0=No HT, 1=Not this, 2=Cur, 3=<45, 4=45-49, 5=50-54, 6=55-59, 7=60-64, 8=65-69, 9=70+, .A=Pre, .B=Unk E,P, .C=ToRev, .D=U_This, .U=UnRecov');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','PALNEND','Q41-56 AGE END P ALONE FINAL VAR','0-9, 0=No HT, 1=Not this, 2=Cur, 3=<45, 4=45-49, 5=50-54, 6=55-59, 7=60-64, 8=65-69, 9=70+, .A=Pre, .B=Unk E,P, .C=ToRev, .D=U_This, .U=UnRecov');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','EPOVREND','Q41-56 AGE END E+P OVERALP FINAL VAR','0-9, 0=No HT, 1=Not this, 2=Cur, 3=<45, 4=45-49, 5=50-54, 6=55-59, 7=60-64, 8=65-69, 9=70+, .A=Pre, .B=Unk E,P, .C=ToRev, .D=U_This, .U=UnRecov');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','MENHT','Q51-56 COMBINATION OF MENOPAUSAL STATUS AND PAST OR CURRENT HT','0-5, 0=Pre, 1=PP, No HT, 2=PP, Past HT, 3=PP, Cur E, 4=PP, Cur E+P, 5=All oth');
INSERT INTO "topic" VALUES('Female health history','Q1','REPRODUCTIVE HISTORY','PROGTYRS','Q54 How many years did you take progesterone?','A=<1, B=1-2, C=3-5, D=6-9, E=10-14, F=15-19, G=20+');
INSERT INTO "topic" VALUES('Female health history','Q1','ALCOHOL & TOBACCO USE','SMKPREPRG','Q2, 28, 84, 85 TOTAL YEARS SMOKED PRIOR PREGNANCY','Jan-32');
INSERT INTO "topic" VALUES('Female health history','Q1','ALCOHOL & TOBACCO USE','SMKPSTPRG','Q2, 28, 84, 85 TOTAL YEARS SMOKED POST PREGNANCY','Jan-46');
INSERT INTO "topic" VALUES('Female health history','Q1','ALCOHOL & TOBACCO USE','SMKPREG','Q2, 28, 84, 85 SMOKING IN RELATION TO FIRST PREGNANCY CATEGORIES','1-4, 1=Never smoker, 2=Smoked postpartum, 3=Smoked prepartum <5y, 4=Smoked prepartum 5+yr');
INSERT INTO "topic" VALUES('Female health history','Q2','PREGNANCY UPDATE','PRPREG','Q16 How many times have you been pregnant?','A=0, B=1, C=2, D=3, E=4, F=5, G=6, H=7+, Z=problem');
INSERT INTO "topic" VALUES('Female health history','Q2','PREGNANCY UPDATE','PRLSTNON','Q17 Pregnancies since last survey-None','A=Yes');
INSERT INTO "topic" VALUES('Female health history','Q2','PREGNANCY UPDATE','PRLSTLIV','Q17 Pregnancies since last survey-Live Birth','A=Yes, Z=problem');
INSERT INTO "topic" VALUES('Female health history','Q2','PREGNANCY UPDATE','PRLSTMIS','Q17 Pregnancies since last survey-Miscarriage','A=Yes, Z=problem');
INSERT INTO "topic" VALUES('Female health history','Q2','PREGNANCY UPDATE','PRLSTABR','Q17 Pregnancies since last survey-Induced Abortion','A=Yes, Z=problem');
INSERT INTO "topic" VALUES('Female health history','Q2','PREGNANCY UPDATE','PRLSTECT','Q17 Pregnancies since last survey-Ectopic Preg','A=Yes');
INSERT INTO "topic" VALUES('Female health history','Q2','PREGNANCY UPDATE','PRLSTSTL','Q17 Pregnancies since last survey-Stillbirth','A=Yes, Z=problem');
INSERT INTO "topic" VALUES('Female health history','Q2','PREGNANCY UPDATE','PRLSTCUR','Q17 Pregnancies since last survey-Currently Preg','A=Yes');
INSERT INTO "topic" VALUES('Female health history','Q2','PREGNANCY UPDATE','PRNAUS','Q18 How many pregs have you had nausea/vomiting?','A=0, B=1, C=2, D=3, E=4, F=5, G=6, H=7+');
INSERT INTO "topic" VALUES('Female health history','Q2','PREGNANCY UPDATE','PRNAUSRX','Q19 Have you received treatment for nausea/vomiting?','Y/N');
INSERT INTO "topic" VALUES('Female health history','Q2','PREGNANCY UPDATE','PRNAUSMR','Q20 Did you need treatment for most recent preg?','Y/N');
INSERT INTO "topic" VALUES('Female health history','Q2','PREGNANCY UPDATE','PRECL','Q21 In all pregs, were you diagnosed w/pre-eclampsia?','Y/N');
INSERT INTO "topic" VALUES('Female health history','Q2','PREGNANCY UPDATE','PRECLMMR','Q22 Were you diagnosed for most recent preg?','Y/N');
INSERT INTO "topic" VALUES('Female health history','Q3','CONTRACEPTION AND MENOPAUSE','PILUSEQ3','Q12 Ever used oral contraceptives?','Y/N/Z=Unk');
INSERT INTO "topic" VALUES('Female health history','Q3','CONTRACEPTION AND MENOPAUSE','PILLMTH','Q13 How many months oral contraceptives?','A=Used but not past 4 yrs, B=1-6 mths, C=7-12 mths, D=13-24 mths, E=25-36 mths, F=37-48 mths, G=<1 mth use, Z=Unk');
INSERT INTO "topic" VALUES('Female health history','Q3','CONTRACEPTION AND MENOPAUSE','PRDNOSTP','Q14 Reasons menstrual periods havent stopped','A=Premenopausal, B=Pre oral contracep, C=Pre hrt, D=HRT aft post, E=Pregnant/breastfeed, F=Peri-menopausal taking OCs to control bleeding, G=Ans both pre_no HT & post_NTL, Z=cant fix');
INSERT INTO "topic" VALUES('Female health history','Q3','CONTRACEPTION AND MENOPAUSE','PRDSTP','Q14 Reasons menstrual periods have stopped','A=Natural menopause, B=Hysterectomy, C=Hyst & oophorectomy, D=Oophorectomy, E=Radiation/chemo, F=Oth reason, such as uterine ablation, medication, pituitary disorder etc., G=Periods stopped but reason unk');
INSERT INTO "topic" VALUES('Female health history','Q3','CONTRACEPTION AND MENOPAUSE','PRDLSTQ3','Q15 Year period stopped','A=Never ceased, B=Before 1995, C=1995, D=1996, E=1997, F=1998, G=1999, H=2000, I=2001, J=temp stopped, K=never period');
INSERT INTO "topic" VALUES('Female health history','Q3','CONTRACEPTION AND MENOPAUSE','HORMEV','Q16 Ever used female hormones for menopause?','Y/N, C=Depo-Provera, D=Don''t unk what took b/c blind study, E=Drugs taken for hormonal imbalances rather than menopausal symptoms, F=P only use for infertility, G=OC use reported instead of HT, H=Use of herbal or alternative hormones only, Z=unk');
INSERT INTO "topic" VALUES('Female health history','Q3','CONTRACEPTION AND MENOPAUSE','HORMMTH','Q17 How many months used female hormones?','A=Used but not past 4 yrs, B=1-6 mths, C=7-12 mths, D=13-24 mths, E=25-36 mths, F=37-48 mths');
INSERT INTO "topic" VALUES('Female health history','Q3','CONTRACEPTION AND MENOPAUSE','HORMLM','Q18 Used female hormones in last month?','Y/N');
INSERT INTO "topic" VALUES('Female health history','Q3','CONTRACEPTION AND MENOPAUSE','COMNO','Q19 Did not use combined HRT past 4 yrs?','Y');
INSERT INTO "topic" VALUES('Female health history','Q3','CONTRACEPTION AND MENOPAUSE','COMPRO','Q19 Used Prempro combined HRT past 4 yrs?','Y');
INSERT INTO "topic" VALUES('Female health history','Q3','CONTRACEPTION AND MENOPAUSE','COMASE','Q19 Used Premphase combined HRT past 4 yrs?','Y');
INSERT INTO "topic" VALUES('Female health history','Q3','CONTRACEPTION AND MENOPAUSE','COMOTH','Q19 Used other combined HRT past 4 yrs?','Y');
INSERT INTO "topic" VALUES('Female health history','Q3','CONTRACEPTION AND MENOPAUSE','ESTHRT','Q19 Used estrogen past 4 yrs?','A=Did not use, B=Oral premarin, C=Ogen, D=Estrace, E=Patch estrogen, F=Injection estro, G=Vaginal estro, H=Estro cream, I=Multiple pill types used/pill type unknown, J=Pill and patch, K=Pill and vaginal or cream estrogen, L=Pill/patch and injection, M=Cream/vaginal and injection');
INSERT INTO "topic" VALUES('Female health history','Q3','CONTRACEPTION AND MENOPAUSE','PROGHRT','Q19 Used progesterone past 4 yrs?','A=Did not use, B=Oral prog, C=Vaginal prog, D=Injection prog, E=Oral and vaginal prog, F=Prog cream (non- vaginal), G=Oral and injection prog
');
INSERT INTO "topic" VALUES('Female health history','Q3','CONTRACEPTION AND MENOPAUSE','Combined_HRT_Frequency','Q16, Q17, Q19 GENERATED - Frequency used combined hormone therapy during the past 4 years','0=No hormone use, 1=<1 day/month, 2=1-8 days/month, 3=9-18 days/month, 4=19-26 days/month, 5=27+ days/month, 6=Participant selected more than one frequency, 7=Former user, 88=Participant did not complete Questionnaire 3, 99=Missing');
INSERT INTO "topic" VALUES('Female health history','Q3','CONTRACEPTION AND MENOPAUSE','ESTDAY','Q19 Number days/month use estrogen hrt','A=<1 day/mth, B=1-8, C=9-18, D=19-26, E=27+');
INSERT INTO "topic" VALUES('Female health history','Q3','CONTRACEPTION AND MENOPAUSE','PROGDYQ3','Q19 Number days/month use progesterone hrt','A=<1 day/mth, B=1-8, C=9-18, D=19-26, E=27+');
INSERT INTO "topic" VALUES('Female health history','Q4','MENOPAUSAL STATUS','MENGRPQ4','Q12 The answer that best describes your current menstrual status.','* A=Pregnant, B=Breast feeding, C= Pre & taking OC, D=Pre & no OC or HT, E=HT before periods stopped, still taking, F=HT before periods stopped, stopped taking, G=Natural Meno, H=Chemo or Radiation Meno, I=Surgery, Z=Problem');
INSERT INTO "topic" VALUES('Female health history','Q4','MENOPAUSAL STATUS','POSTM','Q13 Do you consider yourself post menopausal? (No or Yes)','* Y=Yes, N=No, Z=Problem');
INSERT INTO "topic" VALUES('Female health history','Q4','MENOPAUSAL STATUS','AGELMP','Q13 At what age did you have your last menstrual period?','A=< age 35, B=35-39, C=40-43, D=44-46, E=47-49, F=50-52, G=53-55, H=56+, Z=Problem');
INSERT INTO "topic" VALUES('Female health history','Q4','MENOPAUSAL HORMONE THERAPY','HT5Y','Q14 In the past 5 years, have you used prescription hormone therapy (not including oral contraceptives)? (No or Yes)','Y=Yes, N=No, Z=Problem');
INSERT INTO "topic" VALUES('Female health history','Q4','MENOPAUSAL HORMONE THERAPY','HT5YM','Q14 In the past 5 years, for how many months did you use hormone therapy?','A=1-6 months, B=7-12, C=13-24, D=25-36, E=37-48, F=49-60 months, Z=Problem');
INSERT INTO "topic" VALUES('Female health history','Q4','MENOPAUSAL HORMONE THERAPY','HTCPW','Q14 In the past 5 years have you used prempro (off white)?','A=Yes');
INSERT INTO "topic" VALUES('Female health history','Q4','MENOPAUSAL HORMONE THERAPY','HTCPG','Q14 In the past 5 years have you used prempro (gold)?','A=Yes');
INSERT INTO "topic" VALUES('Female health history','Q4','MENOPAUSAL HORMONE THERAPY','HTCPP','Q14 In the past 5 years have you used prempro (peach)?','A=Yes');
INSERT INTO "topic" VALUES('Female health history','Q4','MENOPAUSAL HORMONE THERAPY','HTCPB','Q14 In the past 5 years have you used prempro (blue)?','A=Yes');
INSERT INTO "topic" VALUES('Female health history','Q4','MENOPAUSAL HORMONE THERAPY','HTCPU','Q14 In the past 5 years have you used prempro (unknown color)?','A=Yes');
INSERT INTO "topic" VALUES('Female health history','Q4','MENOPAUSAL HORMONE THERAPY','HTCPHASE','Q14 In the past 5 years have you used premphase?','A=Yes');
INSERT INTO "topic" VALUES('Female health history','Q4','MENOPAUSAL HORMONE THERAPY','HTCCPTCH','Q14 In the past 5 years have you used combipatch?','A=Yes');
INSERT INTO "topic" VALUES('Female health history','Q4','MENOPAUSAL HORMONE THERAPY','HTCFEM','Q14 In the past 5 years have you used femhrt?','A=Yes');
INSERT INTO "topic" VALUES('Female health history','Q4','MENOPAUSAL HORMONE THERAPY','HTCETEST','Q14 In the past 5 years have you used estratest?','A=Yes');
INSERT INTO "topic" VALUES('Female health history','Q4','MENOPAUSAL HORMONE THERAPY','HTCOTH','Q14 In the past 5 years have you used an other combined hormone preparation?','A=Yes');
INSERT INTO "topic" VALUES('Female health history','Q4','MENOPAUSAL HORMONE THERAPY','HTCNO','Q14 In the past 5 years did not use a combined hormone preparation?','A=Yes');
INSERT INTO "topic" VALUES('Female health history','Q4','MENOPAUSAL HORMONE THERAPY','HTEPG','Q14 In the past 5 years have you used premarin (green)?','A=Yes');
INSERT INTO "topic" VALUES('Female health history','Q4','MENOPAUSAL HORMONE THERAPY','HTEPB','Q14 In the past 5 years have you used premarin (blue)?','A=Yes');
INSERT INTO "topic" VALUES('Female health history','Q4','MENOPAUSAL HORMONE THERAPY','HTEPM','Q14 In the past 5 years have you used premarin (maroon)?','A=Yes');
INSERT INTO "topic" VALUES('Female health history','Q4','MENOPAUSAL HORMONE THERAPY','HTEPW','Q14 In the past 5 years have you used premarin (white)?','A=Yes');
INSERT INTO "topic" VALUES('Female health history','Q4','MENOPAUSAL HORMONE THERAPY','HTEPO','Q14 In the past 5 years have you used premarin (orange)?','A=Yes');
INSERT INTO "topic" VALUES('Female health history','Q4','MENOPAUSAL HORMONE THERAPY','HTEPU','Q14 In the past 5 years have you used premarin (unknown color)?','A=Yes');
INSERT INTO "topic" VALUES('Female health history','Q4','MENOPAUSAL HORMONE THERAPY','HTEEST','Q14 In the past 5 years have you used estrace?','A=Yes');
INSERT INTO "topic" VALUES('Female health history','Q4','MENOPAUSAL HORMONE THERAPY','HTEOGEN','Q14 In the past 5 years have you used ogen?','A=Yes');
INSERT INTO "topic" VALUES('Female health history','Q4','MENOPAUSAL HORMONE THERAPY','HTEOTH','Q14 In the past 5 years have you used other oral estrogen?','A=Yes');
INSERT INTO "topic" VALUES('Female health history','Q4','MENOPAUSAL HORMONE THERAPY','HTENO','Q14 In the past 5 years did not use an oral estrogen?','A=Yes');
INSERT INTO "topic" VALUES('Female health history','Q4','MENOPAUSAL HORMONE THERAPY','HTEPATCH','Q14 In the past 5 years have you used a patch estrogen?','A=Yes');
INSERT INTO "topic" VALUES('Female health history','Q4','MENOPAUSAL HORMONE THERAPY','HTEVAG','Q14 In the past 5 years have you used a vaginal estrogen?','A=Yes');
INSERT INTO "topic" VALUES('Female health history','Q4','MENOPAUSAL HORMONE THERAPY','HTOENO','Q14 In the past 5 years did not use an other estrogen?','A=Yes');
INSERT INTO "topic" VALUES('Female health history','Q4','MENOPAUSAL HORMONE THERAPY','HTP2','Q14 In the past 5 years have you used Prover/Cycrin/MPA(2.5 mg or less) ?','A=Yes');
INSERT INTO "topic" VALUES('Female health history','Q4','MENOPAUSAL HORMONE THERAPY','HTP5','Q14 In the past 5 years have you used Prover/Cycrin/MPA(5-9 mg or less) ?','A=Yes');
INSERT INTO "topic" VALUES('Female health history','Q4','MENOPAUSAL HORMONE THERAPY','HTP10','Q14 In the past 5 years have you used Prover/Cycrin/MPA(10 mg or less) ?','A=Yes');
INSERT INTO "topic" VALUES('Female health history','Q4','MENOPAUSAL HORMONE THERAPY','HTPMORE','Q14 In the past 5 years have you used Prover/Cycrin/MPA(more than 10 mg) ?','A=Yes');
INSERT INTO "topic" VALUES('Female health history','Q4','MENOPAUSAL HORMONE THERAPY','HTPUNK','Q14 In the past 5 years have you used Prover/Cycrin/MPA(unknown dose) ?','A=Yes');
INSERT INTO "topic" VALUES('Female health history','Q4','MENOPAUSAL HORMONE THERAPY','HTPOTH','Q14 In the past 5 years have you used an other oral progestin?','A=Yes');
INSERT INTO "topic" VALUES('Female health history','Q4','MENOPAUSAL HORMONE THERAPY','HTPNO','Q14 In the past 5 years did not use an oral progesterone/progestin?','A=Yes');
INSERT INTO "topic" VALUES('Female health history','Q4','MENOPAUSAL HORMONE THERAPY','HTEDAY','Q14 What was your pattern of use when you used an oral estrogen?','* A=Didn''t use, B=<1day/month, C=1-8, D=9-18, E=19-26, F=27+Days/months, Z=Problem ');
INSERT INTO "topic" VALUES('Female health history','Q4','MENOPAUSAL HORMONE THERAPY','HTPDAY','Q14 What was your pattern of use when you used an oral progesterone?','* A=Didn''t use, B=<1day/month, C=1-8, D=9-18, E=19-26, F=27+Days/months, Z=Problem ');
INSERT INTO "topic" VALUES('Female health history','Q4','MENOPAUSAL HORMONE THERAPY','HTCURR','Q14 Are you currently using hormone therapy (within the past month)?','Y=Yes, N=No, Z=Problem');
INSERT INTO "topic" VALUES('Female health history','Q4','SMOKING & PREGNANCY','SPEVPRGX','Q46 GENERATED VARIABLE FOR Ever pregnant?','Y=Yes, N=No, U=Unk, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Female health history','Q4','SMOKING & PREGNANCY','SPOWNBX','Q46 GENERATED VARIABLE FOR Before preg cigs per day','A=Did not smoke, B=<10, C=10-19, D=20+, V=Questionnaire section blank, Z=Multiple responses');
INSERT INTO "topic" VALUES('Female health history','Q4','SMOKING & PREGNANCY','SPOWNDX','Q46 GENERATED VARIABLE FOR During preg cigs per day','A=Did not smoke, B=<10, C=10-19, D=20+, V=Questionnaire section blank, Z=Multiple responses');
INSERT INTO "topic" VALUES('Female health history','Q4','SMOKING & PREGNANCY','SPNOSMBX','Q46 GENERATED VARIABLE FOR No-one smoked around me before pregnancy','Y=Yes, U=Wrong page #12, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Female health history','Q4','SMOKING & PREGNANCY','SPNOSMDX','Q46 GENERATED VARIABLE FOR No-one smoked around me during pregnancy','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Female health history','Q4','SMOKING & PREGNANCY','SPHOMEBX','Q46 GENERATED VARIABLE FOR Others at home smoked before pregnancy','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Female health history','Q4','SMOKING & PREGNANCY','SPHOMEDX','Q46 GENERATED VARIABLE FOR Others at home smoked during pregnancy','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Female health history','Q4','SMOKING & PREGNANCY','SPWORKBX','Q46 GENERATED VARIABLE FOR Others at work smoked before pregnancy','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Female health history','Q4','SMOKING & PREGNANCY','SPWORKDX','Q46 GENERATED VARIABLE FOR Others at work smoked during pregnancy','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Female health history','Q4','SMOKING & PREGNANCY','SPOTHRBX','Q46 GENERATED VARIABLE FOR Others smoked around me before pregnancy','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Female health history','Q4','SMOKING & PREGNANCY','SPOTHRDX','Q46 GENERATED VARIABLE FOR Others smoked around me during pregnancy','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Female health history','Q4','SMOKING & PREGNANCY','SBPRG1X','Q46 GENERATED VARIABLE FOR Did first pregnancy result in a live birth?','Y=Yes, N=No, U=Unk, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Female health history','Q4','SMOKING & PREGNANCY','SBEVLBX','Q46 GENERATED VARIABLE FOR Ever preg & live birth?','Y=Yes, N=No, U=Unk, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Female health history','Q4','SMOKING & PREGNANCY','SBOWNBX','Q46 GENERATED VARIABLE FOR Own smokg before live birth cigs per day','A=Did not smoke, B=<10, C=10-19, D=20+, V=Questionnaire section blank, Z=Multiple responses');
INSERT INTO "topic" VALUES('Female health history','Q4','SMOKING & PREGNANCY','SBOWNDX','Q46 GENERATED VARIABLE FOR Own smokg during live birth cigs per day','A=Did not smoke, B=<10, C=10-19, D=20+, V=Questionnaire section blank, Z=Multiple responses');
INSERT INTO "topic" VALUES('Female health history','Q4','SMOKING & PREGNANCY','SBNOSMBX','Q46 GENERATED VARIABLE FOR No-one smoked before live birth','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Female health history','Q4','SMOKING & PREGNANCY','SBNOSMDX','Q46 GENERATED VARIABLE FOR No-one smoked during live birth','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Female health history','Q4','SMOKING & PREGNANCY','SBHOMEBX','Q46 GENERATED VARIABLE FOR Others at home smoked before live birth','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Female health history','Q4','SMOKING & PREGNANCY','SBHOMEDX','Q46 GENERATED VARIABLE FOR Others at home smoked during live birth','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Female health history','Q4','SMOKING & PREGNANCY','SBWORKBX','Q46 GENERATED VARIABLE FOR Others at work smoked before live birth','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Female health history','Q4','SMOKING & PREGNANCY','SBWORKDX','Q46 GENERATED VARIABLE FOR Others at work smoked during live birth','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Female health history','Q4','SMOKING & PREGNANCY','SBOTHRBX','Q46 GENERATED VARIABLE FOR Others smoked around me before live birth','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Female health history','Q4','SMOKING & PREGNANCY','SBOTHRDX','Q46 GENERATED VARIABLE FOR Others smoked around me during live birth','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Female health history','Q4mini','FRONT COVER','MENGRPQ4','Q2 The answer that best describes your current menstrual status.','A=PREG, B=BF, C= PRE & OC, D=PRE, E=HT B4 MENO, STILL TAKE, F=HT B4 MENO, STOP, G=NAT MENO, H=CHEMO MENO, I=SURG, J=HT B4 MENO,STILL TAKE + NAT MENO, K=CHEMO MENO + SURG, L=HT B4 MENO,STILL TAKE + SURG, M=HT b4 MENO,STOP + CHEMO MENO, N=HT b4 MENO,STOP + CHEMO MENO + SURG, O=HT b4 MENO,STOP + NAT MENO, P=HT b4 MENO,STOP + NAT MENO + CHEMO MENO, Q=HT b4 MENO,STOP + NAT MENO + SURG, R=HT b4 MENO,STOP + SURG, S=HT B4 MENO,STILL TAKE + NAT MENO + CHEMO MENO, T=HT B4 MENO,STILL TAKE + NAT MENO + SURG, Z=UNABLE TO DETERMINE');
INSERT INTO "topic" VALUES('Female health history','Q4mini','REAR COVER','POSTM','Q3 Do you consider yourself post menopausal? (No or Yes)','Y=Yes, N=No');
INSERT INTO "topic" VALUES('Female health history','Q4mini','REAR COVER','AGELMP','Q3 At what age did you have your last menstrual period?','A=< AGE 35, B=35-39, C=40-43, D=44-46, E=47-49, F=50-52, G=53-55, H=56+');
INSERT INTO "topic" VALUES('Female health history','Q4mini','REAR COVER','HT5Y','Q4 In the past 5 years, have you used prescription hormone therapy (not including oral contraceptives)? (No or Yes)','Y=Yes, N=No');
INSERT INTO "topic" VALUES('Female health history','Q4mini','REAR COVER','HT5YM','Q4 In the past 5 years, for how many months did you use hormone therapy?','A=1-6 MO, B=7-12, C=13-24, D=25-36, E=37-48, F=49-60 MO, Z=UNABLE TO DETERMINE');
INSERT INTO "topic" VALUES('Female health history','Q4mini','REAR COVER','HTCURR','Q4 Are you currently using hormone therapy (within the past month)?','Y=Yes, N=No');
INSERT INTO "topic" VALUES('Female health history','Q4mini','REAR COVER','HTCPW','Q4 In the past 5 years have you used prempro (off white)?','A=YES');
INSERT INTO "topic" VALUES('Female health history','Q4mini','REAR COVER','HTCPG','Q4 In the past 5 years have you used prempro (gold)?','A=YES');
INSERT INTO "topic" VALUES('Female health history','Q4mini','REAR COVER','HTCPP','Q4 In the past 5 years have you used prempro (peach)?','A=YES');
INSERT INTO "topic" VALUES('Female health history','Q4mini','REAR COVER','HTCPB','Q4 In the past 5 years have you used prempro (blue)?','A=YES');
INSERT INTO "topic" VALUES('Female health history','Q4mini','REAR COVER','HTCPU','Q4 In the past 5 years have you used prempro (unknown color)?','A=YES');
INSERT INTO "topic" VALUES('Female health history','Q4mini','REAR COVER','HTCPHASE','Q4 In the past 5 years have you used premphase?','A=YES');
INSERT INTO "topic" VALUES('Female health history','Q4mini','REAR COVER','HTCCPTCH','Q4 In the past 5 years have you used combipatch?','A=YES');
INSERT INTO "topic" VALUES('Female health history','Q4mini','REAR COVER','HTCFEM','Q4 In the past 5 years have you used femhrt?','A=YES');
INSERT INTO "topic" VALUES('Female health history','Q4mini','REAR COVER','HTCETEST','Q4 In the past 5 years have you used estratest?','A=YES');
INSERT INTO "topic" VALUES('Female health history','Q4mini','REAR COVER','HTCOTH','Q4 In the past 5 years have you used an other combined hormone preparation?','A=YES');
INSERT INTO "topic" VALUES('Female health history','Q4mini','REAR COVER','HTCNO','Q4 In the past 5 years did not use a combined hormone preparation?','A=YES');
INSERT INTO "topic" VALUES('Female health history','Q4mini','REAR COVER','HTEPG','Q4 In the past 5 years have you used premarin (green)?','A=YES');
INSERT INTO "topic" VALUES('Female health history','Q4mini','REAR COVER','HTEPB','Q4 In the past 5 years have you used premarin (blue)?','A=YES');
INSERT INTO "topic" VALUES('Female health history','Q4mini','REAR COVER','HTEPM','Q4 In the past 5 years have you used premarin (maroon)?','A=YES');
INSERT INTO "topic" VALUES('Female health history','Q4mini','REAR COVER','HTEPW','Q4 In the past 5 years have you used premarin (white)?','A=YES');
INSERT INTO "topic" VALUES('Female health history','Q4mini','REAR COVER','HTEPO','Q4 In the past 5 years have you used premarin (orange)?','A=YES');
INSERT INTO "topic" VALUES('Female health history','Q4mini','REAR COVER','HTEPU','Q4 In the past 5 years have you used premarin (unknown color)?','A=YES');
INSERT INTO "topic" VALUES('Female health history','Q4mini','REAR COVER','HTEEST','Q4 In the past 5 years have you used estrace?','A=YES');
INSERT INTO "topic" VALUES('Female health history','Q4mini','REAR COVER','HTEOGEN','Q4 In the past 5 years have you used ogen?','A=YES');
INSERT INTO "topic" VALUES('Female health history','Q4mini','REAR COVER','HTEOTH','Q4 In the past 5 years have you used other oral estrogen?','A=YES');
INSERT INTO "topic" VALUES('Female health history','Q4mini','REAR COVER','HTENO','Q4 In the past 5 years did not use an oral estrogen?','A=YES');
INSERT INTO "topic" VALUES('Female health history','Q4mini','REAR COVER','HTEPATCH','Q4 In the past 5 years have you used a patch estrogen?','A=YES');
INSERT INTO "topic" VALUES('Female health history','Q4mini','REAR COVER','HTEVAG','Q4 In the past 5 years have you used a vaginal estrogen?','A=YES');
INSERT INTO "topic" VALUES('Female health history','Q4mini','REAR COVER','HTOENO','Q4 In the past 5 years did not use an other estrogen?','A=YES');
INSERT INTO "topic" VALUES('Female health history','Q4mini','REAR COVER','HTP2','Q4 In the past 5 years have you used Prover/Cycrin/MPA(2.5 mg or less) ?','A=YES');
INSERT INTO "topic" VALUES('Female health history','Q4mini','REAR COVER','HTP5','Q4 In the past 5 years have you used Prover/Cycrin/MPA(5-9 mg or less) ?','A=YES');
INSERT INTO "topic" VALUES('Female health history','Q4mini','REAR COVER','HTP10','Q4 In the past 5 years have you used Prover/Cycrin/MPA(10 mg or less) ?','A=YES');
INSERT INTO "topic" VALUES('Female health history','Q4mini','REAR COVER','HTPMORE','Q4 In the past 5 years have you used Prover/Cycrin/MPA(more than 10 mg) ?','A=YES');
INSERT INTO "topic" VALUES('Female health history','Q4mini','REAR COVER','HTPUNK','Q4 In the past 5 years have you used Prover/Cycrin/MPA(unknown dose) ?','A=YES');
INSERT INTO "topic" VALUES('Female health history','Q4mini','REAR COVER','HTPOTH','Q4 In the past 5 years have you used an other oral progestin?','A=YES');
INSERT INTO "topic" VALUES('Female health history','Q4mini','REAR COVER','HTPNO','Q4 In the past 5 years did not use an oral progesterone/progestin?','A=YES');
INSERT INTO "topic" VALUES('Female health history','Q4mini','REAR COVER','HTEDAY','Q4 What was your pattern of use when you used an oral estrogen?','A=DIDN''T USE, B=<1DAY/MO, C=1-8, D=9-18, E=19-26, F=27+DAYS/MO , G=TWO DIFF PATTERNS');
INSERT INTO "topic" VALUES('Female health history','Q4mini','REAR COVER','HTPDAY','Q4 What was your pattern of use when you used an oral progesterone?','A=DIDN''T USE, B=<1DAY/MO, C=1-8, D=9-18, E=19-26, F=27+DAYS/MO , G=TWO DIFF PATTERNS');
INSERT INTO "topic" VALUES('Female health history','Q4mini','REAR COVER','RALTAMEV','Q5 Have you ever used raloxifene? (No or Yes)','Y=Yes, N=No, *=Problem');
INSERT INTO "topic" VALUES('Female health history','Q4mini','REAR COVER','RALM','Q5 How many months in total have you used raloxifene?','A=NO USE, B=1-6 MOS, C=7-12, D=13-24, E=25-60, F=60 MOS +, *=Problem');
INSERT INTO "topic" VALUES('Female health history','Q4mini','REAR COVER','RALTAMC','Q5 Are you currently using raloxifene?','N=NO, NOT CURRENTLY, Y=YES');
INSERT INTO "topic" VALUES('Female health history','Q4mini','REAR COVER','OTCHORM','Q6 Are you currently using over-the counter hormonal preparations such as herbal, natural or soy-based products? ( No or Yes)','Y=Yes, N=No, *=Problem');
INSERT INTO "topic" VALUES('Female health history','Q4mini','REAR COVER','OTCHORMA','Q6 Currently using soy estrogen pills.','Y=YES');
INSERT INTO "topic" VALUES('Female health history','Q4mini','REAR COVER','OTCHORMB','Q6 Currently using dong quai.','Y=YES');
INSERT INTO "topic" VALUES('Female health history','Q4mini','REAR COVER','OTCHORMC','Q6 Currently using natural progesterone cream or wild yam cream.','Y=YES');
INSERT INTO "topic" VALUES('Female health history','Q4mini','REAR COVER','OTCHORMD','Q6 Currently using black cohosh.','Y=YES');
INSERT INTO "topic" VALUES('Female health history','Q4mini','REAR COVER','OTCHORME','Q6 Currently using flaxseed or linseed oil.','Y=YES');
INSERT INTO "topic" VALUES('Female health history','Q5','ORAL CONTRACEPTIVES','Q23a','Q23 Since January 2000, have you used birth control pills for one month or longer?','0=No, 1=Yes, but no longer taking them, 2=Yes, currently taking them');
INSERT INTO "topic" VALUES('Female health history','Q5','ORAL CONTRACEPTIVES','Q24','Q24 Since January 2000, how many years in total have you used birth control pills?','1=<1 year, 2=1-2, 3=3-4, 4=5-9, 5=10+, 6=Don''t know');
INSERT INTO "topic" VALUES('Female health history','Q5','MENSTRUAL PERIODS','Q26','Q26 Answer that best describes current menstrual status.','01=Stopped on own, 02=Stopped after surgery, 03=Stopped after radiation/chemo, 04=Stopped for other reason, 05=HT before periods stopped, stopped taking HT, 06=HT before periods stopped, still taking HT, 07=Regular periods, 08=Perimenopausal, 09=Pregnant, 10=Breast feeding');
INSERT INTO "topic" VALUES('Female health history','Q5','ORAL CONTRACEPTIVES','Q23b','Q23 If used birth control pills for one month or longer since January 200, please write in the age you stopped taking the birth control pills. The possibilities for each of the 2 columns are either a *, a blank or a number.','written values see description column');
INSERT INTO "topic" VALUES('Female health history','Q5','MENSTRUAL PERIODS','Q25a','Q25 When was your last menstrual period? This is the answer of don''t know.','1=Don''t know');
INSERT INTO "topic" VALUES('Female health history','Q5','MENSTRUAL PERIODS','Q25b','Q25 When was your last menstrual period? This is the written month and year answers. The possibilities for each of the 6 columns are either a *, a blank, or a number.','written values see description column');
INSERT INTO "topic" VALUES('Female health history','Q5','MENSTRUAL PERIODS','Q25c','Q25 When was your last menstrual period? This is the bubbled answer for month. The possibilities for each of the 2 columns are either a *, a blank, or a number.','bubbled values see description');
INSERT INTO "topic" VALUES('Female health history','Q5','MENSTRUAL PERIODS','Q25d','Q25 When was your last menstrual period? This is the bubbled answer for year. The possibilities for each of the 4 columns are either a *, or a blank, or a number.','bubbled values see description');
INSERT INTO "topic" VALUES('Female health history','Q5','MENSTRUAL PERIODS','Q25e','Q25 When was your last menstrual period? This is the written answer for age in years. The possibilities for each of the 2 columns are either a *, or a blank, or a number.','written values see description column');
INSERT INTO "topic" VALUES('Female health history','Q5','MENSTRUAL PERIODS','Q25f','Q25 When was your last menstrual period? This is the bubbled answer for age in years. The possibilities for each of the 2 coumns are either a *, or a blank, or a number.','bubbled values see description');
INSERT INTO "topic" VALUES('Female health history','Q5','MENOPAUSAL HORMONE THERAPY','Q27c_1dose','Q27 What was the dose of the conjugated estrogens?','1=0.3 mg/day, 2=0.45, 3=0.625, 4=0.9, 5=1.25, 6=Unsure');
INSERT INTO "topic" VALUES('Female health history','Q5','MENOPAUSAL HORMONE THERAPY','Q27d_1dose','Q27 What was the dose of estradiol?','1=0.5 mg/day, 2=1.0, 3=2.0, 4=Unsure');
INSERT INTO "topic" VALUES('Female health history','Q5','MENOPAUSAL HORMONE THERAPY','Q27e','Q27 If used, what was the dose of oral progesterone/progestin?','1=2.5 mg/day, 2=5, 3=10, 4=Unsure');
INSERT INTO "topic" VALUES('Female health history','Q5','MENOPAUSAL HORMONE THERAPY','Q28f','Q28 Written answer for the 2 digit year part of when participant stopped using female hormones in pill form. The possibilities for each column are either a *, a blank, or a number. Century value of 20 not required to be written since it is printed on the questionnaire.','written values see description column');
INSERT INTO "topic" VALUES('Female health history','Q5','MENOPAUSAL HORMONE THERAPY','Q28g','Q28 Where the female hormones used in patch form?','1=Patches');
INSERT INTO "topic" VALUES('Female health history','Q5','MENOPAUSAL HORMONE THERAPY','Q28h','Q28 Where the female hormone patches used an estrogen?','1=Estrogen');
INSERT INTO "topic" VALUES('Female health history','Q5','MENOPAUSAL HORMONE THERAPY','Q28i','Q28 Where the female hormone patches used combined estrogen plus progesterone/progestin?','1=Combined (estrogen+pregesterone)');
INSERT INTO "topic" VALUES('Female health history','Q5','MENOPAUSAL HORMONE THERAPY','Q28j','Q28 Are you currently using female hormones in  patch form?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Female health history','Q5','MENOPAUSAL HORMONE THERAPY','Q28k','Q28 Written answer for the 2 digit year part of when participant stopped using female hormones in patch form. The possibiities for each column are either a *, a blank, or a number. Century value of 20 not required to be written since it is printed on the questionnaire.','written values see description column');
INSERT INTO "topic" VALUES('Female health history','Q5','MENOPAUSAL HORMONE THERAPY','Q28l','Q28 Where the female hormones used vaginal estrogen creams or gels?','1=Vaginal estrogen creams/gels');
INSERT INTO "topic" VALUES('Female health history','Q5','MENOPAUSAL HORMONE THERAPY','Q28m','Q28 Are you currently using female hormones in the form of vaginal estrogen creams or gels?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Female health history','Q5','MENOPAUSAL HORMONE THERAPY','Q28n','Q28 Written answer for the 2 digit year part of when participant stopped using female hormones in the form of vaginal estrogen creams or gels. The possibilities for each column are either a *, or a blank or a number. Century value of 20 not required to be written since it is printed on the questionnaire.','written values see description column');
INSERT INTO "topic" VALUES('Female health history','Q5','MENOPAUSAL HORMONE THERAPY','Q29b','Q29 The type of combined hormone patch respondent is currently using.','* 1=Combipatch, 2=Other');
INSERT INTO "topic" VALUES('Female health history','Q5','MENOPAUSAL HORMONE THERAPY','Q27a','Q27 Since  2005 , have you used prescription female hormones (Not including oral contraceptives):','1=Yes, 0=No');
INSERT INTO "topic" VALUES('Female health history','Q5','MENOPAUSAL HORMONE THERAPY','Q27b','Q27 How many years in total did you use prescription female hormones since  January 2005?','1=<1 year, 2=1-2, 3=3-4, 4=5-6, 5=7+, 6=Don''t know');
INSERT INTO "topic" VALUES('Female health history','Q5','MENOPAUSAL HORMONE THERAPY','Q27c_1','Q27 Did you use conjugated estrogens?','1=Conjugated estrogen');
INSERT INTO "topic" VALUES('Female health history','Q5','MENOPAUSAL HORMONE THERAPY','Q27d_1','Q27 Did you use estradiol?','1=Estradiol');
INSERT INTO "topic" VALUES('Female health history','Q5','MENOPAUSAL HORMONE THERAPY','Q28a','Q28 Where the female hormones used in pill form?','1=Pills');
INSERT INTO "topic" VALUES('Female health history','Q5','MENOPAUSAL HORMONE THERAPY','Q28b','Q28 Where the female hormone pills used an estrogen?','1=Estrogen');
INSERT INTO "topic" VALUES('Female health history','Q5','MENOPAUSAL HORMONE THERAPY','Q28c','Q28 Where the female hormone pills used a progesterone/progestin?','1=Progesterone/progestin');
INSERT INTO "topic" VALUES('Female health history','Q5','MENOPAUSAL HORMONE THERAPY','Q28d','Q28 Where the female hormone pills used combined estrogen plus progesterone/progestin?','1=Combined (estrogen+progesterone)');
INSERT INTO "topic" VALUES('Female health history','Q5','MENOPAUSAL HORMONE THERAPY','Q28e','Q28 Are you currently using female hormones in  pill form?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Female health history','Q5','MENOPAUSAL HORMONE THERAPY','Q29a','Q29 The type of combined hormone pills respondent is currently using.','* 1=Prempro (beige), 2=Prempro (gold), 3=Prempro (peach), 4=Prempro (light blue), 5=Premphase (maroon&blue), 6=Femhrt (white)');
INSERT INTO "topic" VALUES('Female health history','Q5','MENOPAUSAL HORMONE THERAPY','Q29d','Q29 The type of estrogen respondent is currently using.','* 1=Oral premarin/conjugated estrogens, 2=Oral estrace/estrodiol, 3=Estrogen gels/creams, 4=Patch estrogen, 5=Vaginal estrogen creams/gels, 6=Other');
INSERT INTO "topic" VALUES('Female health history','Q5','MENOPAUSAL HORMONE THERAPY','Q29f','Q29 The type of progesterone/progestin respondent is currently using.','* 1=Provera/Cycrin, 2=Micronized, 3=Other');
INSERT INTO "topic" VALUES('Female health history','Q5','MENOPAUSAL HORMONE THERAPY','Q30','Q30 Have you EVER used bio-identical hormones (these are hormones from a compounding pharmacy)?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Female health history','Q5mini','MENOPAUSAL HORMONE THERAPY','Q27a','Q27 Since  2005 , have you used prescription female hormones (Not including oral contraceptives):','1=Yes, 0=No');
INSERT INTO "topic" VALUES('Female health history','Q5mini','MENOPAUSAL HORMONE THERAPY','Q27b','Q27 How many years in total did you use prescription female hormones since  January 2005?','1=<1 year, 2=1-2, 3=3-4, 4=5-6, 5=7+, 6=Don''t know');
INSERT INTO "topic" VALUES('Female health history','Q5mini','MENSTRUAL PERIODS','Q26','Q26 Answer that best describes current menstrual status.','01=Stopped on own, 02=Stopped after surgery, 03=Stopped after radiation/chemo, 04=Stopped for other reason, 05=HT before periods stopped, stopped taking HT, 06=HT before periods stopped, still taking HT, 07=Regular periods, 08=Perimenopausal, 09=Pregnant, 10=Breast feeding');
INSERT INTO "topic" VALUES('Female health history','Q6','MENOPAUSAL HORMONE THERAPY','Q6Web_used_MHT','Used prescription hormones since 2012','-88 = Unable to assign value
0 = Skipped
1 = Yes
2 = No');
INSERT INTO "topic" VALUES('Female health history','Q6','MENOPAUSAL HORMONE THERAPY','Q6Web_type_MHT_is_pills','Participant has used female prescription hormones: pills since her last questionnaire.','-88 = Unable to assign value
0 = Skipped
1 = Yes
2 = No
3=Other');
INSERT INTO "topic" VALUES('Female health history','Q6','MENOPAUSAL HORMONE THERAPY','Q6Web_type_MHT_pills','Type of pills used','-88 = Unable to assign value
0 = Skipped
1 = Oral conjugated estrogen (e.g., Premarin) 
2 = Oral estradiol (e.g., Estrace)
3 = Progesterone/Progestin 
4 = Combined (Estrogen + Progesterone in the same pill) ');
INSERT INTO "topic" VALUES('Female health history','Q6','MENOPAUSAL HORMONE THERAPY','Q6Web_years_used_pills','Years participant used pills since last questionnaire (Web) or since 2012 (Paper).','-88 = Unable to assign value
0 = Skipped
1 = Less than 1 year
2 = 1 year
3 = 2 years 
4 = 3 years
5 = 4 years
6 = 5 years
7 = 6 years
8 = 7 years
9 = 8 years 
10 = 9 years
11 = 10 years
12 = 11 years
13 = 12 years
14 = 13 years
15 = 14 years 
16 = 15 years
17 = 16 years
18 = 17 years
19 = Less than 1 year since 2012
20=1 year since 2012
21 = 2 years since 2012
22= 3 years since 2012
23= 4 years since 2012
24= 5 years since 2012
25= 6 years since 2012
26= 7 years since 2012');
INSERT INTO "topic" VALUES('Female health history','Q6','MENOPAUSAL HORMONE THERAPY','Q6Web_curr_MHT_pills','Is the participant currently using pills','-88 = Unable to assign value
0 = Skipped
1 = Yes
2 = No');
INSERT INTO "topic" VALUES('Female health history','Q6','MENOPAUSAL HORMONE THERAPY','Q6Web_type_MHT_patches','Participant has used female prescription hormones: patches since her last questionnaire.','-88 = Unable to assign value
0 = Skipped
1 = Yes
2 = No
3=Other');
INSERT INTO "topic" VALUES('Female health history','Q6','MENOPAUSAL HORMONE THERAPY','Q6Web_curr_MHT_patches','Is the participant currently using patches','-88 = Unable to assign value
 
0 = Skipped
1 = Yes
2 = No');
INSERT INTO "topic" VALUES('Female health history','Q6','MENOPAUSAL HORMONE THERAPY','Q6Web_type_MHT_estrogen_cream','Participant has used female prescription hormones: vaginal estrogen creams or gels since her last questionnaire.','-88 = Unable to assign value
0 = Skipped
1 = Yes
2 = No
3=Other');
INSERT INTO "topic" VALUES('Female health history','Q6','MENOPAUSAL HORMONE THERAPY','Q6Web_curr_MHT_estrogen_cream','Is the participant currently using vaginal estrogen creams or gels','-88 = Unable to assign value
 
0 = Skipped
1 = Yes
2 = No');
INSERT INTO "topic" VALUES('Female health history','Q6','MENSTRUAL PERIODS','Q6Web_menstrual_status','Participant''s current menstrual status','-88 = Unable to assign value
0 = Skipped
1 = My periods stopped on their own: I had natural menopause 
2 = My periods stopped after surgery to remove my uterus or both ovaries 
3 = My periods stopped after radiation or chemotherapy
4 = My periods stopped for another reason (please specify)
5 = I began taking hormone therapy before my periods stopped and I am still taking hormone therapy 
6 = I am still having regular menstrual periods
7 = I am perimenopausal, that is I am still having menstrual periods but they are not regular (they are heavy, continuous, or not occurring monthly) 
8 = I am not having regular menstrual periods because I am pregnant or breastfeeding ');
INSERT INTO "topic" VALUES('Female health history','Q6','MENSTRUAL PERIODS','Q6Web_age_LMP','Age at which participant had her last menstrual period. Best guess if participant cannot remember exact age.','-88 = Unable to assign value
0=Skipped
0-99');
INSERT INTO "topic" VALUES('Menopause/menstrual Periods','Q1','REPRODUCTIVE HISTORY','FMP','Q21 AGE AT MENARCHE','1-10, 1=NoFMP, 2=<10, 3=10, 4=11, 5=12, 6=13, 7=14, 8=15, 9=16, 10=17+, .A=FP_Blnk, .B=P4B_P5A, .C=Q Blnk, .D=M_Ans, .E=Unk');
INSERT INTO "topic" VALUES('Menopause/menstrual Periods','Q1','REPRODUCTIVE HISTORY','PRDSTOP','Q34 Have periods stopped permanently?','A=No, B=Yes w/i 6 mth, C=Yes > 6 mth ago, D=On OC’s to have periods (post meno), Z=Problem');
INSERT INTO "topic" VALUES('Menopause/menstrual Periods','Q1','REPRODUCTIVE HISTORY','TTOREG','Q22 TIME TO REGULAR PERIODS','0-7, 0=No_FMP ,1=NvReg ,2=<1yr ,3=1yr,4=2 yrs ,5=3 yrs ,6=4 yrs ,7=5+ yrs,.A=FP_Blnk ,.B=P4B_P5A ,.C=Q Blnk ,.D=B_NvReg ,.E=B_Reg, .K=NFMP_Reg ,.L=FMP_B, .N=FMP_ToIrrg ,.O=U_Blnk ,.P=U_NvReg ,.Q=U_Reg;');
INSERT INTO "topic" VALUES('Menopause/menstrual Periods','Q1','REPRODUCTIVE HISTORY','PRDAYS','Q23 Days from start of one period to start of next?','A=24 or less, B=25-26, C=27-28, D=29-30, E=31-32, F=33 or more, G=multiple ans, Z=Problem');
INSERT INTO "topic" VALUES('Menopause/menstrual Periods','Q1','REPRODUCTIVE HISTORY','RMENOVARA','Q34-36,41,56 MENOPAUSAL STATUS BASIC GROUPING (REVISED 6-2008 & 2-2009)','1-3, 1=Pre, 2=Peri, 3=Post, .G=Hyst<56, .H=Unk_HT, .U=UnRecov');
INSERT INTO "topic" VALUES('Menopause/menstrual Periods','Q1','REPRODUCTIVE HISTORY','RMENOVARC','Q34-36,41,56 MENOPAUSAL STATUS INCLUDE TYPE OF MENOPAUSE (REVISED 6-2008)','1-11, 1=Pre, 2=Peri_NTL, 3=Peri_M,C,R, 4=Peri_Oth, 5=Post_NTL, 6=Post_BO, 7=Post_M,C,R, 8=Post_Oth, 9=Post_Hyst_56+, 10=Pst56+_Hys<56,  11=Post_Unk_Type, .G=Hyst<56, .H=Unk_Meno stat due to HT, .U=Unk
');
INSERT INTO "topic" VALUES('Menopause/menstrual Periods','Q1','REPRODUCTIVE HISTORY','RMENOVARD','Q34-36,41,56 MENOPAUSAL STATUS TYPE AND AGE (REVISED 3-2008)','1-58, 1=Pre, 2=Peri_N_LT35, 3=Peri_N_35-39, 4=Peri_N_40-43, 5=Peri_N_44-46, 6=Peri_N_47-49, 7=Peri_N_50-52, 8=Peri_N_53-55, 9=Peri_N_56+, 10=Peri_M, C, R_LT35, 11=Peri_M, C, R_35-39, 12=Peri_M, C, R_40-43, 13=Peri_M, C, R_44-46, 14=Peri_M, C, R_47-49, 15=Peri_M, C, R_50-52, 16=Peri_M, C, R_53-55, 17=Peri_M, C, R_56+, 18=Peri_Oth_LT35, 19=Peri_Oth_35-39, 20=Peri_Oth_40-43, 21=Peri_Oth_44-46, 22=Peri_Oth_47-49, 23=Peri_Oth_50-52, 24=Peri_Oth_53-55, 25=Peri_Oth_56+, 26=Pst_N_LT35, 27=Pst_N_35-39, 28=Pst_N_40-43, 29=Pst_N_44-46, 30=Pst_N_47-49, 31=Pst_N_50-52, 32=Pst_N_53-55, 33=Pst_N_56+, 34=Pst_BO_LT35, 35=Pst_BO_35-39, 36=:Pst_BO_40-43, 37=Pst_BO_44-46, 38=Pst_BO_47-49, 39=Pst_BO_50-52, 40=Pst_BO_53-55, 41=Pst_BO_56+, 42=Pst_M, C, R_LT35, 43=Pst_M, C, R_35-39, 44=Pst_M, C, R_40-43, 45=Pst_M, C, R_44-46, 46=Pst_M, C, R_47-49, 47=Pst_M, C, R_50-52, 48=Pst_M, C, R_53-55, 49=Pst_M, C, R_56+, 50=Pst_Oth_LT35, 51=Pst_Oth_35-39, 52=Pst_Oth_40-43, 53=Pst_Oth_44-46, 54=Pst_Oth_47-49, 55=Pst_Oth_50-52, 56=Pst_Oth_53-55, 57=Pst_Oth_56+, 58=Pst_H_56+, .G=Hyst<56, .H=Unk_HT, .U=Unk');
INSERT INTO "topic" VALUES('Menopause/menstrual Periods','Q1','REPRODUCTIVE HISTORY','PRDLAST','Q35 When was last period?','A=<35, B=35-39, C=40-43, D=44-46, E=47-49, F=50-52, G=53-55, H=56+, Z=Problem');
INSERT INTO "topic" VALUES('Menopause/menstrual Periods','Q1','REPRODUCTIVE HISTORY','PRDSTOPW','Q36 Why did periods stop?','A=Nat,B=Surg,C=Med,D=Rad,E=Oth, F=Rad,Med,G=Nat,Surg,H=Nat,Rad,I=Nat,Med, Rad, J=Nat,Med, K=Nat,Oth, L=Horm, M=Pit Aden, Z=Problem');
INSERT INTO "topic" VALUES('Menopause/menstrual Periods','Q1','REPRODUCTIVE HISTORY','MENHT','Q51-56 COMBINATION OF MENOPAUSAL STATUS AND PAST OR CURRENT HT','0-5, 0=Pre, 1=PP, No HT, 2=PP, Past HT, 3=PP, Cur E, 4=PP, Cur E+P, 5=All oth');
INSERT INTO "topic" VALUES('Menopause/menstrual Periods','Q3','CONTRACEPTION AND MENOPAUSE','PRDNOSTP','Q14 Reasons menstrual periods havent stopped','A=Premenopausal, B=Pre oral contracep, C=Pre hrt, D=HRT aft post, E=Pregnant/breastfeed, F=Peri-menopausal taking OCs to control bleeding, G=Ans both pre_no HT & post_NTL, Z=cant fix');
INSERT INTO "topic" VALUES('Menopause/menstrual Periods','Q3','CONTRACEPTION AND MENOPAUSE','PRDSTP','Q14 Reasons menstrual periods have stopped','A=Natural menopause, B=Hysterectomy, C=Hyst & oophorectomy, D=Oophorectomy, E=Radiation/chemo, F=Oth reason, such as uterine ablation, medication, pituitary disorder etc., G=Periods stopped but reason unk');
INSERT INTO "topic" VALUES('Menopause/menstrual Periods','Q3','CONTRACEPTION AND MENOPAUSE','PRDLSTQ3','Q15 Year period stopped','A=Never ceased, B=Before 1995, C=1995, D=1996, E=1997, F=1998, G=1999, H=2000, I=2001, J=temp stopped, K=never period');
INSERT INTO "topic" VALUES('Menopause/menstrual Periods','Q3','CONTRACEPTION AND MENOPAUSE','HORMEV','Q16 Ever used female hormones for menopause?','Y/N, C=Depo-Provera, D=Don''t unk what took b/c blind study, E=Drugs taken for hormonal imbalances rather than menopausal symptoms, F=P only use for infertility, G=OC use reported instead of HT, H=Use of herbal or alternative hormones only, Z=unk');
INSERT INTO "topic" VALUES('Menopause/menstrual Periods','Q4','MENOPAUSAL STATUS','MENGRPQ4','Q12 The answer that best describes your current menstrual status.','* A=Pregnant, B=Breast feeding, C= Pre & taking OC, D=Pre & no OC or HT, E=HT before periods stopped, still taking, F=HT before periods stopped, stopped taking, G=Natural Meno, H=Chemo or Radiation Meno, I=Surgery, Z=Problem');
INSERT INTO "topic" VALUES('Menopause/menstrual Periods','Q4','MENOPAUSAL STATUS','POSTM','Q13 Do you consider yourself post menopausal? (No or Yes)','* Y=Yes, N=No, Z=Problem');
INSERT INTO "topic" VALUES('Menopause/menstrual Periods','Q4','MENOPAUSAL STATUS','AGELMP','Q13 At what age did you have your last menstrual period?','A=< age 35, B=35-39, C=40-43, D=44-46, E=47-49, F=50-52, G=53-55, H=56+, Z=Problem');
INSERT INTO "topic" VALUES('Menopause/menstrual Periods','Q4mini','FRONT COVER','MENGRPQ4','Q2 The answer that best describes your current menstrual status.','A=PREG, B=BF, C= PRE & OC, D=PRE, E=HT B4 MENO, STILL TAKE, F=HT B4 MENO, STOP, G=NAT MENO, H=CHEMO MENO, I=SURG, J=HT B4 MENO,STILL TAKE + NAT MENO, K=CHEMO MENO + SURG, L=HT B4 MENO,STILL TAKE + SURG, M=HT b4 MENO,STOP + CHEMO MENO, N=HT b4 MENO,STOP + CHEMO MENO + SURG, O=HT b4 MENO,STOP + NAT MENO, P=HT b4 MENO,STOP + NAT MENO + CHEMO MENO, Q=HT b4 MENO,STOP + NAT MENO + SURG, R=HT b4 MENO,STOP + SURG, S=HT B4 MENO,STILL TAKE + NAT MENO + CHEMO MENO, T=HT B4 MENO,STILL TAKE + NAT MENO + SURG, Z=UNABLE TO DETERMINE');
INSERT INTO "topic" VALUES('Menopause/menstrual Periods','Q4mini','REAR COVER','POSTM','Q3 Do you consider yourself post menopausal? (No or Yes)','Y=Yes, N=No');
INSERT INTO "topic" VALUES('Menopause/menstrual Periods','Q4mini','REAR COVER','AGELMP','Q3 At what age did you have your last menstrual period?','A=< AGE 35, B=35-39, C=40-43, D=44-46, E=47-49, F=50-52, G=53-55, H=56+');
INSERT INTO "topic" VALUES('Menopause/menstrual Periods','Q5','MENSTRUAL PERIODS','Q26','Q26 Answer that best describes current menstrual status.','01=Stopped on own, 02=Stopped after surgery, 03=Stopped after radiation/chemo, 04=Stopped for other reason, 05=HT before periods stopped, stopped taking HT, 06=HT before periods stopped, still taking HT, 07=Regular periods, 08=Perimenopausal, 09=Pregnant, 10=Breast feeding');
INSERT INTO "topic" VALUES('Menopause/menstrual Periods','Q5','MENSTRUAL PERIODS','Q25a','Q25 When was your last menstrual period? This is the answer of don''t know.','1=Don''t know');
INSERT INTO "topic" VALUES('Menopause/menstrual Periods','Q5','MENSTRUAL PERIODS','Q25b','Q25 When was your last menstrual period? This is the written month and year answers. The possibilities for each of the 6 columns are either a *, a blank, or a number.','written values see description column');
INSERT INTO "topic" VALUES('Menopause/menstrual Periods','Q5','MENSTRUAL PERIODS','Q25c','Q25 When was your last menstrual period? This is the bubbled answer for month. The possibilities for each of the 2 columns are either a *, a blank, or a number.','bubbled values see description');
INSERT INTO "topic" VALUES('Menopause/menstrual Periods','Q5','MENSTRUAL PERIODS','Q25d','Q25 When was your last menstrual period? This is the bubbled answer for year. The possibilities for each of the 4 columns are either a *, or a blank, or a number.','bubbled values see description');
INSERT INTO "topic" VALUES('Menopause/menstrual Periods','Q5','MENSTRUAL PERIODS','Q25e','Q25 When was your last menstrual period? This is the written answer for age in years. The possibilities for each of the 2 columns are either a *, or a blank, or a number.','written values see description column');
INSERT INTO "topic" VALUES('Menopause/menstrual Periods','Q5','MENSTRUAL PERIODS','Q25f','Q25 When was your last menstrual period? This is the bubbled answer for age in years. The possibilities for each of the 2 coumns are either a *, or a blank, or a number.','bubbled values see description');
INSERT INTO "topic" VALUES('Menopause/menstrual Periods','Q5mini','MENSTRUAL PERIODS','Q26','Q26 Answer that best describes current menstrual status.','01=Stopped on own, 02=Stopped after surgery, 03=Stopped after radiation/chemo, 04=Stopped for other reason, 05=HT before periods stopped, stopped taking HT, 06=HT before periods stopped, still taking HT, 07=Regular periods, 08=Perimenopausal, 09=Pregnant, 10=Breast feeding');
INSERT INTO "topic" VALUES('Menopause/menstrual Periods','Q6','MENSTRUAL PERIODS','Q6Web_menstrual_status','Participant''s current menstrual status','-88 = Unable to assign value
0 = Skipped
1 = My periods stopped on their own: I had natural menopause 
2 = My periods stopped after surgery to remove my uterus or both ovaries 
3 = My periods stopped after radiation or chemotherapy
4 = My periods stopped for another reason (please specify)
5 = I began taking hormone therapy before my periods stopped and I am still taking hormone therapy 
6 = I am still having regular menstrual periods
7 = I am perimenopausal, that is I am still having menstrual periods but they are not regular (they are heavy, continuous, or not occurring monthly) 
8 = I am not having regular menstrual periods because I am pregnant or breastfeeding ');
INSERT INTO "topic" VALUES('Menopause/menstrual Periods','Q6','MENSTRUAL PERIODS','Q6Web_age_LMP','Age at which participant had her last menstrual period. Best guess if participant cannot remember exact age.','-88 = Unable to assign value
0=Skipped
0-99');
INSERT INTO "topic" VALUES('Female surgery','Q1','REPRODUCTIVE HISTORY','RMENOVARA','Q34-36,41,56 MENOPAUSAL STATUS BASIC GROUPING (REVISED 6-2008 & 2-2009)','1-3, 1=Pre, 2=Peri, 3=Post, .G=Hyst<56, .H=Unk_HT, .U=UnRecov');
INSERT INTO "topic" VALUES('Female surgery','Q1','REPRODUCTIVE HISTORY','RMENOVARC','Q34-36,41,56 MENOPAUSAL STATUS INCLUDE TYPE OF MENOPAUSE (REVISED 6-2008)','1-11, 1=Pre, 2=Peri_NTL, 3=Peri_M,C,R, 4=Peri_Oth, 5=Post_NTL, 6=Post_BO, 7=Post_M,C,R, 8=Post_Oth, 9=Post_Hyst_56+, 10=Pst56+_Hys<56,  11=Post_Unk_Type, .G=Hyst<56, .H=Unk_Meno stat due to HT, .U=Unk
');
INSERT INTO "topic" VALUES('Female surgery','Q1','REPRODUCTIVE HISTORY','RMENOVARD','Q34-36,41,56 MENOPAUSAL STATUS TYPE AND AGE (REVISED 3-2008)','1-58, 1=Pre, 2=Peri_N_LT35, 3=Peri_N_35-39, 4=Peri_N_40-43, 5=Peri_N_44-46, 6=Peri_N_47-49, 7=Peri_N_50-52, 8=Peri_N_53-55, 9=Peri_N_56+, 10=Peri_M, C, R_LT35, 11=Peri_M, C, R_35-39, 12=Peri_M, C, R_40-43, 13=Peri_M, C, R_44-46, 14=Peri_M, C, R_47-49, 15=Peri_M, C, R_50-52, 16=Peri_M, C, R_53-55, 17=Peri_M, C, R_56+, 18=Peri_Oth_LT35, 19=Peri_Oth_35-39, 20=Peri_Oth_40-43, 21=Peri_Oth_44-46, 22=Peri_Oth_47-49, 23=Peri_Oth_50-52, 24=Peri_Oth_53-55, 25=Peri_Oth_56+, 26=Pst_N_LT35, 27=Pst_N_35-39, 28=Pst_N_40-43, 29=Pst_N_44-46, 30=Pst_N_47-49, 31=Pst_N_50-52, 32=Pst_N_53-55, 33=Pst_N_56+, 34=Pst_BO_LT35, 35=Pst_BO_35-39, 36=:Pst_BO_40-43, 37=Pst_BO_44-46, 38=Pst_BO_47-49, 39=Pst_BO_50-52, 40=Pst_BO_53-55, 41=Pst_BO_56+, 42=Pst_M, C, R_LT35, 43=Pst_M, C, R_35-39, 44=Pst_M, C, R_40-43, 45=Pst_M, C, R_44-46, 46=Pst_M, C, R_47-49, 47=Pst_M, C, R_50-52, 48=Pst_M, C, R_53-55, 49=Pst_M, C, R_56+, 50=Pst_Oth_LT35, 51=Pst_Oth_35-39, 52=Pst_Oth_40-43, 53=Pst_Oth_44-46, 54=Pst_Oth_47-49, 55=Pst_Oth_50-52, 56=Pst_Oth_53-55, 57=Pst_Oth_56+, 58=Pst_H_56+, .G=Hyst<56, .H=Unk_HT, .U=Unk');
INSERT INTO "topic" VALUES('Female surgery','Q1','REPRODUCTIVE HISTORY','HYSTERAG','Q37 Ever had a hysterectomy? If so, what age?','A=Never, B=<25, C=25-34, D=35-44, E=45-49, F=50-54, G=55-59, H=60-64, I=65+, Z=Problem');
INSERT INTO "topic" VALUES('Female surgery','Q1','REPRODUCTIVE HISTORY','OVARYRMV','Q38 Have you ever had an ovary removed?','A=No, B=Yes/1, C=Yes/both same time, D=Yes/both diff times, E=Yes/DK which, F=DK, Z=Problem');
INSERT INTO "topic" VALUES('Female surgery','Q1','REPRODUCTIVE HISTORY','OVARYAGE','Q39 What age did you first have ovary removed?','A=<25, B=25-34, C=35-44, D=45-49, E=50-54, F=55-59, G=60-64, H=65+, Z=Problem');
INSERT INTO "topic" VALUES('Female surgery','Q1','REPRODUCTIVE HISTORY','TUBALLIG','Q40 Ever have a tubal ligation? At what age?','A=Never, B=<20, C=20-24, D=25-29, E=30-34, F=35-39, G=40-44, H=45+');
INSERT INTO "topic" VALUES('Female surgery','Q3','CONTRACEPTION AND MENOPAUSE','PRDSTP','Q14 Reasons menstrual periods have stopped','A=Natural menopause, B=Hysterectomy, C=Hyst & oophorectomy, D=Oophorectomy, E=Radiation/chemo, F=Oth reason, such as uterine ablation, medication, pituitary disorder etc., G=Periods stopped but reason unk');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q1','REPRODUCTIVE HISTORY','PRMEVERG','Q46 Have you ever used Premarin - Green?','N/Y');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q1','REPRODUCTIVE HISTORY','PRMEVERB','Q46 Have you ever used Premarin - Brown/Red?','N/Y');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q1','REPRODUCTIVE HISTORY','PRMEVERW','Q46 Have you ever used Premarin - White?','N/Y');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q1','REPRODUCTIVE HISTORY','PRMEVERY','Q46 Have you ever used Premarin - Yellow/Orange','N/Y');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q1','REPRODUCTIVE HISTORY','PRMEVERP','Q46 Have you ever used Premarin - Purple?','N/Y');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q1','REPRODUCTIVE HISTORY','PRMLONG','Q46 Longest use of Premarin - Which type?','A=Green, B=Brown/Red, C=White, D=Yellow/Orange, E=Purple, F=Ans "A" & "B", G=Ans "B" & "C", H=Ans "C" & "D", I=Ans "D" & "E", J=Ans "A" & "D", K=Ans "C" & "E", L=Ans "B" & "D"      ');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q1','REPRODUCTIVE HISTORY','ESTINJCT','Q47 Ever taken estrogen by injection?','N/Y/Z');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q1','REPRODUCTIVE HISTORY','ESTPATCH','Q47 Ever taken estrogen by patch/implant?','N/Y/Z');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q1','REPRODUCTIVE HISTORY','ESTVAGCM','Q47 Ever taken estrogen by vaginal cream/supp?','N/Y/Z');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q1','REPRODUCTIVE HISTORY','Provera_Dose','Q51, Q55 GENERATED - Usual dose of provera','0=No provera use, 1=2.5mg, 2= 5mg, 3=10 mg, 4=20 mg, 5=Other, 6=Don''t know, 7=Multiple doses selected, 8=Used another type of progestin, 99=Missing');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q1','REPRODUCTIVE HISTORY','ESTPREMF','Q43 At what age did you first take Premarin?','A=<45, B=45-49, C=50-54, D=55-59, E=60-64, F=65-69, G=70+');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q1','REPRODUCTIVE HISTORY','ESTPREML','Q44 At what age did you last take Premarin?','A=Currently B=<45, C=45-49, D=50-54, E=55-59, F=60-64, G=65-69, H=70+');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q1','REPRODUCTIVE HISTORY','ESTMOUTH','Q47 Ever taken estrogen by mouth?','N/Y/Z');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q1','REPRODUCTIVE HISTORY','PROGUSE','Q51 Ever used progesterone or progestin?','A=No, B=Provera only, C=Another type only, D=Provera & oth type, E=Yes, DK type, Z=Problem');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q1','REPRODUCTIVE HISTORY','PROGAGEF','Q52 What age did you first use progesterone?','A=<40, B=40-44, C=45-49, D=50-54, E=55-59, F=60-64, G=65-69, H=70+');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q1','REPRODUCTIVE HISTORY','PROGAGEL','Q53 What age did you last use progesterone?','A=Currently B=<45, C=45-49, D=50-54, E=55-59, F=60-64, G=65-69, H=70+');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q1','REPRODUCTIVE HISTORY','ESTPREMX','Q45 RECONSTITUTED -Total years taking Premarin','0-56, .Z=Problem');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q1','REPRODUCTIVE HISTORY','PROGDYX','Q56 RECONSTITUTED -Days / month using progestin','0-39, 93=40 days total, 94=≤10 days total, 95=1 shot, every 3 mo., 96=For pregnancy for unknown #days/mo.,  97=14 days, every 3 mo.');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q1','REPRODUCTIVE HISTORY','EALNNPC','Q41-56 E ALONE NEV,PAST,CUR','0-3, 0=No HT, 1=Not this, 2=Past, 3=Cur, .A=Pre, .B=Unk E,P, .C=ToRev,  .D=D:U_This, .U=U:UnRecov');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q1','REPRODUCTIVE HISTORY','EPOVRNPC','Q41-56 E+P OVERLAP NEV,PAST,CUR','0-3, 0=No HT, 1=Not this, 2=Past, 3=Cur, .A=Pre, .B=Unk E,P, .C=ToRev,  .D=D:U_This, .U=U:UnRecov');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q1','REPRODUCTIVE HISTORY','PALNNPC','Q41-56 P ALONE NEV,PAST,CUR','0-3, 0=No HT, 1=Not this, 2=Past, 3=Cur, .A=Pre, .B=Unk E,P, .C=ToRev,  .D=D:U_This, .U=U:UnRecov');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q1','REPRODUCTIVE HISTORY','HTVARB','Q41-56 HT REVIEWED PATTERN OF USE','0-8, 0=No HT, 1=E only, 2=E+P, 3=E_E+P, 4=E+P_E, 5=E_E+P_E, 6=P only, 7=P_E+P, 8=P_E, .A=Pre, .B=Unk HT Ans, .C=ToRev HT, .D=U_This, .U=UnRecov meno status');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q1','REPRODUCTIVE HISTORY','HTVARC','Q41-56 HT ALL PAST, CUR E, CUR E+P, P ONLY','0-4, 0=No HT, 1=Past HT, 2=Cur E, 3=Cur E+P, 4=P only, .A=Pre, .B=Unk HT Ans, .C=ToRev HT, .D=U_This, .U=UnRecov meno status');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q1','REPRODUCTIVE HISTORY','EALNAMT','Q41-56 DURATION OF E ALONE FINAL VAR','0-7, 0=No HT, 1=Not this, 2=<1-2y, 3=3-5y, 4=6-9y, 5=10-14y, 6=15-19y, 7=20+y, .A=Pre, .B=Unk E,P, .C=ToRev, .D=U_This, .U=UnRecov');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q1','REPRODUCTIVE HISTORY','PALNAMT','Q41-56 DURATION OF P ALONE FINAL VAR','0-7, 0=No HT, 1=Not this, 2=<1-2y, 3=3-5y, 4=6-9y, 5=10-14y, 6=15-19y, 7=20+y, .A=Pre, .B=Unk E,P, .C=ToRev, .D=U_This, .U=UnRecov');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q1','REPRODUCTIVE HISTORY','EPOVRAMT','Q41-56 DURATION OF E+P OVERLAP FINAL VAR','0-7, 0=No HT, 1=Not this, 2=<1-2y, 3=3-5y, 4=6-9y, 5=10-14y, 6=15-19y, 7=20+y, .A=Pre, .B=Unk E,P, .C=ToRev, .D=U_This, .U=UnRecov');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q1','REPRODUCTIVE HISTORY','EALNBEG','Q41-56 AGE BEGIN E ALONE FINAL VAR','0-8, 0=No HT, 1=Not this, 2=<45, 3=45-49, 4=50-54, 5=55-59, 6=60-64, 7=65-69, 8=70+, .A=Pre, .B=Unk E,P, .C=ToRev, .D=U_This, .U=UnRecov');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q1','REPRODUCTIVE HISTORY','PALNBEG','Q41-56 AGE BEGIN P ALONE FINAL VAR','0-8, 0=No HT, 1=Not this, 2=<45, 3=45-49, 4=50-54, 5=55-59, 6=60-64, 7=65-69, 8=70+, .A=Pre, .B=Unk E,P, .C=ToRev, .D=U_This, .U=UnRecov');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q1','REPRODUCTIVE HISTORY','EPOVRBEG','Q41-56 AGE BEGIN E+P OVERLAP FINAL VAR','0-8, 0=No HT, 1=Not this, 2=<45, 3=45-49, 4=50-54, 5=55-59, 6=60-64, 7=65-69, 8=70+, .A=Pre, .B=Unk E,P, .C=ToRev, .D=U_This, .U=UnRecov');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q1','REPRODUCTIVE HISTORY','EALNEND','Q41-56 AGE END E ALONE FINAL VAR','0-9, 0=No HT, 1=Not this, 2=Cur, 3=<45, 4=45-49, 5=50-54, 6=55-59, 7=60-64, 8=65-69, 9=70+, .A=Pre, .B=Unk E,P, .C=ToRev, .D=U_This, .U=UnRecov');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q1','REPRODUCTIVE HISTORY','PALNEND','Q41-56 AGE END P ALONE FINAL VAR','0-9, 0=No HT, 1=Not this, 2=Cur, 3=<45, 4=45-49, 5=50-54, 6=55-59, 7=60-64, 8=65-69, 9=70+, .A=Pre, .B=Unk E,P, .C=ToRev, .D=U_This, .U=UnRecov');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q1','REPRODUCTIVE HISTORY','EPOVREND','Q41-56 AGE END E+P OVERALP FINAL VAR','0-9, 0=No HT, 1=Not this, 2=Cur, 3=<45, 4=45-49, 5=50-54, 6=55-59, 7=60-64, 8=65-69, 9=70+, .A=Pre, .B=Unk E,P, .C=ToRev, .D=U_This, .U=UnRecov');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q1','REPRODUCTIVE HISTORY','MENHT','Q51-56 COMBINATION OF MENOPAUSAL STATUS AND PAST OR CURRENT HT','0-5, 0=Pre, 1=PP, No HT, 2=PP, Past HT, 3=PP, Cur E, 4=PP, Cur E+P, 5=All oth');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q1','REPRODUCTIVE HISTORY','PROGTYRS','Q54 How many years did you take progesterone?','A=<1, B=1-2, C=3-5, D=6-9, E=10-14, F=15-19, G=20+');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q3','CONTRACEPTION AND MENOPAUSE','HORMEV','Q16 Ever used female hormones for menopause?','Y/N, C=Depo-Provera, D=Don''t unk what took b/c blind study, E=Drugs taken for hormonal imbalances rather than menopausal symptoms, F=P only use for infertility, G=OC use reported instead of HT, H=Use of herbal or alternative hormones only, Z=unk');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q3','CONTRACEPTION AND MENOPAUSE','HORMMTH','Q17 How many months used female hormones?','A=Used but not past 4 yrs, B=1-6 mths, C=7-12 mths, D=13-24 mths, E=25-36 mths, F=37-48 mths');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q3','CONTRACEPTION AND MENOPAUSE','HORMLM','Q18 Used female hormones in last month?','Y/N');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q3','CONTRACEPTION AND MENOPAUSE','COMNO','Q19 Did not use combined HRT past 4 yrs?','Y');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q3','CONTRACEPTION AND MENOPAUSE','COMPRO','Q19 Used Prempro combined HRT past 4 yrs?','Y');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q3','CONTRACEPTION AND MENOPAUSE','COMASE','Q19 Used Premphase combined HRT past 4 yrs?','Y');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q3','CONTRACEPTION AND MENOPAUSE','COMOTH','Q19 Used other combined HRT past 4 yrs?','Y');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q3','CONTRACEPTION AND MENOPAUSE','ESTHRT','Q19 Used estrogen past 4 yrs?','A=Did not use, B=Oral premarin, C=Ogen, D=Estrace, E=Patch estrogen, F=Injection estro, G=Vaginal estro, H=Estro cream, I=Multiple pill types used/pill type unknown, J=Pill and patch, K=Pill and vaginal or cream estrogen, L=Pill/patch and injection, M=Cream/vaginal and injection');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q3','CONTRACEPTION AND MENOPAUSE','PROGHRT','Q19 Used progesterone past 4 yrs?','A=Did not use, B=Oral prog, C=Vaginal prog, D=Injection prog, E=Oral and vaginal prog, F=Prog cream (non- vaginal), G=Oral and injection prog
');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q3','CONTRACEPTION AND MENOPAUSE','Combined_HRT_Frequency','Q16, Q17, Q19 GENERATED - Frequency used combined hormone therapy during the past 4 years','0=No hormone use, 1=<1 day/month, 2=1-8 days/month, 3=9-18 days/month, 4=19-26 days/month, 5=27+ days/month, 6=Participant selected more than one frequency, 7=Former user, 88=Participant did not complete Questionnaire 3, 99=Missing');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q3','CONTRACEPTION AND MENOPAUSE','ESTDAY','Q19 Number days/month use estrogen hrt','A=<1 day/mth, B=1-8, C=9-18, D=19-26, E=27+');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q3','CONTRACEPTION AND MENOPAUSE','PROGDYQ3','Q19 Number days/month use progesterone hrt','A=<1 day/mth, B=1-8, C=9-18, D=19-26, E=27+');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4','MENOPAUSAL HORMONE THERAPY','HT5Y','Q14 In the past 5 years, have you used prescription hormone therapy (not including oral contraceptives)? (No or Yes)','Y=Yes, N=No, Z=Problem');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4','MENOPAUSAL HORMONE THERAPY','HT5YM','Q14 In the past 5 years, for how many months did you use hormone therapy?','A=1-6 months, B=7-12, C=13-24, D=25-36, E=37-48, F=49-60 months, Z=Problem');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4','MENOPAUSAL HORMONE THERAPY','HTCPW','Q14 In the past 5 years have you used prempro (off white)?','A=Yes');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4','MENOPAUSAL HORMONE THERAPY','HTCPG','Q14 In the past 5 years have you used prempro (gold)?','A=Yes');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4','MENOPAUSAL HORMONE THERAPY','HTCPP','Q14 In the past 5 years have you used prempro (peach)?','A=Yes');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4','MENOPAUSAL HORMONE THERAPY','HTCPB','Q14 In the past 5 years have you used prempro (blue)?','A=Yes');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4','MENOPAUSAL HORMONE THERAPY','HTCPU','Q14 In the past 5 years have you used prempro (unknown color)?','A=Yes');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4','MENOPAUSAL HORMONE THERAPY','HTCPHASE','Q14 In the past 5 years have you used premphase?','A=Yes');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4','MENOPAUSAL HORMONE THERAPY','HTCCPTCH','Q14 In the past 5 years have you used combipatch?','A=Yes');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4','MENOPAUSAL HORMONE THERAPY','HTCFEM','Q14 In the past 5 years have you used femhrt?','A=Yes');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4','MENOPAUSAL HORMONE THERAPY','HTCETEST','Q14 In the past 5 years have you used estratest?','A=Yes');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4','MENOPAUSAL HORMONE THERAPY','HTCOTH','Q14 In the past 5 years have you used an other combined hormone preparation?','A=Yes');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4','MENOPAUSAL HORMONE THERAPY','HTCNO','Q14 In the past 5 years did not use a combined hormone preparation?','A=Yes');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4','MENOPAUSAL HORMONE THERAPY','HTEPG','Q14 In the past 5 years have you used premarin (green)?','A=Yes');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4','MENOPAUSAL HORMONE THERAPY','HTEPB','Q14 In the past 5 years have you used premarin (blue)?','A=Yes');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4','MENOPAUSAL HORMONE THERAPY','HTEPM','Q14 In the past 5 years have you used premarin (maroon)?','A=Yes');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4','MENOPAUSAL HORMONE THERAPY','HTEPW','Q14 In the past 5 years have you used premarin (white)?','A=Yes');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4','MENOPAUSAL HORMONE THERAPY','HTEPO','Q14 In the past 5 years have you used premarin (orange)?','A=Yes');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4','MENOPAUSAL HORMONE THERAPY','HTEPU','Q14 In the past 5 years have you used premarin (unknown color)?','A=Yes');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4','MENOPAUSAL HORMONE THERAPY','HTEEST','Q14 In the past 5 years have you used estrace?','A=Yes');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4','MENOPAUSAL HORMONE THERAPY','HTEOGEN','Q14 In the past 5 years have you used ogen?','A=Yes');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4','MENOPAUSAL HORMONE THERAPY','HTEOTH','Q14 In the past 5 years have you used other oral estrogen?','A=Yes');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4','MENOPAUSAL HORMONE THERAPY','HTENO','Q14 In the past 5 years did not use an oral estrogen?','A=Yes');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4','MENOPAUSAL HORMONE THERAPY','HTEPATCH','Q14 In the past 5 years have you used a patch estrogen?','A=Yes');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4','MENOPAUSAL HORMONE THERAPY','HTEVAG','Q14 In the past 5 years have you used a vaginal estrogen?','A=Yes');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4','MENOPAUSAL HORMONE THERAPY','HTOENO','Q14 In the past 5 years did not use an other estrogen?','A=Yes');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4','MENOPAUSAL HORMONE THERAPY','HTP2','Q14 In the past 5 years have you used Prover/Cycrin/MPA(2.5 mg or less) ?','A=Yes');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4','MENOPAUSAL HORMONE THERAPY','HTP5','Q14 In the past 5 years have you used Prover/Cycrin/MPA(5-9 mg or less) ?','A=Yes');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4','MENOPAUSAL HORMONE THERAPY','HTP10','Q14 In the past 5 years have you used Prover/Cycrin/MPA(10 mg or less) ?','A=Yes');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4','MENOPAUSAL HORMONE THERAPY','HTPMORE','Q14 In the past 5 years have you used Prover/Cycrin/MPA(more than 10 mg) ?','A=Yes');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4','MENOPAUSAL HORMONE THERAPY','HTPUNK','Q14 In the past 5 years have you used Prover/Cycrin/MPA(unknown dose) ?','A=Yes');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4','MENOPAUSAL HORMONE THERAPY','HTPOTH','Q14 In the past 5 years have you used an other oral progestin?','A=Yes');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4','MENOPAUSAL HORMONE THERAPY','HTPNO','Q14 In the past 5 years did not use an oral progesterone/progestin?','A=Yes');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4','MENOPAUSAL HORMONE THERAPY','HTEDAY','Q14 What was your pattern of use when you used an oral estrogen?','* A=Didn''t use, B=<1day/month, C=1-8, D=9-18, E=19-26, F=27+Days/months, Z=Problem ');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4','MENOPAUSAL HORMONE THERAPY','HTPDAY','Q14 What was your pattern of use when you used an oral progesterone?','* A=Didn''t use, B=<1day/month, C=1-8, D=9-18, E=19-26, F=27+Days/months, Z=Problem ');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4','MENOPAUSAL HORMONE THERAPY','HTCURR','Q14 Are you currently using hormone therapy (within the past month)?','Y=Yes, N=No, Z=Problem');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4mini','REAR COVER','HT5Y','Q4 In the past 5 years, have you used prescription hormone therapy (not including oral contraceptives)? (No or Yes)','Y=Yes, N=No');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4mini','REAR COVER','HT5YM','Q4 In the past 5 years, for how many months did you use hormone therapy?','A=1-6 MO, B=7-12, C=13-24, D=25-36, E=37-48, F=49-60 MO, Z=UNABLE TO DETERMINE');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4mini','REAR COVER','HTCURR','Q4 Are you currently using hormone therapy (within the past month)?','Y=Yes, N=No');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4mini','REAR COVER','HTCPW','Q4 In the past 5 years have you used prempro (off white)?','A=YES');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4mini','REAR COVER','HTCPG','Q4 In the past 5 years have you used prempro (gold)?','A=YES');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4mini','REAR COVER','HTCPP','Q4 In the past 5 years have you used prempro (peach)?','A=YES');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4mini','REAR COVER','HTCPB','Q4 In the past 5 years have you used prempro (blue)?','A=YES');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4mini','REAR COVER','HTCPU','Q4 In the past 5 years have you used prempro (unknown color)?','A=YES');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4mini','REAR COVER','HTCPHASE','Q4 In the past 5 years have you used premphase?','A=YES');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4mini','REAR COVER','HTCCPTCH','Q4 In the past 5 years have you used combipatch?','A=YES');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4mini','REAR COVER','HTCFEM','Q4 In the past 5 years have you used femhrt?','A=YES');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4mini','REAR COVER','HTCETEST','Q4 In the past 5 years have you used estratest?','A=YES');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4mini','REAR COVER','HTCOTH','Q4 In the past 5 years have you used an other combined hormone preparation?','A=YES');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4mini','REAR COVER','HTCNO','Q4 In the past 5 years did not use a combined hormone preparation?','A=YES');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4mini','REAR COVER','HTEPG','Q4 In the past 5 years have you used premarin (green)?','A=YES');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4mini','REAR COVER','HTEPB','Q4 In the past 5 years have you used premarin (blue)?','A=YES');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4mini','REAR COVER','HTEPM','Q4 In the past 5 years have you used premarin (maroon)?','A=YES');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4mini','REAR COVER','HTEPW','Q4 In the past 5 years have you used premarin (white)?','A=YES');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4mini','REAR COVER','HTEPO','Q4 In the past 5 years have you used premarin (orange)?','A=YES');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4mini','REAR COVER','HTEPU','Q4 In the past 5 years have you used premarin (unknown color)?','A=YES');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4mini','REAR COVER','HTEEST','Q4 In the past 5 years have you used estrace?','A=YES');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4mini','REAR COVER','HTEOGEN','Q4 In the past 5 years have you used ogen?','A=YES');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4mini','REAR COVER','HTEOTH','Q4 In the past 5 years have you used other oral estrogen?','A=YES');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4mini','REAR COVER','HTENO','Q4 In the past 5 years did not use an oral estrogen?','A=YES');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4mini','REAR COVER','HTEPATCH','Q4 In the past 5 years have you used a patch estrogen?','A=YES');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4mini','REAR COVER','HTEVAG','Q4 In the past 5 years have you used a vaginal estrogen?','A=YES');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4mini','REAR COVER','HTOENO','Q4 In the past 5 years did not use an other estrogen?','A=YES');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4mini','REAR COVER','HTP2','Q4 In the past 5 years have you used Prover/Cycrin/MPA(2.5 mg or less) ?','A=YES');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4mini','REAR COVER','HTP5','Q4 In the past 5 years have you used Prover/Cycrin/MPA(5-9 mg or less) ?','A=YES');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4mini','REAR COVER','HTP10','Q4 In the past 5 years have you used Prover/Cycrin/MPA(10 mg or less) ?','A=YES');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4mini','REAR COVER','HTPMORE','Q4 In the past 5 years have you used Prover/Cycrin/MPA(more than 10 mg) ?','A=YES');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4mini','REAR COVER','HTPUNK','Q4 In the past 5 years have you used Prover/Cycrin/MPA(unknown dose) ?','A=YES');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4mini','REAR COVER','HTPOTH','Q4 In the past 5 years have you used an other oral progestin?','A=YES');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4mini','REAR COVER','HTPNO','Q4 In the past 5 years did not use an oral progesterone/progestin?','A=YES');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4mini','REAR COVER','HTEDAY','Q4 What was your pattern of use when you used an oral estrogen?','A=DIDN''T USE, B=<1DAY/MO, C=1-8, D=9-18, E=19-26, F=27+DAYS/MO , G=TWO DIFF PATTERNS');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4mini','REAR COVER','HTPDAY','Q4 What was your pattern of use when you used an oral progesterone?','A=DIDN''T USE, B=<1DAY/MO, C=1-8, D=9-18, E=19-26, F=27+DAYS/MO , G=TWO DIFF PATTERNS');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4mini','REAR COVER','RALTAMEV','Q5 Have you ever used raloxifene? (No or Yes)','Y=Yes, N=No, *=Problem');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4mini','REAR COVER','RALM','Q5 How many months in total have you used raloxifene?','A=NO USE, B=1-6 MOS, C=7-12, D=13-24, E=25-60, F=60 MOS +, *=Problem');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4mini','REAR COVER','RALTAMC','Q5 Are you currently using raloxifene?','N=NO, NOT CURRENTLY, Y=YES');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4mini','REAR COVER','OTCHORM','Q6 Are you currently using over-the counter hormonal preparations such as herbal, natural or soy-based products? ( No or Yes)','Y=Yes, N=No, *=Problem');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4mini','REAR COVER','OTCHORMA','Q6 Currently using soy estrogen pills.','Y=YES');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4mini','REAR COVER','OTCHORMB','Q6 Currently using dong quai.','Y=YES');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4mini','REAR COVER','OTCHORMC','Q6 Currently using natural progesterone cream or wild yam cream.','Y=YES');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4mini','REAR COVER','OTCHORMD','Q6 Currently using black cohosh.','Y=YES');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q4mini','REAR COVER','OTCHORME','Q6 Currently using flaxseed or linseed oil.','Y=YES');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q5','MENOPAUSAL HORMONE THERAPY','Q27c_1dose','Q27 What was the dose of the conjugated estrogens?','1=0.3 mg/day, 2=0.45, 3=0.625, 4=0.9, 5=1.25, 6=Unsure');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q5','MENOPAUSAL HORMONE THERAPY','Q27d_1dose','Q27 What was the dose of estradiol?','1=0.5 mg/day, 2=1.0, 3=2.0, 4=Unsure');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q5','MENOPAUSAL HORMONE THERAPY','Q27e','Q27 If used, what was the dose of oral progesterone/progestin?','1=2.5 mg/day, 2=5, 3=10, 4=Unsure');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q5','MENOPAUSAL HORMONE THERAPY','Q28f','Q28 Written answer for the 2 digit year part of when participant stopped using female hormones in pill form. The possibilities for each column are either a *, a blank, or a number. Century value of 20 not required to be written since it is printed on the questionnaire.','written values see description column');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q5','MENOPAUSAL HORMONE THERAPY','Q28g','Q28 Where the female hormones used in patch form?','1=Patches');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q5','MENOPAUSAL HORMONE THERAPY','Q28h','Q28 Where the female hormone patches used an estrogen?','1=Estrogen');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q5','MENOPAUSAL HORMONE THERAPY','Q28i','Q28 Where the female hormone patches used combined estrogen plus progesterone/progestin?','1=Combined (estrogen+pregesterone)');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q5','MENOPAUSAL HORMONE THERAPY','Q28j','Q28 Are you currently using female hormones in  patch form?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q5','MENOPAUSAL HORMONE THERAPY','Q28k','Q28 Written answer for the 2 digit year part of when participant stopped using female hormones in patch form. The possibiities for each column are either a *, a blank, or a number. Century value of 20 not required to be written since it is printed on the questionnaire.','written values see description column');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q5','MENOPAUSAL HORMONE THERAPY','Q28l','Q28 Where the female hormones used vaginal estrogen creams or gels?','1=Vaginal estrogen creams/gels');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q5','MENOPAUSAL HORMONE THERAPY','Q28m','Q28 Are you currently using female hormones in the form of vaginal estrogen creams or gels?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q5','MENOPAUSAL HORMONE THERAPY','Q28n','Q28 Written answer for the 2 digit year part of when participant stopped using female hormones in the form of vaginal estrogen creams or gels. The possibilities for each column are either a *, or a blank or a number. Century value of 20 not required to be written since it is printed on the questionnaire.','written values see description column');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q5','MENOPAUSAL HORMONE THERAPY','Q29b','Q29 The type of combined hormone patch respondent is currently using.','* 1=Combipatch, 2=Other');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q5','MENOPAUSAL HORMONE THERAPY','Q27a','Q27 Since  2005 , have you used prescription female hormones (Not including oral contraceptives):','1=Yes, 0=No');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q5','MENOPAUSAL HORMONE THERAPY','Q27b','Q27 How many years in total did you use prescription female hormones since  January 2005?','1=<1 year, 2=1-2, 3=3-4, 4=5-6, 5=7+, 6=Don''t know');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q5','MENOPAUSAL HORMONE THERAPY','Q27c_1','Q27 Did you use conjugated estrogens?','1=Conjugated estrogen');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q5','MENOPAUSAL HORMONE THERAPY','Q27d_1','Q27 Did you use estradiol?','1=Estradiol');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q5','MENOPAUSAL HORMONE THERAPY','Q28a','Q28 Where the female hormones used in pill form?','1=Pills');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q5','MENOPAUSAL HORMONE THERAPY','Q28b','Q28 Where the female hormone pills used an estrogen?','1=Estrogen');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q5','MENOPAUSAL HORMONE THERAPY','Q28c','Q28 Where the female hormone pills used a progesterone/progestin?','1=Progesterone/progestin');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q5','MENOPAUSAL HORMONE THERAPY','Q28d','Q28 Where the female hormone pills used combined estrogen plus progesterone/progestin?','1=Combined (estrogen+progesterone)');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q5','MENOPAUSAL HORMONE THERAPY','Q28e','Q28 Are you currently using female hormones in  pill form?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q5','MENOPAUSAL HORMONE THERAPY','Q29a','Q29 The type of combined hormone pills respondent is currently using.','* 1=Prempro (beige), 2=Prempro (gold), 3=Prempro (peach), 4=Prempro (light blue), 5=Premphase (maroon&blue), 6=Femhrt (white)');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q5','MENOPAUSAL HORMONE THERAPY','Q29d','Q29 The type of estrogen respondent is currently using.','* 1=Oral premarin/conjugated estrogens, 2=Oral estrace/estrodiol, 3=Estrogen gels/creams, 4=Patch estrogen, 5=Vaginal estrogen creams/gels, 6=Other');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q5','MENOPAUSAL HORMONE THERAPY','Q29f','Q29 The type of progesterone/progestin respondent is currently using.','* 1=Provera/Cycrin, 2=Micronized, 3=Other');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q5','MENOPAUSAL HORMONE THERAPY','Q30','Q30 Have you EVER used bio-identical hormones (these are hormones from a compounding pharmacy)?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q5mini','MENOPAUSAL HORMONE THERAPY','Q27a','Q27 Since  2005 , have you used prescription female hormones (Not including oral contraceptives):','1=Yes, 0=No');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q5mini','MENOPAUSAL HORMONE THERAPY','Q27b','Q27 How many years in total did you use prescription female hormones since  January 2005?','1=<1 year, 2=1-2, 3=3-4, 4=5-6, 5=7+, 6=Don''t know');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q6','MENOPAUSAL HORMONE THERAPY','Q6Web_used_MHT','Used prescription hormones since 2012','-88 = Unable to assign value
0 = Skipped
1 = Yes
2 = No');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q6','MENOPAUSAL HORMONE THERAPY','Q6Web_type_MHT_is_pills','Participant has used female prescription hormones: pills since her last questionnaire.','-88 = Unable to assign value
0 = Skipped
1 = Yes
2 = No
3=Other');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q6','MENOPAUSAL HORMONE THERAPY','Q6Web_type_MHT_pills','Type of pills used','-88 = Unable to assign value
0 = Skipped
1 = Oral conjugated estrogen (e.g., Premarin) 
2 = Oral estradiol (e.g., Estrace)
3 = Progesterone/Progestin 
4 = Combined (Estrogen + Progesterone in the same pill) ');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q6','MENOPAUSAL HORMONE THERAPY','Q6Web_years_used_pills','Years participant used pills since last questionnaire (Web) or since 2012 (Paper).','-88 = Unable to assign value
0 = Skipped
1 = Less than 1 year
2 = 1 year
3 = 2 years 
4 = 3 years
5 = 4 years
6 = 5 years
7 = 6 years
8 = 7 years
9 = 8 years 
10 = 9 years
11 = 10 years
12 = 11 years
13 = 12 years
14 = 13 years
15 = 14 years 
16 = 15 years
17 = 16 years
18 = 17 years
19 = Less than 1 year since 2012
20=1 year since 2012
21 = 2 years since 2012
22= 3 years since 2012
23= 4 years since 2012
24= 5 years since 2012
25= 6 years since 2012
26= 7 years since 2012');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q6','MENOPAUSAL HORMONE THERAPY','Q6Web_curr_MHT_pills','Is the participant currently using pills','-88 = Unable to assign value
0 = Skipped
1 = Yes
2 = No');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q6','MENOPAUSAL HORMONE THERAPY','Q6Web_type_MHT_patches','Participant has used female prescription hormones: patches since her last questionnaire.','-88 = Unable to assign value
0 = Skipped
1 = Yes
2 = No
3=Other');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q6','MENOPAUSAL HORMONE THERAPY','Q6Web_curr_MHT_patches','Is the participant currently using patches','-88 = Unable to assign value
 
0 = Skipped
1 = Yes
2 = No');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q6','MENOPAUSAL HORMONE THERAPY','Q6Web_type_MHT_estrogen_cream','Participant has used female prescription hormones: vaginal estrogen creams or gels since her last questionnaire.','-88 = Unable to assign value
0 = Skipped
1 = Yes
2 = No
3=Other');
INSERT INTO "topic" VALUES('Menopausal hormone therapy','Q6','MENOPAUSAL HORMONE THERAPY','Q6Web_curr_MHT_estrogen_cream','Is the participant currently using vaginal estrogen creams or gels','-88 = Unable to assign value
 
0 = Skipped
1 = Yes
2 = No');
INSERT INTO "topic" VALUES('X-Rays imaging and radiation','Q2','X-RAY &RADIATION TREATMENT','RIBSBXR','Q23 How many times x-ray for broken ribs before 20?','A=0, B=1-4, C=5-9, D=10-14, E=15-19, F=20+, Z=problem');
INSERT INTO "topic" VALUES('X-Rays imaging and radiation','Q2','X-RAY &RADIATION TREATMENT','RIBSAXR','Q23 How many times x-ray for broken ribs after 20?','A=0, B=1-4, C=5-9, D=10-14, E=15-19, F=20+, Z=problem');
INSERT INTO "topic" VALUES('X-Rays imaging and radiation','Q2','X-RAY &RADIATION TREATMENT','BACKBXR','Q23 How many times x-ray for chest/back before 20?','A=0, B=1-4, C=5-9, D=10-14, E=15-19, F=20+, Z=problem');
INSERT INTO "topic" VALUES('X-Rays imaging and radiation','Q2','X-RAY &RADIATION TREATMENT','BACKAXR','Q23 How many times x-ray for chest/back after 20?','A=0, B=1-4, C=5-9, D=10-14, E=15-19, F=20+, Z=problem');
INSERT INTO "topic" VALUES('X-Rays imaging and radiation','Q2','X-RAY &RADIATION TREATMENT','CHESTBXR','Q23 How many times x-ray for chest (ht/lung) before 20?','A=0, B=1-4, C=5-9, D=10-14, E=15-19, F=20+, Z=problem');
INSERT INTO "topic" VALUES('X-Rays imaging and radiation','Q2','X-RAY &RADIATION TREATMENT','CHESTAXR','Q23 How many times x-ray for chest (ht/lung) after 20?','A=0, B=1-4, C=5-9, D=10-14, E=15-19, F=20+, Z=problem');
INSERT INTO "topic" VALUES('X-Rays imaging and radiation','Q2','X-RAY &RADIATION TREATMENT','GIBXR','Q23 How many times x-ray for upper/lwr GI before 20?','A=0, B=1-4, C=5-9, D=10-14, E=15-19, F=20+, Z=problem');
INSERT INTO "topic" VALUES('X-Rays imaging and radiation','Q2','X-RAY &RADIATION TREATMENT','GIAXR','Q23 How many times x-ray for upper/lwr GI after 20?','A=0, B=1-4, C=5-9, D=10-14, E=15-19, F=20+, Z=problem');
INSERT INTO "topic" VALUES('X-Rays imaging and radiation','Q2','X-RAY &RADIATION TREATMENT','SPINBXR','Q23 How many times x-ray for spinal/back before 20?','A=0, B=1-4, C=5-9, D=10-14, E=15-19, F=20+, Z=problem');
INSERT INTO "topic" VALUES('X-Rays imaging and radiation','Q2','X-RAY &RADIATION TREATMENT','SPINAXR','Q23 How many times x-ray for spinal/back after 20?','A=0, B=1-4, C=5-9, D=10-14, E=15-19, F=20+, Z=problem');
INSERT INTO "topic" VALUES('X-Rays imaging and radiation','Q2','X-RAY &RADIATION TREATMENT','IVPBXR','Q23 How many times x-ray for kidney/IVP before 20?','A=0, B=1-4, C=5-9, D=10-14, E=15-19, F=20+, Z=problem');
INSERT INTO "topic" VALUES('X-Rays imaging and radiation','Q2','X-RAY &RADIATION TREATMENT','IVPAXR','Q23 How many times x-ray for kidney/IVP after 20?','A=0, B=1-4, C=5-9, D=10-14, E=15-19, F=20+, Z=problem');
INSERT INTO "topic" VALUES('X-Rays imaging and radiation','Q2','X-RAY &RADIATION TREATMENT','FLUORBXR','Q23 How many times fluoroscopy before 20?','A=0, B=1-4, C=5-9, D=10-14, E=15-19, F=20+, Z=problem');
INSERT INTO "topic" VALUES('X-Rays imaging and radiation','Q2','X-RAY &RADIATION TREATMENT','FLUORAXR','Q23 How many times fluoroscopy after 20?','A=0, B=1-4, C=5-9, D=10-14, E=15-19, F=20+, Z=problem');
INSERT INTO "topic" VALUES('X-Rays imaging and radiation','Q2','X-RAY &RADIATION TREATMENT','CTSCNBXR','Q23 How many times CT Scan before 20?','A=0, B=1-4, C=5-9, D=10-14, E=15-19, F=20+, Z=problem');
INSERT INTO "topic" VALUES('X-Rays imaging and radiation','Q2','X-RAY &RADIATION TREATMENT','CTSCNAXR','Q23 How many times CT Scan after 20?','A=0, B=1-4, C=5-9, D=10-14, E=15-19, F=20+, Z=problem');
INSERT INTO "topic" VALUES('X-Rays imaging and radiation','Q2','X-RAY &RADIATION TREATMENT','RADRXXR','Q24 Ever received radiation treatment for med probs?','Y/N');
INSERT INTO "topic" VALUES('X-Rays imaging and radiation','Q5','MEDICAL IMAGING','Q33a_1990','Q33 How many times have you had an MRI before 1990?','* 0=0, 1=1-3, 2=4-7, 3=8-10, 4=11+');
INSERT INTO "topic" VALUES('X-Rays imaging and radiation','Q5','MEDICAL IMAGING','Q33a_1999','Q33 How many times have you had an MRI between 1990-1999?','* 0=0, 1=1-3, 2=4-7, 3=8-10, 4=11+');
INSERT INTO "topic" VALUES('X-Rays imaging and radiation','Q5','MEDICAL IMAGING','Q33a_2000','Q33 How many times have you had an MRI 2000 or later?','* 0=0, 1=1-3, 2=4-7, 3=8-10, 4=11+');
INSERT INTO "topic" VALUES('X-Rays imaging and radiation','Q5','MEDICAL IMAGING','Q34a_1','Q34 Have you ever had a CAT/PET scan of the head, this is answer of never.','1=Never had');
INSERT INTO "topic" VALUES('X-Rays imaging and radiation','Q5','MEDICAL IMAGING','Q34a_1990','Q34 How many times have you had a CAT?PET scan of the head before 1990?','* 0=0, 1=1-3, 2=4-7, 3=8-10, 4=11+');
INSERT INTO "topic" VALUES('X-Rays imaging and radiation','Q5','MEDICAL IMAGING','Q34a_1999','Q34 How many times have you had a CAT?PET scan of the head between 1990-1999?','* 0=0, 1=1-3, 2=4-7, 3=8-10, 4=11+');
INSERT INTO "topic" VALUES('X-Rays imaging and radiation','Q5','MEDICAL IMAGING','Q34a_2000','Q34 How many times have you had a CAT?PET scan of the head 2000 or later?','* 0=0, 1=1-3, 2=4-7, 3=8-10, 4=11+');
INSERT INTO "topic" VALUES('X-Rays imaging and radiation','Q5','MEDICAL IMAGING','Q34b_1','Q34 Have you ever had a CAT/PET scan of the neck, this is answer of never.','1=Never had');
INSERT INTO "topic" VALUES('X-Rays imaging and radiation','Q5','MEDICAL IMAGING','Q34b_1990','Q34 How many times have you had a CAT?PET scan of the neck before 1990?','* 0=0, 1=1-3, 2=4-7, 3=8-10, 4=11+');
INSERT INTO "topic" VALUES('X-Rays imaging and radiation','Q5','MEDICAL IMAGING','Q34b_1999','Q34 How many times have you had a CAT?PET scan of the neck between 1990-1999?','* 0=0, 1=1-3, 2=4-7, 3=8-10, 4=11+');
INSERT INTO "topic" VALUES('X-Rays imaging and radiation','Q5','MEDICAL IMAGING','Q34b_2000','Q34 How many times have you had a CAT?PET scan of the neck 2000 or later?','* 0=0, 1=1-3, 2=4-7, 3=8-10, 4=11+');
INSERT INTO "topic" VALUES('X-Rays imaging and radiation','Q5','MEDICAL IMAGING','Q34c_1','Q34 Have you ever had a CAT/PET scan of the chest, this is answer of never.','1=Never had');
INSERT INTO "topic" VALUES('X-Rays imaging and radiation','Q5','MEDICAL IMAGING','Q34c_1990','Q34 How many times have you had a CAT?PET scan of the chest before 1990?','* 0=0, 1=1-3, 2=4-7, 3=8-10, 4=11+');
INSERT INTO "topic" VALUES('X-Rays imaging and radiation','Q5','MEDICAL IMAGING','Q34c_1999','Q34 How many times have you had a CAT?PET scan of the chest between 1990-1999?','* 0=0, 1=1-3, 2=4-7, 3=8-10, 4=11+');
INSERT INTO "topic" VALUES('X-Rays imaging and radiation','Q5','MEDICAL IMAGING','Q34c_2000','Q34 How many times have you had a CAT?PET scan of the chest 2000 or later?','* 0=0, 1=1-3, 2=4-7, 3=8-10, 4=11+');
INSERT INTO "topic" VALUES('X-Rays imaging and radiation','Q5','MEDICAL IMAGING','Q34d_1','Q34 Have you ever had a CAT/PET scan of the spine, this is answer of never.','1=Never had');
INSERT INTO "topic" VALUES('X-Rays imaging and radiation','Q5','MEDICAL IMAGING','Q34d_1990','Q34 How many times have you had a CAT?PET scan of the spine before 1990?','* 0=0, 1=1-3, 2=4-7, 3=8-10, 4=11+');
INSERT INTO "topic" VALUES('X-Rays imaging and radiation','Q5','MEDICAL IMAGING','Q34d_1999','Q34 How many times have you had a CAT?PET scan of the spine between 1990-1999?','* 0=0, 1=1-3, 2=4-7, 3=8-10, 4=11+');
INSERT INTO "topic" VALUES('X-Rays imaging and radiation','Q5','MEDICAL IMAGING','Q34d_2000','Q34 How many times have you had a CAT?PET scan of the spine 2000 or later?','* 0=0, 1=1-3, 2=4-7, 3=8-10, 4=11+');
INSERT INTO "topic" VALUES('X-Rays imaging and radiation','Q5','MEDICAL IMAGING','Q34e_1','Q34 Have you ever had a CAT/PET scan of the abdomen/pelvis, this is answer of never.','1=Never had');
INSERT INTO "topic" VALUES('X-Rays imaging and radiation','Q5','MEDICAL IMAGING','Q34e_1990','Q34 How many times have you had a CAT?PET scan of the abdomen/pelvis before 1990?','* 0=0, 1=1-3, 2=4-7, 3=8-10, 4=11+');
INSERT INTO "topic" VALUES('X-Rays imaging and radiation','Q5','MEDICAL IMAGING','Q34e_1999','Q34 How many times have you had a CAT?PET scan of the abdomen/pelvis between 1990-1999?','* 0=0, 1=1-3, 2=4-7, 3=8-10, 4=11+');
INSERT INTO "topic" VALUES('X-Rays imaging and radiation','Q5','MEDICAL IMAGING','Q34e_2000','Q34 How many times have you had a CAT?PET scan of the abdomen/pelvis 2000 or later?','* 0=0, 1=1-3, 2=4-7, 3=8-10, 4=11+');
INSERT INTO "topic" VALUES('X-Rays imaging and radiation','Q5','MEDICAL IMAGING','Q34f_1','Q34 Have you ever had a CAT/PET scan as a heart/angiography, this is answer of never.','1=Never had');
INSERT INTO "topic" VALUES('X-Rays imaging and radiation','Q5','MEDICAL IMAGING','Q34f_1990','Q34 How many times have you had a CAT?PET scan as a heart/angiography before 1990?','* 0=0, 1=1-3, 2=4-7, 3=8-10, 4=11+');
INSERT INTO "topic" VALUES('X-Rays imaging and radiation','Q5','MEDICAL IMAGING','Q34f_1999','Q34 How many times have you had a CAT?PET scan as a heart/angiography between 1990-1999?','* 0=0, 1=1-3, 2=4-7, 3=8-10, 4=11+');
INSERT INTO "topic" VALUES('X-Rays imaging and radiation','Q5','MEDICAL IMAGING','Q34f_2000','Q34 How many times have you had a CAT?PET scan as a hear/angiography 2000 or later?','* 0=0, 1=1-3, 2=4-7, 3=8-10, 4=11+');
INSERT INTO "topic" VALUES('X-Rays imaging and radiation','Q6','MEDICAL SCREENING','Q6Web_recent_chest_xray','Participant had a chest x-ray in the last 3 months','-88 = Unable to assign value
0 = Skipped
1 = Yes, one x-ray
2 = Yes, more than one x-ray
3 = No
4 = Don''t know');
INSERT INTO "topic" VALUES('Personal medical history','Q1','HEALTH HISTORY','BRIMPLNT','Q59 Have you ever had breast implants?','A=No, B=Yes, after br ca, C=Yes, other reasons, D=Ans both "B" & "C", F/Z=Problem');
INSERT INTO "topic" VALUES('Personal medical history','Q1','HEALTH HISTORY','BRIMAGEF','Q60 What age did you first have breast implants?','A=<25, B=25-29, C=30-34, D=35-39, E=40-44, F=45-49,  G=50-54,  H=55-59,  I=60-64,  J=65+, Z=Problem');
INSERT INTO "topic" VALUES('Personal medical history','Q1','HEALTH HISTORY','BRIMKIND','Q61 What kind of breast implants have you had?','A=Silicone gel, B=Saline, C=Both, D=DK');
INSERT INTO "topic" VALUES('Personal medical history','Q1','HEALTH HISTORY','BLDTRAN1','Q64 Have you ever had a blood transfusion - No?','A=Yes');
INSERT INTO "topic" VALUES('Personal medical history','Q1','HEALTH HISTORY','BLDTRAN2','Q64 Have you ever had a blood transfusion-before35?','A=Yes');
INSERT INTO "topic" VALUES('Personal medical history','Q1','HEALTH HISTORY','BLDTRAN3','Q64 Have you ever had a blood transfusion - 35-44?','A=Yes');
INSERT INTO "topic" VALUES('Personal medical history','Q1','HEALTH HISTORY','BLDTRAN4','Q64 Have you ever had a blood transfusion - 45-54?','A=Yes');
INSERT INTO "topic" VALUES('Personal medical history','Q1','HEALTH HISTORY','BLDTRAN5','Q64 Have you ever had a blood transfusion - 55-64?','A=Yes');
INSERT INTO "topic" VALUES('Personal medical history','Q1','HEALTH HISTORY','BLDTRAN6','Q64 Have you ever had a blood transfusion -after 64?','A=Yes');
INSERT INTO "topic" VALUES('Personal medical history','Q1','PERSONAL & FAMILY MEDICAL HISTORY','GALLSELF','Q67 Have you ever had Gall Stones?','A=Yes');
INSERT INTO "topic" VALUES('Personal medical history','Q1','PERSONAL & FAMILY MEDICAL HISTORY','DIABSELF','Q67 Have you ever had Diabetes?','A=Yes');
INSERT INTO "topic" VALUES('Personal medical history','Q1','PERSONAL & FAMILY MEDICAL HISTORY','HIPFSELF','Q67 Have you ever had Hip Fracture?','A=Yes');
INSERT INTO "topic" VALUES('Personal medical history','Q1','PERSONAL & FAMILY MEDICAL HISTORY','FIBRSELF','Q67 Have you ever had Fibroids/Womb?','A=Yes');
INSERT INTO "topic" VALUES('Personal medical history','Q1','PERSONAL & FAMILY MEDICAL HISTORY','ENMTSELF','Q67 Have you ever had Endometriosis?','A=Yes');
INSERT INTO "topic" VALUES('Personal medical history','Q1','PERSONAL & FAMILY MEDICAL HISTORY','MIGRSELF','Q67 Have you ever had Migraines?','A=Yes');
INSERT INTO "topic" VALUES('Personal medical history','Q1','PERSONAL & FAMILY MEDICAL HISTORY','POLYSELF','Q67 Have you ever had Colon/Rect Polyps?','A=Yes');
INSERT INTO "topic" VALUES('Personal medical history','Q1','PERSONAL & FAMILY MEDICAL HISTORY','THDSSELF','Q67 Have you ever had Thyroid Dis?','A=Yes');
INSERT INTO "topic" VALUES('Personal medical history','Q1','PERSONAL & FAMILY MEDICAL HISTORY','MOLESELF','Q67 Have you ever had Moles Removed?','A=Yes');
INSERT INTO "topic" VALUES('Personal medical history','Q1','PERSONAL & FAMILY MEDICAL HISTORY','STRKSELF','Q67 Have you ever had Stroke?','A=Yes');
INSERT INTO "topic" VALUES('Personal medical history','Q1','PERSONAL & FAMILY MEDICAL HISTORY','HTAKSELF','Q67 Have you ever had Heart Attack?','A=Yes');
INSERT INTO "topic" VALUES('Personal medical history','Q1','PERSONAL & FAMILY MEDICAL HISTORY','HBPSELF','Q67 Have you ever had Hi Blood Press?','A=Yes');
INSERT INTO "topic" VALUES('Personal medical history','Q2','PREGNANCY UPDATE','PRECL','Q21 In all pregs, were you diagnosed w/pre-eclampsia?','Y/N');
INSERT INTO "topic" VALUES('Personal medical history','Q2','PREGNANCY UPDATE','PRECLMMR','Q22 Were you diagnosed for most recent preg?','Y/N');
INSERT INTO "topic" VALUES('Personal medical history','Q3','ILLNESS','ASTHMA','Q20 Doctor ever said you have asthma?','Y/N');
INSERT INTO "topic" VALUES('Personal medical history','Q3','ILLNESS','ASTHAGE','Q21 Age when doctor diagnosed asthma','A=0-4, B=5-18, C=19-34, D=35+');
INSERT INTO "topic" VALUES('Personal medical history','Q3','ILLNESS','ASTHNOT','Q22 Asthma symptoms no trouble','Y');
INSERT INTO "topic" VALUES('Personal medical history','Q3','ILLNESS','ASTHMLD','Q22 Asthma symptoms mild','Y');
INSERT INTO "topic" VALUES('Personal medical history','Q3','ILLNESS','ASTHMED','Q22 Asthma symptoms took medication','Y');
INSERT INTO "topic" VALUES('Personal medical history','Q3','ILLNESS','ASTHDOC','Q22 Asthma symptoms urgent visit to doctor','Y');
INSERT INTO "topic" VALUES('Personal medical history','Q3','ILLNESS','ASTHHOSP','Q22 Asthma symptoms spent night in hospital','Y');
INSERT INTO "topic" VALUES('Personal medical history','Q3','ILLNESS','ASTHNOW1','Q22 CURRENT ASTHMA SYMPTOMS - excludes mildest','Y/N');
INSERT INTO "topic" VALUES('Personal medical history','Q3','ILLNESS','ASTHNOW2','Q22 CURRENT ASTHMA SYMPTOMS - includes mildest','Y/N');
INSERT INTO "topic" VALUES('Personal medical history','Q3','ILLNESS','ASTHSEV','Q22 ASTHMA SEVERITY','1-4, 1=mild symptoms, 2=meds, 3=doctor, 4=hospital');
INSERT INTO "topic" VALUES('Personal medical history','Q3','ILLNESS','ASTHAGE1','Q20-21 AGE WHEN DOCTOR DIAGNOSED ASTHMA','A=0-4yr, B=5-18yr, C=19-34yr, D=35 or older');
INSERT INTO "topic" VALUES('Personal medical history','Q4','HEALTH','DBPRE','Q15 Were you ever told by a health professional that you have borderline diabetes or pre-diabetes? (No or Yes)','Y=Yes, N=No');
INSERT INTO "topic" VALUES('Personal medical history','Q4','HEALTH','DBPRG','Q15 Were you ever told by a health professional that you have gestational diabetes? (No or Yes)','Y=Yes, N=No');
INSERT INTO "topic" VALUES('Personal medical history','Q4','HEALTH','DBT12','Q15 Were you ever told by a health professional that you have type 1 or 2 diabetes? (No or Yes)','Y=Yes, N=No');
INSERT INTO "topic" VALUES('Personal medical history','Q4','HEALTH','DBPREAGE','Q15 Age you were first told you had borderline diabetes or pre-diabetes? ','A=0-4, B=5-18, C=19-34, D=35-44, E=45-54, F=55-64, G=65+');
INSERT INTO "topic" VALUES('Personal medical history','Q4','HEALTH','DBPRGAGE','Q15 Age you were first told you had gestational diabetes? ','A=0-4, B=5-18, C=19-34, D=35-44, E=45-54, F=55-64, G=65+');
INSERT INTO "topic" VALUES('Personal medical history','Q4','HEALTH','DBT12AGE','Q15 Age you were first told you had type 1 or 2 diabetes? ','A=0-4, B=5-18, C=19-34, D=35-44, E=45-54, F=55-64, G=65+');
INSERT INTO "topic" VALUES('Personal medical history','Q4','HEALTH','DBINS','Q16 Are you currently taking insulin? (No or Yes)','Y=Yes, N=No');
INSERT INTO "topic" VALUES('Personal medical history','Q4','HEALTH','DBINSY','Q16 For how many years have you been taking insulin? ','A=<1yr, B=1-4, C=5-9, D=10-14, E=15-19, F=20-29, G=30+');
INSERT INTO "topic" VALUES('Personal medical history','Q4','HEALTH','DBPIL','Q17 Are you currently taking pills to lower your blood sugar? These are sometimes called oral hypoglycemic agents. (No or Yes)','Y=Yes, N=No, C=DK because participating research study');
INSERT INTO "topic" VALUES('Personal medical history','Q4','HEALTH','DBPILY','Q17 For how many years have you been taking these pills to lower your blood pressure? ','A=<1yr, B=1-4, C=5-9, D=10-14, E=15-19, F=20-29, G=30+');
INSERT INTO "topic" VALUES('Personal medical history','Q4','HEALTH','ASTHMAQ4','Q18 Were you ever told by a health professional that you have asthma? (No or Yes) ','Y=Yes, N=No, Z=Problem');
INSERT INTO "topic" VALUES('Personal medical history','Q4','HEALTH','ASTHAGQ4','Q18 Age you were first told you had asthma? ','* A=0-4, B=5-18, C=19-34, D=35-44, E=45-54, F=55+, Z=Problem');
INSERT INTO "topic" VALUES('Personal medical history','Q4','HEALTH','ASTHYR','Q18 What year were you first told you had asthma? ','A=Before 2000, B=2000, C=2001, D=2002, E=2003, F=2004, G=2005, Z=Problem');
INSERT INTO "topic" VALUES('Personal medical history','Q4','HEALTH','ASTHFRQ','Q18 During the past 12 months, on average, how often did you have any symptoms of asthma apart from a cold or respiratory infection? ','A=None, B=<1/wk, C=1 or 2/wk, D=>2/wk (<then daily), E=Daily certain seasons, F=Daily all the time, Z=Problem');
INSERT INTO "topic" VALUES('Personal medical history','Q4','HEALTH','ASTHNTQ4','Q18 During the past 12 months, you have not been troubled by asthma. ','Y=Yes');
INSERT INTO "topic" VALUES('Personal medical history','Q4','HEALTH','ASTHMLQ4','Q18 During the past 12 months, you had mild symptoms for which you have not taken any asthma medication . ','Y=Yes');
INSERT INTO "topic" VALUES('Personal medical history','Q4','HEALTH','ASTHMDQ4','Q18 During the past 12 months, you have had asthma symptoms requiring asthma medication. ','Y=Yes');
INSERT INTO "topic" VALUES('Personal medical history','Q4','HEALTH','ASTHDRQ4','Q18 During the past 12 months, you have had asthma symptoms requiring an urgent visit to a doctor or emergency care. ','Y=Yes');
INSERT INTO "topic" VALUES('Personal medical history','Q4','HEALTH','ASTHHPQ4','Q18 During the past 12 months, you have had asthma symptoms requiring you to stay overnight at a hospital. ','Y=Yes');
INSERT INTO "topic" VALUES('Personal medical history','Q4','HEALTH','PNEUEV','Q19 Were you every told by a health professional that you have penumonia? ','Y=Yes, N=No, Z=Problem');
INSERT INTO "topic" VALUES('Personal medical history','Q4','HEALTH','HAYFEV','Q19 Were you every told by a health professional that you have allergic rhinitis? ','Y=Yes, N=No, Z=Problem');
INSERT INTO "topic" VALUES('Personal medical history','Q4','HEALTH','PARKEV','Q20 Were you ever told by a health professional that you have Parkinson''s disease? (No or Yes) ','Y=Yes, N=No');
INSERT INTO "topic" VALUES('Personal medical history','Q4','HEALTH','MONOEV','Q21 Were you ever told by a health professional that you have infectious mononucleosis or "mono"? ','A=No, B=Yes < age 15, C=Yes 15-19, D=Yes age 20-24, E=Yes age 25+, Z=Problem');
INSERT INTO "topic" VALUES('Personal medical history','Q4','HEALTH','ENMTEV','Q22 Were you ever told by a health professional that you have endometriosis? ','A=No, B=Yes < age 20, C=Yes 20-29, D=Yes age 30-39, E=Yes age 40+, Z=Problem');
INSERT INTO "topic" VALUES('Personal medical history','Q4','HEALTH','MASTNUM','Q22 How many times were you told by a health professional that you have mastitis (a breast infection)? ','A=None, B=1-2 times, C=3-4 times, D=5 or more times, Z=Problem');
INSERT INTO "topic" VALUES('Personal medical history','Q4','HEALTH','PARKAG','Q20 Generated variable for age you were diagnosed with Parkinson''s disease','37-95');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43b_Age','Q43 How old were you when you were first told you had a heart attack?','* 1=<35 years, 2=35-49, 3=50-64, 4=65-74, 5=75+');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43b_Ever','Q43 Have you ever taken medication for a heart attack?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43b_Cur','Q43 Are you currently taking medication for a heart attack?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43c_Ever','Q43 Have you ever taken medication for a stroke?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43c_Cur','Q43 Are you currently taking medication for a stroke?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43d_Ever','Q43 Have you ever taken medication for a deep vein thrombosis?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43d_Cur','Q43 Are you currently taking medication for a deep vein thrombosis?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43e_Ever','Q43 Have you ever taken medication for COPD?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43e_Cur','Q43 Are you currently taking medication for COPD?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43f_Ever','Q43 Have you ever taken medication for osteoporosis?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43f_Cur','Q43 Are you currently taking medication for osteoporosis?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43g_Ever','Q43 Have you ever taken medication for pneumonia?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43g_Cur','Q43 Are you currently taking medication for pneumonia?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43h_Ever','Q43 Have you ever taken medication for Parkinson''s disease?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43h_Cur','Q43 Are you currently taking medication for Parkinson''s disease?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43i_Ever','Q43 Have you ever taken medication for depression?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43i_Cur','Q43 Are you currently taking medication for depression?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43j_Ever','Q43 Have you ever taken medication for shingles?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43j_Cur','Q43 Are you currently taking medication for shingles?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43k_Ever','Q43 Have you ever taken medication for an ulcer?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43k_Cur','Q43 Are you currently taking medication for an ulcer?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43l_Ever','Q43 Have you ever taken medication for kidney stones?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43l_Cur','Q43 Are you currently taking medication for kidney stones?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43m_Ever','Q43 Have you ever taken medication for kidney disease?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43m_Cur','Q43 Are you currently taking medication for kidney disease?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43n_Ever','Q43 Have you ever taken medication for chronic fatigue syndrome?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43n_Cur','Q43 Are you currently taking medication for chronic fatigue syndrome?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43o_Ever','Q43 Have you ever taken medication for osteoarthritis?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43o_Cur','Q43 Are you currently taking medication for osteoarthritis?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43p_Ever','Q43 Have you ever taken medication for rheumatoid arthritis?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43p_Cur','Q43 Are you currently taking medication for rheumatoid arthritis?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43q_Ever','Q43 Have you ever taken medication for lupus?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43q_Cur','Q43 Are you currently taking medication for lupus?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43r_Ever','Q43 Have you ever taken medication for IBD or Crohn''s disease?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43r_Cur','Q43 Are you currently taking medication for IBD or Crohn''s disease?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43s_Ever','Q43 Have you ever taken medication for multiple sclerosis?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43s_Cur','Q43 Are you currently taking medication for multiple sclerosis?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43t_Ever','Q43 Have you ever taken medication for psoriasis?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43t_Cur','Q43 Are you currently taking medication for psoriasis?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Personal medical history','Q5','HEALTH','Q31_1','Q31 Has a health professional ever told you that you have diabetes? ','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Personal medical history','Q5','HEALTH','Q31_2','Q31 Which type of diabetes do you have: Type I (also known as insulin-dependent diabetes or IDDM)
 Type II (also known as non-insulin dependent diabetes or NIDDM)','* 1=Type I, 2=Type II');
INSERT INTO "topic" VALUES('Personal medical history','Q5','HEALTH','Q31a','Q31 Written answer for "How old were you when you were diagnosed with diabetes"? The possibilities for each column are either a *, a blank, or a number. ','written values see description column');
INSERT INTO "topic" VALUES('Personal medical history','Q5','HEALTH','Q31b_1','Q31 Was your diabetes treated when you were first diagnosis, this is answer of ''not treated''.','1=Not treated');
INSERT INTO "topic" VALUES('Personal medical history','Q5','HEALTH','Q31b_2','Q31 Diabetes when first diagnosed was treated with diet. ','1=Diet');
INSERT INTO "topic" VALUES('Personal medical history','Q5','HEALTH','Q31b_3','Q31 Diabetes when first diagnosed was treated with injection. ','1=Injection');
INSERT INTO "topic" VALUES('Personal medical history','Q5','HEALTH','Q31b_4','Q31 Diabetes when first diagnosed was treated with Metformin or Glucophage. ','1=Metformin/Glucophage');
INSERT INTO "topic" VALUES('Personal medical history','Q5','HEALTH','Q31b_5','Q31 Diabetes when first diagnosed was treated with another mediation. ','1=Another medication');
INSERT INTO "topic" VALUES('Personal medical history','Q5','HEALTH','Q31b_6','Q31 Diabetes when first diagnosed was treated with other method not listed. ','1=Other  ');
INSERT INTO "topic" VALUES('Personal medical history','Q5','HEALTH','Q31c_1','Q31 Is your diabetes currently treated, this is answer of ''not treated''.','1=Not treated');
INSERT INTO "topic" VALUES('Personal medical history','Q5','HEALTH','Q31c_2','Q31 Diabetes is currently being treated with diet.','1=Diet');
INSERT INTO "topic" VALUES('Personal medical history','Q5','HEALTH','Q31c_3','Q31 Diabetes is currently being treated with injection.','1=Injection');
INSERT INTO "topic" VALUES('Personal medical history','Q5','HEALTH','Q31c_4','Q31 Diabetes is currently being treated with Metformin or Glucophage.','1=Metformin/Glucophage');
INSERT INTO "topic" VALUES('Personal medical history','Q5','HEALTH','Q31c_5','Q31 Diabetes is currently being treated with another medication.','1=Another medication');
INSERT INTO "topic" VALUES('Personal medical history','Q5','HEALTH','Q31c_6','Q31 Diabetes is currently being treated with other method not listed.','1=Other  ');
INSERT INTO "topic" VALUES('Personal medical history','Q5','HEALTH','Q31d_1','Q31 Do you use a blood glucose kit to monitor your blood glucose levels?','1=Yes, 0=No');
INSERT INTO "topic" VALUES('Personal medical history','Q5','HEALTH','Q31d_2','Q31 Frequency of use of a blood glucose kit to monitor blood glucose levels?','* 1=More than once a day, 2=Ususally once a day, 3=Only occasionally');
INSERT INTO "topic" VALUES('Personal medical history','Q5','HEALTH','Q31e_1','Q31 Have you had your Hemoglobin A1C measured in the past 6 months?','1=Yes, 0=No');
INSERT INTO "topic" VALUES('Personal medical history','Q5','HEALTH','Q31e_2','Q31 Hemoglobiin A1C score as measured in the past 6 months.','* 1=<6%, 2=6%-<7%, 3=7%-8%, 4=Over 8%, 5=Don''t know');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43a_Type','Q43 Has a health professional ever told you that you had hypertension?','* 0=No, 1=Yes, 2=Don''t know');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43a_Age','Q43 How old were you when you were first told you had hypertension?','* 1=<35 years, 2=35-49, 3=50-64, 4=65-74, 5=75+');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43a_Ever','Q43 Have you ever taken medication for hypertension?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43a_Cur','Q43 Are you currently taking medication for hypertension?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43b_Type','Q43 Has a health professional ever told you that you had a heart attack?','* 0=No, 1=Yes, 2=Don''t know');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43c_Type','Q43 Has a health professional ever told you that you had a stroke?','* 0=No, 1=Yes, 2=Don''t know');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43d_Type','Q43 Has a health professional ever told you that you had a deep vein thrombosis?','* 0=No, 1=Yes, 2=Don''t know');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43e_Type','Q43 Has a health professional ever told you that you had COPD?','* 0=No, 1=Yes, 2=Don''t know');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43f_Type','Q43 Has a health professional ever told you that you had osteoporosis?','* 0=No, 1=Yes, 2=Don''t know');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43g_Type','Q43 Has a health professional ever told you that you had pneumonia?','* 0=No, 1=Yes, 2=Don''t know');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43h_Type','Q43 Has a health professional ever told you that you had Parkinson''s disease?','* 0=No, 1=Yes, 2=Don''t know');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43i_Type','Q43 Has a health professional ever told you that you had depression?','* 0=No, 1=Yes, 2=Don''t know');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43j_Type','Q43 Has a health professional ever told you that you had shingles?','* 0=No, 1=Yes, 2=Don''t know');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43k_Type','Q43 Has a health professional ever told you that you had an ulcer?','* 0=No, 1=Yes, 2=Don''t know');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43l_Type','Q43 Has a health professional ever told you that you had kidney stones?','* 0=No, 1=Yes, 2=Don''t know');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43m_Type','Q43 Has a health professional ever told you that you had kidney disease?','* 0=No, 1=Yes, 2=Don''t know');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43n_Type','Q43 Has a health professional ever told you that you had chronic fatigue syndrome?','* 0=No, 1=Yes, 2=Don''t know');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43o_Type','Q43 Has a health professional ever told you that you had osteoarthritis?','* 0=No, 1=Yes, 2=Don''t know');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43p_Type','Q43 Has a health professional ever told you that you had rheumatoid arthritis?','* 0=No, 1=Yes, 2=Don''t know');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43q_Type','Q43 Has a health professional ever told you that you had lupus?','* 0=No, 1=Yes, 2=Don''t know');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43r_Type','Q43 Has a health professional ever told you that you had IBD or Crohn''s disease?','* 0=No, 1=Yes, 2=Don''t know');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43s_Type','Q43 Has a health professional ever told you that you had multiple sclerosis?','* 0=No, 1=Yes, 2=Don''t know');
INSERT INTO "topic" VALUES('Personal medical history','Q5','MEDICAL CONDITIONS','Q43t_Type','Q43 Has a health professional ever told you that you had psoriasis?','* 0=No, 1=Yes, 2=Don''t know');
INSERT INTO "topic" VALUES('Personal medical history','Q5','BODY SIZE','Q47a','Q47 Have you had gastric bypass or lap-band surgery? (no yes)','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Personal medical history','Q5','BODY SIZE','Q47b','Q47 What type of gastric bypass or lap-band surgery have you had?','* 1=Lap-band, 2=Roux-en-Y bypass, 3=Other gastric bypass surgery');
INSERT INTO "topic" VALUES('Personal medical history','Q5mini','HEALTH','Q31_1','Q31 Has a health professional ever told you that you have diabetes? ','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Personal medical history','Q5mini','HEALTH','Q31_2','Q31 Which type of diabetes do you have: Type I (also known as insulin-dependent diabetes or IDDM)
 Type II (also known as non-insulin dependent diabetes or NIDDM)','* 1=Type I, 2=Type II');
INSERT INTO "topic" VALUES('Personal medical history','Q6','HEALTH CONDITIONS','Q6Web_dxd_arthritis','Diagnosed by a health professional as having Arthritis: Osteoarthritis ','-88 = Unable to assign value
0 = Skipped
1 = Yes
2 = No');
INSERT INTO "topic" VALUES('Personal medical history','Q6','HEALTH CONDITIONS','Q6Web_dxd_rheumarthritis','Diagnosed by a health professional as having Arthritis: Rheumatoid arthritis ','-88 = Unable to assign value
0 = Skipped
1 = Yes
2 = No');
INSERT INTO "topic" VALUES('Personal medical history','Q6','HEALTH CONDITIONS','Q6Web_dxd_asthma','Diagnosed by a health professional as having Asthma','-88 = Unable to assign value
0 = Skipped
1 = Yes
2 = No');
INSERT INTO "topic" VALUES('Personal medical history','Q6','HEALTH CONDITIONS','Q6Web_dxd_T2D','Diagnosed by a health professional as having Diabetes Type 2 ("Type 2 Diabetes")','-88 = Unable to assign value
0 = Skipped
1 = Yes
2 = No');
INSERT INTO "topic" VALUES('Personal medical history','Q6','HEALTH CONDITIONS','Q6Web_dxd_DVT','Diagnosed by a health professional as having Deep vein thrombosis (DVT)','-88 = Unable to assign value
0 = Skipped
1 = Yes
2 = No');
INSERT INTO "topic" VALUES('Personal medical history','Q6','HEALTH CONDITIONS','Q6Web_dxd_depression','Diagnosed by a health professional as having Depression','-88 = Unable to assign value
0 = Skipped
1 = Yes
2 = No');
INSERT INTO "topic" VALUES('Personal medical history','Q6','HEALTH CONDITIONS','Q6Web_dxd_cholesterol','Diagnosed by a health professional as having High cholesterol','-88 = Unable to assign value
0 = Skipped
1 = Yes
2 = No');
INSERT INTO "topic" VALUES('Personal medical history','Q6','HEALTH CONDITIONS','Q6Web_dxd_DBP','Diagnosed by a health professional as having Hypertension / high blood pressure ','-88 = Unable to assign value
0 = Skipped
1 = Yes
2 = No');
INSERT INTO "topic" VALUES('Personal medical history','Q6','HEALTH CONDITIONS','Q6Web_dxd_inflammatorybowel','Diagnosed by a health professional as having Inflammatory bowel disease or Crohn''s disease ','-88 = Unable to assign value
0 = Skipped
1 = Yes
2 = No');
INSERT INTO "topic" VALUES('Personal medical history','Q6','HEALTH CONDITIONS','Q6Web_dxd_kidneydisease','Diagnosed by a health professional as having Kidney disease (not kidney stones) ','-88 = Unable to assign value
0 = Skipped
1 = Yes
2 = No');
INSERT INTO "topic" VALUES('Personal medical history','Q6','HEALTH CONDITIONS','Q6Web_dxd_kidneystones','Diagnosed by a health professional as having Kidney stones','-88 = Unable to assign value
0 = Skipped
1 = Yes
2 = No');
INSERT INTO "topic" VALUES('Personal medical history','Q6','HEALTH CONDITIONS','Q6Web_dxd_migraines','Diagnosed by a health professional as having Migraines','-88 = Unable to assign value
0 = Skipped
1 = Yes
2 = No');
INSERT INTO "topic" VALUES('Personal medical history','Q6','HEALTH CONDITIONS','Q6Web_dxd_osteoporosis','Diagnosed by a health professional as having Osteoporosis ','-88 = Unable to assign value
0 = Skipped
1 = Yes
2 = No');
INSERT INTO "topic" VALUES('Personal medical history','Q6','HEALTH CONDITIONS','Q6Web_dxd_parkinsons','Diagnosed by a health professional as having Parkinson''s disease','-88 = Unable to assign value
0 = Skipped
1 = Yes
2 = No');
INSERT INTO "topic" VALUES('Personal medical history','Q6','HEALTH CONDITIONS','Q6Web_dxd_periodontal','Diagnosed by a health professional as having Periodontal disease or gum disease / gingivitis ','-88 = Unable to assign value
0 = Skipped
1 = Yes
2 = No');
INSERT INTO "topic" VALUES('Personal medical history','Q6','HEALTH CONDITIONS','Q6Web_dxs_psoriasis','Diagnosed by a health professional as having Psoriasis','-88 = Unable to assign value
0 = Skipped
1 = Yes
2 = No');
INSERT INTO "topic" VALUES('Personal medical history','Q6','HEALTH CONDITIONS','Q6Web_dxd_shingles','Diagnosed by a health professional as having Shingles ','-88 = Unable to assign value
0 = Skipped
1 = Yes
2 = No');
INSERT INTO "topic" VALUES('Personal medical history','Q6','HEALTH CONDITIONS','Q6Web_dxd_sleepapnea','Diagnosed by a health professional as having Sleep apnea','-88 = Unable to assign value
0 = Skipped
1 = Yes
2 = No');
INSERT INTO "topic" VALUES('Personal medical history','Q6','HEALTH CONDITIONS','Q6Web_dxd_sleep_disorder','Diagnosed with any kind of sleep disorder, including but not limited to: restless leg syndrome, REM sleep behavior disorder, narcolepsy, cataplexy, chronic circadian disorder','-88 = Unable to assign value
0 = Skipped
1 = Yes
2 = No');
INSERT INTO "topic" VALUES('Personal history of cancer','Q1','HEALTH HISTORY','BRCA','Q57 Have you ever had breast cancer?','N/Y');
INSERT INTO "topic" VALUES('Personal history of cancer','Q1','HEALTH HISTORY','BRCADGX','Q58 RECONSTITUTED -Age first dx brest cancer','13-95, .Z=Problem');
INSERT INTO "topic" VALUES('Personal history of cancer','Q1','PERSONAL & FAMILY MEDICAL HISTORY','BRC5SELF','Q67 Have you ever had breast cancer under 50?','A=Yes');
INSERT INTO "topic" VALUES('Personal history of cancer','Q1','PERSONAL & FAMILY MEDICAL HISTORY','BRCASELF','Q67 Have you ever had breast cancer over age 50?','A=Yes');
INSERT INTO "topic" VALUES('Personal history of cancer','Q1','PERSONAL & FAMILY MEDICAL HISTORY','ENDOSELF','Q67 Have you ever had endometrial cancer?','A=Yes');
INSERT INTO "topic" VALUES('Personal history of cancer','Q1','PERSONAL & FAMILY MEDICAL HISTORY','CERVSELF','Q67 Have you ever had cervical cancer?','A=Yes');
INSERT INTO "topic" VALUES('Personal history of cancer','Q1','PERSONAL & FAMILY MEDICAL HISTORY','OVRYSELF','Q67 Have you ever had ovarian cancer?','A=Yes');
INSERT INTO "topic" VALUES('Personal history of cancer','Q1','PERSONAL & FAMILY MEDICAL HISTORY','LUNGSELF','Q67 Have you ever had lung cancer?','A=Yes');
INSERT INTO "topic" VALUES('Personal history of cancer','Q1','PERSONAL & FAMILY MEDICAL HISTORY','LEUKSELF','Q67 Have you ever had leukemia?','A=Yes');
INSERT INTO "topic" VALUES('Personal history of cancer','Q1','PERSONAL & FAMILY MEDICAL HISTORY','HODGSELF','Q67 Have you ever had Hodgkins Dis?','A=Yes');
INSERT INTO "topic" VALUES('Personal history of cancer','Q1','PERSONAL & FAMILY MEDICAL HISTORY','COLNSELF','Q67 Have you ever had Colon/Rect cancer?','A=Yes');
INSERT INTO "topic" VALUES('Personal history of cancer','Q1','PERSONAL & FAMILY MEDICAL HISTORY','THYRSELF','Q67 Have you ever had Thyroid cancer?','A=Yes');
INSERT INTO "topic" VALUES('Personal history of cancer','Q1','PERSONAL & FAMILY MEDICAL HISTORY','MELNSELF','Q67 Have you ever had Malig Melanoma?','A=Yes');
INSERT INTO "topic" VALUES('Personal history of cancer','Q1','PERSONAL & FAMILY MEDICAL HISTORY','NEVCSELF','Q67 Never had any cancer - self?','A=Yes');
INSERT INTO "topic" VALUES('Personal history of cancer','Q1','PERSONAL & FAMILY MEDICAL HISTORY','BRCANLX','Q67 BREAST CANCER SELF(SURVEY DATA ONLY)','Y=Yes, N=No, A=Relevant vas blank');
INSERT INTO "topic" VALUES('Personal history of cancer','Q4','FAMILY CANCER HISTORY','SXSELF','Q32 Answer of gender for self (only answer of female allowed).','F=Female');
INSERT INTO "topic" VALUES('Family history of cancer','Q1','PERSONAL & FAMILY MEDICAL HISTORY','NEVCMOM','Q67 Never had any cancer - mom?','A=Yes');
INSERT INTO "topic" VALUES('Family history of cancer','Q1','PERSONAL & FAMILY MEDICAL HISTORY','NEVCDAD','Q67 Never had any cancer - dad?','A=Yes');
INSERT INTO "topic" VALUES('Family history of cancer','Q1','PERSONAL & FAMILY MEDICAL HISTORY','BRCAFAM','Q67 FAMILY HISTORY OF BREAST CANCER','0-3, 0=No family hx of specific cancer, 1=Yes 1+ 1st degree relative, 2=Adopted, 3=No info on family hx');
INSERT INTO "topic" VALUES('Family history of cancer','Q1','PERSONAL & FAMILY MEDICAL HISTORY','ENDOFAM','Q67 FAMILY HISTORY OF ENDOMETRIAL CANCER','0-3, 0=No family hx of specific cancer, 1=Yes 1+ 1st degree relative, 2=Adopted, 3=No info on family hx');
INSERT INTO "topic" VALUES('Family history of cancer','Q1','PERSONAL & FAMILY MEDICAL HISTORY','OVRYFAM','Q67 FAMILY HISTORY OF OVARIAN CANCER','0-3, 0=No family hx of specific cancer, 1=Yes 1+ 1st degree relative, 2=Adopted, 3=No info on family hx');
INSERT INTO "topic" VALUES('Family history of cancer','Q1','PERSONAL & FAMILY MEDICAL HISTORY','CERVFAM','Q67 FAMILY HISTORY OF CERVICAL CANCER','0-3, 0=No family hx of specific cancer, 1=Yes 1+ 1st degree relative, 2=Adopted, 3=No info on family hx');
INSERT INTO "topic" VALUES('Family history of cancer','Q1','PERSONAL & FAMILY MEDICAL HISTORY','LUNGFAM','Q67 FAMILY HISTORY OF LUNG CANCER','0-3, 0=No family hx of specific cancer, 1=Yes 1+ 1st degree relative, 2=Adopted, 3=No info on family hx');
INSERT INTO "topic" VALUES('Family history of cancer','Q1','PERSONAL & FAMILY MEDICAL HISTORY','LEUKFAM','Q67 FAMILY HISTORY OF LEUKEMIA','0-3, 0=No family hx of specific cancer, 1=Yes 1+ 1st degree relative, 2=Adopted, 3=No info on family hx');
INSERT INTO "topic" VALUES('Family history of cancer','Q1','PERSONAL & FAMILY MEDICAL HISTORY','HODGFAM','Q67 FAMILY HISTORY OF HODGKINS OR LYMPHOMA','0-3, 0=No family hx of specific cancer, 1=Yes 1+ 1st degree relative, 2=Adopted, 3=No info on family hx');
INSERT INTO "topic" VALUES('Family history of cancer','Q1','PERSONAL & FAMILY MEDICAL HISTORY','THYRFAM','Q67 FAMILY HISTORY OF THYROID CANCER','0-3, 0=No family hx of specific cancer, 1=Yes 1+ 1st degree relative, 2=Adopted, 3=No info on family hx');
INSERT INTO "topic" VALUES('Family history of cancer','Q1','PERSONAL & FAMILY MEDICAL HISTORY','COLNFAM','Q67 FAMILY HISTORY OF COLORECTAL CANCER','0-3, 0=No family hx of specific cancer, 1=Yes 1+ 1st degree relative, 2=Adopted, 3=No info on family hx');
INSERT INTO "topic" VALUES('Family history of cancer','Q1','PERSONAL & FAMILY MEDICAL HISTORY','MELNFAM','Q67 FAMILY HISTORY OF MELANOMA','0-3, 0=No family hx of specific cancer, 1=Yes 1+ 1st degree relative, 2=Adopted, 3=No info on family hx');
INSERT INTO "topic" VALUES('Family history of cancer','Q1','PERSONAL & FAMILY MEDICAL HISTORY','PROSFAM','Q67 FAMILY HISTORY OF PROSTATE CANCER','0-3, 0=No family hx of specific cancer, 1=Yes 1+ 1st degree relative, 2=Adopted, 3=No info on family hx');
INSERT INTO "topic" VALUES('Mammograms and other health screenings','Q1','HEALTH HISTORY','EXMMAMMO','Q62 Have you ever had a mammogram?','N/Y');
INSERT INTO "topic" VALUES('Mammograms and other health screenings','Q1','HEALTH HISTORY','EXMBRXM','Q62 Have you ever had a breast exam?','N/Y/Z');
INSERT INTO "topic" VALUES('Mammograms and other health screenings','Q1','HEALTH HISTORY','EXMPAPSM','Q62 Have you ever had a PAP smear?','N/Y/Z');
INSERT INTO "topic" VALUES('Mammograms and other health screenings','Q1','HEALTH HISTORY','MAMSCRN','Q62 YRS SINCE LAST MAMMOGRAM FRM Q62','0-4, 0=Never had, 1=Y_<1yr, 2=Y_1-2yrs, 3=Y_3+yrs, 4=Y_Uyrs, .U=Unk');
INSERT INTO "topic" VALUES('Mammograms and other health screenings','Q1','HEALTH HISTORY','BRXMSCRN','Q62 YRS SINCE LAST BREAST EXAM FRM Q62','0-4, 0=Never had, 1=Y_<1yr, 2=Y_1-2yrs, 3=Y_3+yrs, 4=Y_Uyrs, .U=Unk');
INSERT INTO "topic" VALUES('Mammograms and other health screenings','Q1','HEALTH HISTORY','PAPSCRN','Q62 YRS SINCE LAST PAP SMEAR FRM Q62','0-4, 0=Never had, 1=Y_<1yr, 2=Y_1-2yrs, 3=Y_3+yrs, 4=Y_Uyrs, .U=Unk');
INSERT INTO "topic" VALUES('Mammograms and other health screenings','Q1','HEALTH HISTORY','BREXSELF','Q63 How often examined breasts in last year?','A=Rarely, B=2-3 times, C=2-3 months, D=Once a month, E=More than once a month');
INSERT INTO "topic" VALUES('Mammograms and other health screenings','Q1','PERSONAL & FAMILY MEDICAL HISTORY','BRBXSELF','Q67 Have you ever had Breast Biopsy?','A=Yes');
INSERT INTO "topic" VALUES('Mammograms and other health screenings','Q2','X-RAY &RADIATION TREATMENT','MAMMOAXR','Q23 How many times had mammogram after age 20?','A=0, B=1-4, C=5-9, D=10-14, E=15-19, F=20+, Z=problem');
INSERT INTO "topic" VALUES('Mammograms and other health screenings','Q5','MEDICAL SCREENING','Q39CTno','Q39 Have you ever had a (Virtual) CT Colonoscopy, answer of no. ','1=No');
INSERT INTO "topic" VALUES('Mammograms and other health screenings','Q5','MEDICAL SCREENING','Q39CTage','Q39 Written answer for age at most recernt (Virtual) CT Colonoscopy. The possibilities for each column are either a *, a blank, or a number.','written values see description column');
INSERT INTO "topic" VALUES('Mammograms and other health screenings','Q5','MEDICAL SCREENING','Q39CSage','Q39 Written answer for age at most recernt Colonoscopy. The possibilities for each column are either a *, a blank, or a number.','written values see description column');
INSERT INTO "topic" VALUES('Mammograms and other health screenings','Q5','MEDICAL SCREENING','Q39SGage','Q39 Written answer for age at most recernt Sigmoidoscopy, The possibilities for each column are either a *, a blank, or a number.','written values see description column');
INSERT INTO "topic" VALUES('Mammograms and other health screenings','Q5','MEDICAL SCREENING','Q35','Q35 Have you EVER had a screening  mammogram?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Mammograms and other health screenings','Q5','MEDICAL SCREENING','Q36','Q36 When was your LAST screening mammogram?','* 1=Less than 1 year ago, 2=1-2 years ago, 3=3 years ago, 4=4 or more years ago, 5=Don''t know');
INSERT INTO "topic" VALUES('Mammograms and other health screenings','Q5','MEDICAL SCREENING','Q37','Q37 Over the last 10 years, on average, how often did you have a screening mammogram? ','* 1=Every year, 2=Every 2 years, 3=Every 3 years, 4=Other');
INSERT INTO "topic" VALUES('Mammograms and other health screenings','Q5','MEDICAL SCREENING','Q38a','Q38 Have you EVER  had any of the following breast procedures: a fine needle aspiration (FNA), core biopsy, or surgical biopsy?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Mammograms and other health screenings','Q5','MEDICAL SCREENING','Q38b','Q38 If yes (you had a FNA, core biopsy, or surgical biopsy), were you told you had a diagnosis of Atypical Hyperplasia or Atypia?','* 1=Yes, 0=No');
INSERT INTO "topic" VALUES('Mammograms and other health screenings','Q5','MEDICAL SCREENING','Q38c','Q38 Written answer for age first diagnosed with Atypical Hyperplasia or Atypia. The possibilities for each column are either a *, a blank, or a number.','written values see description column');
INSERT INTO "topic" VALUES('Mammograms and other health screenings','Q5','MEDICAL SCREENING','Q39CTscreen','Q39 Have you ever had a (Virtual) CT Colonoscopy for screening, answer of yes . ','1=Yes, for screening');
INSERT INTO "topic" VALUES('Mammograms and other health screenings','Q5','MEDICAL SCREENING','Q39CTsympt','Q39 Have you ever had a (Virtual) CT Colonoscopy for symptoms, answer of yes. ','1=Yes, for symptoms');
INSERT INTO "topic" VALUES('Mammograms and other health screenings','Q5','MEDICAL SCREENING','Q39CSscreen','Q39 Have you ever had a Colonoscopy for screening, answer of yes . ','1=Yes, for screening');
INSERT INTO "topic" VALUES('Mammograms and other health screenings','Q5','MEDICAL SCREENING','Q39CSsympt','Q39 Have you ever had a Colonoscopy for symptoms, answer of yes. ','1=Yes, for symptoms');
INSERT INTO "topic" VALUES('Mammograms and other health screenings','Q5','MEDICAL SCREENING','Q39SGscreen','Q39 Have you ever had a Sigmoidoscopy for screening, answer of yes . ','1=Yes, for screening');
INSERT INTO "topic" VALUES('Mammograms and other health screenings','Q5','MEDICAL SCREENING','Q39SGsympt','Q39 Have you ever had a Sigmoidoscopy for symptoms, answer of yes. ','1=Yes, for symptoms');
INSERT INTO "topic" VALUES('Mammograms and other health screenings','Q5','MEDICAL SCREENING','Q40a','Q40 Outcome of a colonoscopy or sigmoidoscopy was a benign colon polyp.','1=Benign colon polyp');
INSERT INTO "topic" VALUES('Mammograms and other health screenings','Q5','MEDICAL SCREENING','Q40b','Q40 Outcome of a colonoscopy or sigmoidoscopy was a benign rectal polyp.','1=Benign rectal polyp');
INSERT INTO "topic" VALUES('Mammograms and other health screenings','Q5','MEDICAL SCREENING','Q40c','Q40 Outcome of a colonoscopy or sigmoidoscopy was colon or rectal cancer.','1=Colon or rectal cancer');
INSERT INTO "topic" VALUES('Mammograms and other health screenings','Q5','MEDICAL SCREENING','Q40d','Q40 Outcome of a colonoscopy or sigmoidoscopy was something not listed.','1=None of these');
INSERT INTO "topic" VALUES('Mammograms and other health screenings','Q5','MEDICAL SCREENING','Q40e','Q40 Outcome of a colonoscopy or sigmoidoscopy was unknown.','1=Don''t know');
INSERT INTO "topic" VALUES('Mammograms and other health screenings','Q6','MEDICAL SCREENING','Q6Web_recent_colonoscopy','Colonoscopy in last 10 years','-88 = Unable to assign value
0 = Skipped
1 = Yes, for screening
2 = Yes, for symptoms
3 = No
4 = Both');
INSERT INTO "topic" VALUES('Mammograms and other health screenings','Q6','MEDICAL SCREENING','Q6Web_recent_sigmoidoscopy','Sigmoidoscopy in last 10 years','-88 = Unable to assign value
0 = Skipped
1 = Yes, for screening
2 = Yes, for symptoms
3 = No
4 = Both');
INSERT INTO "topic" VALUES('Mammograms and other health screenings','Q6','MEDICAL SCREENING','Q6Web_age_recent_colonoscopy','Age at most recent Colonoscopy ','-88 = Unable to assign value
0-99');
INSERT INTO "topic" VALUES('Mammograms and other health screenings','Q6','MEDICAL SCREENING','Q6Web_age_recent_sigmoidoscopy','Age at most recent Sigmoidoscopy','-88 = Unable to assign value
0-99');
INSERT INTO "topic" VALUES('Mammograms and other health screenings','Q6','GENETIC TESTING','Q6Web_genetic_testing','Ever had genetic testing for inherited cancer','-88 = Unable to assign value
0 = Skipped
1 = Yes
2 = No');
INSERT INTO "topic" VALUES('Physical activity','Q1','PHYSICAL ACTIVITY','STHIGHY','Q68, 69 STRN EXER DUR HS HRS/WK OVR YR LB','0-12, .A=FP_Blnk, .B=LSDBlnk, .Y=YNG');
INSERT INTO "topic" VALUES('Physical activity','Q1','PHYSICAL ACTIVITY','ST1824Y','Q68, 69 STRN EXER AGE 18-24 HRS/WK OVR YR LB','0-12, .A=FP_Blnk, .B=LSDBlnk, .Y=YNG');
INSERT INTO "topic" VALUES('Physical activity','Q1','PHYSICAL ACTIVITY','ST2534Y','Q68, 69 STRN EXER AGE 25-34 HRS/WK OVR YR LB','0-12, .A=FP_Blnk, .B=LSDBlnk, .Y=YNG');
INSERT INTO "topic" VALUES('Physical activity','Q1','PHYSICAL ACTIVITY','ST3544Y','Q68, 69 STRN EXER AGE 35-44 HRS/WK OVR YR LB','0-12, .A=FP_Blnk, .B=LSDBlnk, .Y=YNG');
INSERT INTO "topic" VALUES('Physical activity','Q1','PHYSICAL ACTIVITY','ST4554Y','Q68, 69 STRN EXER AGE 45-54 HRS/WK OVR YR LB','0-12, .A=FP_Blnk, .B=LSDBlnk, .Y=YNG');
INSERT INTO "topic" VALUES('Physical activity','Q1','PHYSICAL ACTIVITY','STPST3Y','Q68, 69 STRN EXER PST 3YRS HRS/WK OVR YR LB','0-12, .A=FP_Blnk, .B=LSDBlnk, .Y=YNG');
INSERT INTO "topic" VALUES('Physical activity','Q1','PHYSICAL ACTIVITY','MDHIGHY','Q68, 69 MOD EXER DUR HS HRS/WK OVR YR LB','0-12, .A=FP_Blnk, .B=LSDBlnk, .Y=YNG');
INSERT INTO "topic" VALUES('Physical activity','Q1','PHYSICAL ACTIVITY','MD1824Y','Q68, 69 MOD EXER AGE 18-24 HRS/WK OVR YR LB','0-12, .A=FP_Blnk, .B=LSDBlnk, .Y=YNG');
INSERT INTO "topic" VALUES('Physical activity','Q1','PHYSICAL ACTIVITY','MD2534Y','Q68, 69 MOD EXER AGE 25-34 HRS/WK OVR YR LB','0-12, .A=FP_Blnk, .B=LSDBlnk, .Y=YNG');
INSERT INTO "topic" VALUES('Physical activity','Q1','PHYSICAL ACTIVITY','MD3544Y','Q68, 69 MOD EXER AGE 35-44 HRS/WK OVR YR LB','0-12, .A=FP_Blnk, .B=LSDBlnk, .Y=YNG');
INSERT INTO "topic" VALUES('Physical activity','Q1','PHYSICAL ACTIVITY','MD4554Y','Q68, 69 MOD EXER AGE 45-54 HRS/WK OVR YR LB','0-12, .A=FP_Blnk, .B=LSDBlnk, .Y=YNG');
INSERT INTO "topic" VALUES('Physical activity','Q1','PHYSICAL ACTIVITY','MDPST3Y','Q68, 69 MOD EXER PST 3YRS HRS/WK OVR YR LB','0-12, .A=FP_Blnk, .B=LSDBlnk, .Y=YNG');
INSERT INTO "topic" VALUES('Physical activity','Q1','PHYSICAL ACTIVITY','SHRLT','Q68, 69 STREN EXER HR/WK OVER LIFETIME','0-12, .A=FP_Blnk, .B=LSDBlnk, .M=Prt_Miss, .Y=YNG');
INSERT INTO "topic" VALUES('Physical activity','Q1','PHYSICAL ACTIVITY','MHRLT','Q68, 69 MODERATE EXER HR/WK OVER LIFETIME','0-12, .A=FP_Blnk, .B=LSDBlnk, .M=Prt_Miss, .Y=YNG');
INSERT INTO "topic" VALUES('Physical activity','Q1','PHYSICAL ACTIVITY','SPMHS','Q68, 69 S+M HRS/WK OVR YR HS','0-24,  .A=FP_Blnk, .B=LSDBlnk, .M=S&M_Miss, .Y=YNG');
INSERT INTO "topic" VALUES('Physical activity','Q1','PHYSICAL ACTIVITY','SPM1824','Q68, 69 S+M HRS/WK OVR YR 18-24','0-24,  .A=FP_Blnk, .B=LSDBlnk, .M=S&M_Miss, .Y=YNG');
INSERT INTO "topic" VALUES('Physical activity','Q1','PHYSICAL ACTIVITY','SPM2534','Q68, 69 S+M HRS/WK OVR YR 25-34','0-24,  .A=FP_Blnk, .B=LSDBlnk, .M=S&M_Miss, .Y=YNG');
INSERT INTO "topic" VALUES('Physical activity','Q1','PHYSICAL ACTIVITY','SPM3544','Q68, 69 S+M HRS/WK OVR YR 35-44','0-24,  .A=FP_Blnk, .B=LSDBlnk, .M=S&M_Miss, .Y=YNG');
INSERT INTO "topic" VALUES('Physical activity','Q1','PHYSICAL ACTIVITY','SPM4554','Q68, 69 S+M HRS/WK OVR YR 45-54','0-24,  .A=FP_Blnk, .B=LSDBlnk, .M=S&M_Miss, .Y=YNG');
INSERT INTO "topic" VALUES('Physical activity','Q1','PHYSICAL ACTIVITY','SPMP3YR','Q68, 69 S+M HRS/WK OVR YR PST 3YRS','0-24,  .A=FP_Blnk, .B=LSDBlnk, .M=S&M_Miss, .Y=YNG');
INSERT INTO "topic" VALUES('Physical activity','Q1','PHYSICAL ACTIVITY','SPMHRLT','Q68, 69 S+M HRS/WK OVR YR FOR LIFETIME','0-24,  .A=FP_Blnk, .B=LSDBlnk, .M=S&M_Miss, .Y=YNG');
INSERT INTO "topic" VALUES('Physical activity','Q1','PHYSICAL ACTIVITY','SP3YFIX','Q68, 69 STREN PAST 3YRS AMT FRM EARLIER AGE RANGE','1=Coded per exer in corresponding age group(s) due to missing value ');
INSERT INTO "topic" VALUES('Physical activity','Q1','PHYSICAL ACTIVITY','MP3YFIX','Q68, 69 MOD PAST 3YRS AMT FRM EARLIER AGE RANGE','1=Coded per exer in corresponding age group(s) due to missing value ');
INSERT INTO "topic" VALUES('Physical activity','Q1','PHYSICAL ACTIVITY','OTRWALKH','Q70 Hours/day spent in casual walking?','A=0, B=<1, C=1, D=2, E=3-4, F=5-6 G=7-9, H=10+');
INSERT INTO "topic" VALUES('Physical activity','Q1','PHYSICAL ACTIVITY','OTRWALKD','Q70 Days/wk spent in casual walking?','A=1, B=2-3, C=4-5, D=6-7');
INSERT INTO "topic" VALUES('Physical activity','Q1','PHYSICAL ACTIVITY','OTRHOUSH','Q70 Hours/day spent in housework?','A=0, B=<1, C=1, D=2, E=3-4, F=5-6 G=7-9, H=10+');
INSERT INTO "topic" VALUES('Physical activity','Q1','PHYSICAL ACTIVITY','OTRHOUSD','Q70 Days/wk spent in housework?','A=1, B=2-3, C=4-5, D=6-7');
INSERT INTO "topic" VALUES('Physical activity','Q1','PHYSICAL ACTIVITY','OTRSTNDH','Q70 Hours/day spent in standing/walking at work?','A=0, B=<1, C=1, D=2, E=3-4, F=5-6 G=7-9, H=10+');
INSERT INTO "topic" VALUES('Physical activity','Q1','PHYSICAL ACTIVITY','OTRSTNDD','Q70 Days/wk spent in standing/walking at work?','A=1, B=2-3, C=4-5, D=6-7');
INSERT INTO "topic" VALUES('Physical activity','Q1','PHYSICAL ACTIVITY','OTRSITH','Q70 Hours/day spent sitting?','A=0, B=<1, C=1, D=2, E=3-4, F=5-6 G=7-9, H=10+');
INSERT INTO "topic" VALUES('Physical activity','Q1','PHYSICAL ACTIVITY','OTRSITD','Q70 Days/wk spent in sitting?','A=1, B=2-3, C=4-5, D=6-7');
INSERT INTO "topic" VALUES('Physical activity','Q1','PHYSICAL ACTIVITY','OTRSLPH','Q70 Hours/day spent sleeping?','A=0, B=<1, C=1, D=2, E=3-4, F=5-6 G=7-9, H=10+');
INSERT INTO "topic" VALUES('Physical activity','Q1','PHYSICAL ACTIVITY','OTRSLPD','Q70 Days/wk spent sleeping?','A=1, B=2-3, C=4-5, D=6-7');
INSERT INTO "topic" VALUES('Physical activity','Q4','PHYSICAL ACTIVITY','STQ4HR','Q24 During the past 3 years, what was the average number of hours per week that you did strenuous exercise or sports? ','A=None, B=1/2, C=1, D=1 1/2, E=2, F=3, G=4-6, H=7-10, I=11+');
INSERT INTO "topic" VALUES('Physical activity','Q4','PHYSICAL ACTIVITY','STQ4miniO','Q24 During the past 3 years, what was the average number of months per year that you did strenuous exercise or sports? ','A=1-3, B=4-6, C=7-9, D=10-12');
INSERT INTO "topic" VALUES('Physical activity','Q4','PHYSICAL ACTIVITY','MDQ4HR','Q25 During the past 3 years, what was the average number of hours per week that you did moderate exercise or sports? ','A=None, B=1/2, C=1, D=1 1/2, E=2, F=3, G=4-6, H=7-10, I=11+');
INSERT INTO "topic" VALUES('Physical activity','Q4','PHYSICAL ACTIVITY','MDQ4miniO','Q25 During the past 3 years, what was the average number of months per year that you did moderate exercise or sports? ','A=1-3, B=4-6, C=7-9, D=10-12');
INSERT INTO "topic" VALUES('Physical activity','Q4','PHYSICAL ACTIVITY','STAIRD','Q26 How many flights of stairs do you climb in total daily? ','A=2 Flights or less, B=3-4, C=5-9, D=10-14, E=15+');
INSERT INTO "topic" VALUES('Physical activity','Q4','PHYSICAL ACTIVITY','LTDVIG','Q27 Does your health now limit you while doing vigorous activities? ','A= not limited at all, B=Yes limited a little, C=Yes limited a lot, X=Image covered');
INSERT INTO "topic" VALUES('Physical activity','Q4','PHYSICAL ACTIVITY','LTDMD','Q27 Does your health now limit you while doing moderate activities? ','A= not limited at all, B=Yes limited a little, C=Yes limited a lot, X=Image covered');
INSERT INTO "topic" VALUES('Physical activity','Q4','PHYSICAL ACTIVITY','LTDSTR','Q27 Does your health now limit you while climbing several flights of stairs? ','A= not limited at all, B=Yes limited a little, C=Yes limited a lot, X=Image covered');
INSERT INTO "topic" VALUES('Physical activity','Q4','PHYSICAL ACTIVITY','LTD1STR','Q27 Does your health now limit you while climbing 1 flight of stairs? ','A= not limited at all, B=Yes limited a little, C=Yes limited a lot, X=Image covered');
INSERT INTO "topic" VALUES('Physical activity','Q4','PHYSICAL ACTIVITY','LTDMILE','Q27 Does your health now limit you while walking more than a mile? ','A= not limited at all, B=Yes limited a little, C=Yes limited a lot, X=Image covered');
INSERT INTO "topic" VALUES('Physical activity','Q4','PHYSICAL ACTIVITY','LTDBLK','Q27 Does your health now limit you while walking several blocks? ','A= not limited at all, B=Yes limited a little, C=Yes limited a lot, X=Image covered');
INSERT INTO "topic" VALUES('Physical activity','Q4','PHYSICAL ACTIVITY','LTD1BLK','Q27 Does your health now limit you while walking 1 block? ','A= not limited at all, B=Yes limited a little, C=Yes limited a lot, X=Image covered');
INSERT INTO "topic" VALUES('Physical activity','Q4','PHYSICAL ACTIVITY','LTDCARRY','Q27 Does your health now limit you while lifting or carrying groceries? ','A= not limited at all, B=Yes limited a little, C=Yes limited a lot, X=Image covered');
INSERT INTO "topic" VALUES('Physical activity','Q4','PHYSICAL ACTIVITY','LTDBEND','Q27 Does your health now limit you while bending, kneeling, or stooping? ','A= not limited at all, B=Yes limited a little, C=Yes limited a lot, X=Image covered');
INSERT INTO "topic" VALUES('Physical activity','Q4','PHYSICAL ACTIVITY','LTDBATH','Q27 Does your health now limit you while bathing or dressing yourself? ','A= not limited at all, B=Yes limited a little, C=Yes limited a lot, X=Image covered');
INSERT INTO "topic" VALUES('Physical activity','Q4','PHYSICAL ACTIVITY','STPST3YQ4','Q24 GENERATED VARIABLE FOR past 3 yrs average hours/week/month of strenuous activity from Q4 ','0-12, .B=Phy_blnk');
INSERT INTO "topic" VALUES('Physical activity','Q4','PHYSICAL ACTIVITY','MDPST3YQ4','Q25 GENERATED VARIABLE FOR past 3 yrs average hours/week/month of moderate activity from Q4','0-12, .B=Phy_blnk');
INSERT INTO "topic" VALUES('Physical activity','Q4','PHYSICAL ACTIVITY','SPMPST3YQ4','Q24 GENERATED VARIABLE FOR past 3 yrs average hours/week/month of strenuous+moderate activity from Q4','0-24, .B=Phy_blnk');
INSERT INTO "topic" VALUES('Physical activity','Q5','PHYSICAL ACTIVITY','Q14a','Q14 During the PAST YEAR, what was your average total time per week (in hours) spent standing or walking around at work or away from home.','00=None, 01=1/2 hour, 02=1 hour, 03=1-1/2 hours, 04=2-3 hours, 05=4-6 hours, 06=7-10 hours, 07=11-20 hours, 08=21-30 hours, 09=31-39 hours, 10=40+ hours');
INSERT INTO "topic" VALUES('Physical activity','Q5','PHYSICAL ACTIVITY','Q14b','Q14 During the PAST YEAR, what was your average total time per week (in hours) spent standing or walking around at home.','00=None, 01=1/2 hour, 02=1 hour, 03=1-1/2 hours, 04=2-3 hours, 05=4-6 hours, 06=7-10 hours, 07=11-20 hours, 08=21-30 hours, 09=31-39 hours, 10=40+ hours');
INSERT INTO "topic" VALUES('Physical activity','Q5','PHYSICAL ACTIVITY','Q14c','Q14 During the PAST YEAR, what was your average total time per week (in hours) spent sitting at work.','00=None, 01=1/2 hour, 02=1 hour, 03=1-1/2 hours, 04=2-3 hours, 05=4-6 hours, 06=7-10 hours, 07=11-20 hours, 08=21-30 hours, 09=31-39 hours, 10=40+ hours');
INSERT INTO "topic" VALUES('Physical activity','Q5','PHYSICAL ACTIVITY','Q14d','Q14 During the PAST YEAR, what was your average total time per week (in hours) spent sitting or driving in a car, bus or train.','00=None, 01=1/2 hour, 02=1 hour, 03=1-1/2 hours, 04=2-3 hours, 05=4-6 hours, 06=7-10 hours, 07=11-20 hours, 08=21-30 hours, 09=31-39 hours, 10=40+ hours');
INSERT INTO "topic" VALUES('Physical activity','Q5','PHYSICAL ACTIVITY','Q14e','Q14 During the PAST YEAR, what was your average total time per week (in hours) spent sitting or reclining while watching television.','00=None, 01=1/2 hour, 02=1 hour, 03=1-1/2 hours, 04=2-3 hours, 05=4-6 hours, 06=7-10 hours, 07=11-20 hours, 08=21-30 hours, 09=31-39 hours, 10=40+ hours');
INSERT INTO "topic" VALUES('Physical activity','Q5','PHYSICAL ACTIVITY','Q14f','Q14 During the PAST YEAR, what was your average total time per week (in hours) spent sitting or reclining while watching reading.','00=None, 01=1/2 hour, 02=1 hour, 03=1-1/2 hours, 04=2-3 hours, 05=4-6 hours, 06=7-10 hours, 07=11-20 hours, 08=21-30 hours, 09=31-39 hours, 10=40+ hours');
INSERT INTO "topic" VALUES('Physical activity','Q5','PHYSICAL ACTIVITY','Q14g','Q14 During the PAST YEAR, what was your average total time per week (in hours) spent sitting for other reasons (playing games, working at a desk, sewing).','00=None, 01=1/2 hour, 02=1 hour, 03=1-1/2 hours, 04=2-3 hours, 05=4-6 hours, 06=7-10 hours, 07=11-20 hours, 08=21-30 hours, 09=31-39 hours, 10=40+ hours');
INSERT INTO "topic" VALUES('Physical activity','Q5','PHYSICAL ACTIVITY','Q14h','Q14 During the PAST YEAR, what was your average total time per week (in hours) spent participating in light-intensity activities such as shopping.','00=None, 01=1/2 hour, 02=1 hour, 03=1-1/2 hours, 04=2-3 hours, 05=4-6 hours, 06=7-10 hours, 07=11-20 hours, 08=21-30 hours, 09=31-39 hours, 10=40+ hours');
INSERT INTO "topic" VALUES('Physical activity','Q5','PHYSICAL ACTIVITY','Q14i','Q14 During the PAST YEAR, what was your average total time per week (in hours) spent walking, either for exercise or as part of your job activities.','00=None, 01=1/2 hour, 02=1 hour, 03=1-1/2 hours, 04=2-3 hours, 05=4-6 hours, 06=7-10 hours, 07=11-20 hours, 08=21-30 hours, 09=31-39 hours, 10=40+ hours');
INSERT INTO "topic" VALUES('Physical activity','Q5','PHYSICAL ACTIVITY','Q14j','Q14 During the PAST YEAR, what was your average total time per week (in hours) spent weight training exercise, such as at the gym.','00=None, 01=1/2 hour, 02=1 hour, 03=1-1/2 hours, 04=2-3 hours, 05=4-6 hours, 06=7-10 hours, 07=11-20 hours, 08=21-30 hours, 09=31-39 hours, 10=40+ hours');
INSERT INTO "topic" VALUES('Physical activity','Q5','PHYSICAL ACTIVITY','Q15','Q15 What is your normal walking pace?','1=Slow, 2=Normal, 3=Brisk, 4=Very brisk, 5=Unable to walk');
INSERT INTO "topic" VALUES('Physical activity','Q5','PHYSICAL ACTIVITY','Q16a','Q16 Average Hours Per Week Strenuous exercise during the past 3 years.','0=None, 1=1/2 hour, 2=1 hour, 3=1-1/2 hours, 4=2 hours, 5=3 hours, 6=4-6 hours, 7=7-10 hours, 8=11+ hours');
INSERT INTO "topic" VALUES('Physical activity','Q5','PHYSICAL ACTIVITY','Q16b','Q16 Average Months Per Year Strenuous exercise during the past 3 years.','1=1-3 months, 2=4-6, 3=7-9, 4=10-12');
INSERT INTO "topic" VALUES('Physical activity','Q5','PHYSICAL ACTIVITY','Q17a','Q17 Average Hours Per Week Moderate exercise during the past 3 years.','0=None, 1=1/2 hour, 2=1 hour, 3=1-1/2 hours, 4=2 hours, 5=3 hours, 6=4-6 hours, 7=7-10 hours, 8=11+ hours');
INSERT INTO "topic" VALUES('Physical activity','Q5','PHYSICAL ACTIVITY','Q17b','Q17 Average Months Per Year Moderate exercise during the past 3 years.','1=1-3 months, 2=4-6, 3=7-9, 4=10-12');
INSERT INTO "topic" VALUES('Physical activity','Q5','PHYSICAL ACTIVITY','Q18a','Q18 Are you currently limited doing vigorous activities, such as running, lifting heavy objects, participating in strenuous sports.','1=Yes, limited a lot, 2=Yes, limited a little, 3=No, not limited at all');
INSERT INTO "topic" VALUES('Physical activity','Q5','PHYSICAL ACTIVITY','Q18b','Q18 Are you currently limited doing moderate activities, such as moving a table, pushing a vacuum cleaner, bowling, or playing golf.    ','1=Yes, limited a lot, 2=Yes, limited a little, 3=No, not limited at all');
INSERT INTO "topic" VALUES('Physical activity','Q5','PHYSICAL ACTIVITY','Q18c','Q18 Are you currently limited lifting or carrying groceries.','1=Yes, limited a lot, 2=Yes, limited a little, 3=No, not limited at all');
INSERT INTO "topic" VALUES('Physical activity','Q5','PHYSICAL ACTIVITY','Q18d','Q18 Are you currently limited climbing several  flights of stairs.','1=Yes, limited a lot, 2=Yes, limited a little, 3=No, not limited at all');
INSERT INTO "topic" VALUES('Physical activity','Q5','PHYSICAL ACTIVITY','Q18e','Q18 Are you currently limited climbing one flight of stairs.','1=Yes, limited a lot, 2=Yes, limited a little, 3=No, not limited at all');
INSERT INTO "topic" VALUES('Physical activity','Q5','PHYSICAL ACTIVITY','Q18f','Q18 Are you currently limited bending, kneeling, or stooping.','1=Yes, limited a lot, 2=Yes, limited a little, 3=No, not limited at all');
INSERT INTO "topic" VALUES('Physical activity','Q5','PHYSICAL ACTIVITY','Q18g','Q18 Are you currently limited walking more than a mile.','1=Yes, limited a lot, 2=Yes, limited a little, 3=No, not limited at all');
INSERT INTO "topic" VALUES('Physical activity','Q5','PHYSICAL ACTIVITY','Q18h','Q18 Are you currently limited walking several blocks.','1=Yes, limited a lot, 2=Yes, limited a little, 3=No, not limited at all');
INSERT INTO "topic" VALUES('Physical activity','Q5','PHYSICAL ACTIVITY','Q18i','Q18 Are you currently limited walking one  block.','1=Yes, limited a lot, 2=Yes, limited a little, 3=No, not limited at all');
INSERT INTO "topic" VALUES('Physical activity','Q5','PHYSICAL ACTIVITY','Q18j','Q18 Are you currently limited bathing or dressing yourself.','1=Yes, limited a lot, 2=Yes, limited a little, 3=No, not limited at all');
INSERT INTO "topic" VALUES('Physical activity','Q5mini','PHYSICAL ACTIVITY','Q16a','Q16 Average Hours Per Week Strenuous exercise during the past 3 years.','0=None, 1=1/2 hour, 2=1 hour, 3=1-1/2 hours, 4=2 hours, 5=3 hours, 6=4-6 hours, 7=7-10 hours, 8=11+ hours');
INSERT INTO "topic" VALUES('Physical activity','Q5mini','PHYSICAL ACTIVITY','Q16b','Q16 Average Months Per Year Strenuous exercise during the past 3 years.','1=1-3 months, 2=4-6, 3=7-9, 4=10-12');
INSERT INTO "topic" VALUES('Physical activity','Q5mini','PHYSICAL ACTIVITY','Q17a','Q17 Average Hours Per Week Moderate exercise during the past 3 years.','0=None, 1=1/2 hour, 2=1 hour, 3=1-1/2 hours, 4=2 hours, 5=3 hours, 6=4-6 hours, 7=7-10 hours, 8=11+ hours');
INSERT INTO "topic" VALUES('Physical activity','Q5mini','PHYSICAL ACTIVITY','Q17b','Q17 Average Months Per Year Moderate exercise during the past 3 years.','1=1-3 months, 2=4-6, 3=7-9, 4=10-12');
INSERT INTO "topic" VALUES('Physical activity','Q6','PHYSICAL ACTIVITY','Q6Web_strenuous_hrs_per_wk','Strenuous exercise hours per week over last 3 years','-88 = Unable to assign value
0 = Skipped
1 = None
2 = 1/2 hour per week
3 = 1 hour per week
4 = 1 1/2 hours per week
5 = 2 hours per week 
6 = 3 hours per week
7 = 4 - 6 hours per week
8 = 7 - 10 hours per week
9 = 11+ hours per week
10 = Don''t know');
INSERT INTO "topic" VALUES('Physical activity','Q6','PHYSICAL ACTIVITY','Q6Web_strenuous_mos_per_yr','Strenuous exercise months per year over last 3 years','-88 = Unable to assign value
0 = Skipped
1 = 1 - 3 months
2 = 4 - 6 months
3 = 7 - 9 months
4 = 10 - 12 months');
INSERT INTO "topic" VALUES('Physical activity','Q6','PHYSICAL ACTIVITY','Q6Web_moderate_hrs_per_wk','Moderate exercise hours per week over last 3 years','-88 = Unable to assign value
0 = Skipped
1 = None
2 = 1/2 hour per week
3 = 1 hour per week
4 = 1 1/2 hours per week
5 = 2 hours per week 
6 = 3 hours per week
7 = 4 - 6 hours per week
8 = 7 - 10 hours per week
9 = 11+ hours per week
10 = Don''t know');
INSERT INTO "topic" VALUES('Physical activity','Q6','PHYSICAL ACTIVITY','Q6Web_moderate_hrs_per_yr','Moderate exercise months per year over last 3 years','-88 = Unable to assign value
0 = Skipped
1 = 1 - 3 months
2 = 4 - 6 months
3 = 7 - 9 months
4 = 10 - 12 months');
INSERT INTO "topic" VALUES('Vitamins','Q1','DIET','VITNO','Q71 Have you ever taken vitamins regularly? NO','A=Yes');
INSERT INTO "topic" VALUES('Vitamins','Q1','DIET','VITMULTD','Q71 Have you ever taken multi-vitamins - days/wk?','A=Don''t take, B=1-3, C=4-6, D=Every day, Z=Problem');
INSERT INTO "topic" VALUES('Vitamins','Q1','DIET','VITMULTY','Q71 Have you ever taken multi-vitamins - years?','A=<1, B=1, C=2, D=3-4, E=5-9, F=10+, Z=Problem');
INSERT INTO "topic" VALUES('Vitamins','Q1','DIET','VITAD','Q71 Have you ever taken vitamin A reg - days/wk?','A=Don''t take, B=1-3, C=4-6, D=Every day, Z=Problem');
INSERT INTO "topic" VALUES('Vitamins','Q1','DIET','VITAY','Q71 Have you ever taken vitamin A reg - years?','A=<1, B=1, C=2, D=3-4, E=5-9, F=10+, Z=Problem');
INSERT INTO "topic" VALUES('Vitamins','Q1','DIET','VITBETAD','Q71 Have you ever taken beta-carotene - days/wk','A=Don''t take, B=1-3, C=4-6, D=Every day, Z=Problem');
INSERT INTO "topic" VALUES('Vitamins','Q1','DIET','VITBETAY','Q71 Have you ever taken beta-carotene - years?','A=<1, B=1, C=2, D=3-4, E=5-9, F=10+, Z=Problem');
INSERT INTO "topic" VALUES('Vitamins','Q1','DIET','VITCD','Q71 Have you ever taken vitamin C reg - days/wk?','A=Don''t take, B=1-3, C=4-6, D=Every day, Z=Problem');
INSERT INTO "topic" VALUES('Vitamins','Q1','DIET','VITCY','Q71 Have you ever taken vitamin C reg - years?','A=<1, B=1, C=2, D=3-4, E=5-9, F=10+, Z=Problem');
INSERT INTO "topic" VALUES('Vitamins','Q1','DIET','VITED','Q71 Have you ever taken vitamin E reg - days/wk?','A=Don''t take, B=1-3, C=4-6, D=Every day, Z=Problem');
INSERT INTO "topic" VALUES('Vitamins','Q1','DIET','VITEY','Q71 Have you ever taken vitamin E reg - years?','A=<1, B=1, C=2, D=3-4, E=5-9, F=10+, Z=Problem');
INSERT INTO "topic" VALUES('Vitamins','Q1','DIET','VITSELD','Q71 Have you ever taken selenium reg - days/wk?','A=Don''t take, B=1-3, C=4-6, D=Every day, Z=Problem');
INSERT INTO "topic" VALUES('Vitamins','Q1','DIET','VITSELY','Q71 Have you ever taken selenium reg - years?','A=<1, B=1, C=2, D=3-4, E=5-9, F=10+, Z=Problem');
INSERT INTO "topic" VALUES('Vitamins','Q1','DIET','VITABETA','Q72 How much vit A/beta-car taken (as pt of multi)?','A=5000 IU, B=6000, C=10000, D=20000+, *=Problem');
INSERT INTO "topic" VALUES('Vitamins','Q1','DIET','VITAONLY','Q72 How much vitamin A (only) do you take?','A=5000 IU, B=8000, C=10000, D=16000+, *=Problem');
INSERT INTO "topic" VALUES('Vitamins','Q1','DIET','VITBETA','Q72 How much beta-carotene (only) do you take?','A=6000 IU, B=10000, C=25000, D=50000+, *=Problem');
INSERT INTO "topic" VALUES('Vitamins','Q1','DIET','VITC','Q72 How much vitamin C do you take?','A=100 mg, B=250, C=500, D=750, E=1000, F=1500, G=2000, H=3000+, *=Problem');
INSERT INTO "topic" VALUES('Vitamins','Q1','DIET','VITE','Q72 How much vitamin E do you take?','A=50 mg, B=200, C=400, D=800, E=1000, F=2000+, *=Problem');
INSERT INTO "topic" VALUES('Vitamins','Q1','DIET','VITSELEN','Q72 How much selenium do you take?','A=10 mcg, B=15, C=20, D=30, E=40, F=50+, *=Problem');
INSERT INTO "topic" VALUES('Vitamins','Q1','DIET','vitgrp','Q71-72 multivit and single vit use variable','1-4, 1=Non-user, 2=Curr, Sing vit only, 3=Curr, Multvit only, 4=Curr, Both mult & sing vit use');
INSERT INTO "topic" VALUES('Vitamins','Q1','DIET','multpill','Q71-72 number of multivit pills per week','0=Non-user, 2=1-3 d/wk, 5=4-6 d/wk, 7=Everyday, .B=VitUseGrp Missing');
INSERT INTO "topic" VALUES('Vitamins','Q1','DIET','singpill','Q71-72 number of single vit pills per week','0-28, .B=VitUseGrp Missing');
INSERT INTO "topic" VALUES('Vitamins','Q1','DIET','multdur','Q71-72 duration in yr category of multivit use','1-6, 1=<1 yr, 2=1 yr, 3=2 yrs, 4=3-4 yrs, 5=5-9 yrs, 6=10+ yrs,.A=Non-user of that type, .B=VitUseGrp Missing, .C=Missing Duration ');
INSERT INTO "topic" VALUES('Vitamins','Q4','VITAMIN SUPPLEMENTS','MVPST','Q42 During the past year, have you taken multivitamin pills regularly? (No, Yes (all year), or Yes (season only)','A=No, B=Yes all yr, C=Yes only in seasonally, X=Unable to resolve');
INSERT INTO "topic" VALUES('Vitamins','Q4','VITAMIN SUPPLEMENTS','VITAPST','Q42 During the past year, have you taken Vitamin A or beta-carotene (as a single supplement) regularly? [No, Yes (all year), or Yes (season only)]','A=No, B=Yes all yr, C=Yes only in seasonally, X=Unable to resolve');
INSERT INTO "topic" VALUES('Vitamins','Q4','VITAMIN SUPPLEMENTS','VITCPST','Q42 During the past year, have you taken Vitamin C (as a single supplement) regularly? [No, Yes (all year), or Yes (season only)]','A=No, B=Yes all yr, C=Yes only in seasonally, X=Unable to resolve');
INSERT INTO "topic" VALUES('Vitamins','Q4','VITAMIN SUPPLEMENTS','VITEPST','Q42 During the past year, have you taken Vitamin E (as a single supplement) regularly? [No, Yes (all year), or Yes (season only)]','A=No, B=Yes all yr, C=Yes only in seasonally, X=Unable to resolve');
INSERT INTO "topic" VALUES('Vitamins','Q4','VITAMIN SUPPLEMENTS','CALCPST','Q42 During the past year, have you taken Calcium, including Tums, Os Cal, etc. (with or without added Vitamin D)? [No, Yes (all year), or Yes (season only)]','A=No, B=Yes all yr, C=Yes only in seasonally, X=Unable to resolve');
INSERT INTO "topic" VALUES('Vitamins','Q4','VITAMIN SUPPLEMENTS','MVMINRAL','Q43 If you take multivitamins, do you usually take multivitamins that contain minerals? ','Y=Yes, N=No, X=Unable to resolve');
INSERT INTO "topic" VALUES('Vitamins','Q4','VITAMIN SUPPLEMENTS','MVANTIOX','Q43 If you take multivitamins, do you usually take multivitamins that contain extra antioxidents? ','Y=Yes, N=No, X=Unable to resolve');
INSERT INTO "topic" VALUES('Vitamins','Q4','VITAMIN SUPPLEMENTS','VITCM','Q44 If you take vitamin C as a single supplement, how much do you take each time you take it? ','A=250 mg or less, B=300-500 mg, C=600-1000 mg, D=More than 1000 mg, Z=Problem');
INSERT INTO "topic" VALUES('Vitamins','Q4','VITAMIN SUPPLEMENTS','VITEM','Q45 If you take vitamin E as a single supplement, how much do you take each time you take it? ','A=200 IU, B=250-400 IU, C=450-1000 IU, D=More than 1000 IU, Z=Problem');
INSERT INTO "topic" VALUES('Vitamins','Q4','VITAMIN SUPPLEMENTS','mvfreq','Q42 How often take multivitamins?','A=1-3, B=4-6, C=Every day, U=Blank Out The Data, W&X=Irresolvable');
INSERT INTO "topic" VALUES('Vitamins','Q4','VITAMIN SUPPLEMENTS','mvyear','Q42 How many years taken multivitamins?','A=<1 yr, B=1 yr, C=2 yrs, D=3-4 yrs, E=5-9 yrs, F=10+ yrs, U&V=Blank Out The Data, W&X=Irresolvable');
INSERT INTO "topic" VALUES('Vitamins','Q4','VITAMIN SUPPLEMENTS','vitafreq','Q42 How often take vitamin A or beta-carotene?','A=1-3, B=4-6, C=Every day, U=Blank Out The Data, W&X=Irresolvable');
INSERT INTO "topic" VALUES('Vitamins','Q4','VITAMIN SUPPLEMENTS','vitayear','Q42 How many years taken vitamin A or beta-carotene?','A=<1 yr, B=1 yr, C=2 yrs, D=3-4 yrs, E=5-9 yrs, F=10+ yrs, U&V=Blank Out The Data, W&X=Irresolvable');
INSERT INTO "topic" VALUES('Vitamins','Q4','VITAMIN SUPPLEMENTS','vitcfreq','Q42 How often take vitamin C?','A=1-3, B=4-6, C=Every day, U=Blank Out The Data, W&X=Irresolvable');
INSERT INTO "topic" VALUES('Vitamins','Q4','VITAMIN SUPPLEMENTS','vitcyear','Q42 How many years taken vitamin C?','A=<1 yr, B=1 yr, C=2 yrs, D=3-4 yrs, E=5-9 yrs, F=10+ yrs, U&V=Blank Out The Data, W&X=Irresolvable');
INSERT INTO "topic" VALUES('Vitamins','Q4','VITAMIN SUPPLEMENTS','vitefreq','Q42 How often take vitamin E?','A=1-3, B=4-6, C=Every day, U=Blank Out The Data, W&X=Irresolvable');
INSERT INTO "topic" VALUES('Vitamins','Q4','VITAMIN SUPPLEMENTS','viteyear','Q42 How many years taken vitamin E?','A=<1 yr, B=1 yr, C=2 yrs, D=3-4 yrs, E=5-9 yrs, F=10+ yrs, U&V=Blank Out The Data, W&X=Irresolvable');
INSERT INTO "topic" VALUES('Vitamins','Q4','VITAMIN SUPPLEMENTS','calcfreq','Q42 How often take calcium?','A=1-3, B=4-6, C=Every day, U=Blank Out The Data, W&X=Irresolvable');
INSERT INTO "topic" VALUES('Vitamins','Q4','VITAMIN SUPPLEMENTS','calcyear','Q42 How many years taken calcium?','A=<1 yr, B=1 yr, C=2 yrs, D=3-4 yrs, E=5-9 yrs, F=10+ yrs, U&V=Blank Out The Data, W&X=Irresolvable');
INSERT INTO "topic" VALUES('Vitamins','Q5','VITAMINS and SUPPLEMENTS','Q41a_1','Q41 During the  past year  how often have you taken multi-vitamin supplements regularly (at least once a week)?','* 0=Don''t take, 1=1-3 days/week, 2=4-6, 3=Every day');
INSERT INTO "topic" VALUES('Vitamins','Q5','VITAMINS and SUPPLEMENTS','Q41a_2','Q41 For how many years have you taken multi-vitamin supplements regularly (at least once a week)?','* 0=Less than 1 year, 1=1, 2=2, 3=3-4, 4=5-9, 5=10+');
INSERT INTO "topic" VALUES('Vitamins','Q5','VITAMINS and SUPPLEMENTS','Q41b_1','Q41 During the  past year how often have you taken vitamin B12 as a single supplement regularly (at least once a week)?','* 0=Don''t take, 1=1-3 days/week, 2=4-6, 3=Every day');
INSERT INTO "topic" VALUES('Vitamins','Q5','VITAMINS and SUPPLEMENTS','Q41b_2','Q41 For how many years have you taken vitamin B12 as a single supplement regularly (at least once a week)?','* 0=Less than 1 year, 1=1, 2=2, 3=3-4, 4=5-9, 5=10+');
INSERT INTO "topic" VALUES('Vitamins','Q5','VITAMINS and SUPPLEMENTS','Q41c_1','Q41 During the  past year  how often have you taken calcium and vitamin D as a single supplement regularly (at least once a week)?','* 0=Don''t take, 1=1-3 days/week, 2=4-6, 3=Every day');
INSERT INTO "topic" VALUES('Vitamins','Q5','VITAMINS and SUPPLEMENTS','Q41c_2','Q41 For how many years have you taken calcium and vitamin D as a single supplement regularly (at least once a week)?','* 0=Less than 1 year, 1=1, 2=2, 3=3-4, 4=5-9, 5=10+');
INSERT INTO "topic" VALUES('Vitamins','Q5','VITAMINS and SUPPLEMENTS','Q41d_1','Q41 During the  past year how often have you taken vitamin D3 as a single supplement regularly (at least once a week)?','* 0=Don''t take, 1=1-3 days/week, 2=4-6, 3=Every day');
INSERT INTO "topic" VALUES('Vitamins','Q5','VITAMINS and SUPPLEMENTS','Q41d_2','Q41 For how many years have you taken vitamin D3 as a single supplement regularly (at least once a week)?','* 0=Less than 1 year, 1=1, 2=2, 3=3-4, 4=5-9, 5=10+');
INSERT INTO "topic" VALUES('Vitamins','Q5','VITAMINS and SUPPLEMENTS','Q41e_1','Q41 During the past year  how often have you taken calcium as a single  supplement regularly (at least once a week)?','* 0=Don''t take, 1=1-3 days/week, 2=4-6, 3=Every day');
INSERT INTO "topic" VALUES('Vitamins','Q5','VITAMINS and SUPPLEMENTS','Q41e_2','Q41 For how many years have you taken calcium as a single supplement regularly (at least once a week)?','* 0=Less than 1 year, 1=1, 2=2, 3=3-4, 4=5-9, 5=10+');
INSERT INTO "topic" VALUES('Vitamins','Q5','VITAMINS and SUPPLEMENTS','Q41f_1','Q41 During the past year how often have you taken niacin as a single supplement regularly (at least once a week)?','* 0=Don''t take, 1=1-3 days/week, 2=4-6, 3=Every day');
INSERT INTO "topic" VALUES('Vitamins','Q5','VITAMINS and SUPPLEMENTS','Q41f_2','Q41 For how many years have you taken niacin as a single supplement regularly (at least once a week)?','* 0=Less than 1 year, 1=1, 2=2, 3=3-4, 4=5-9, 5=10+');
INSERT INTO "topic" VALUES('Vitamins','Q5','VITAMINS and SUPPLEMENTS','Q41g_1','Q41 During the past year how often have you taken omega-3 fatty acids as single supplement regularly (at least once a week)?','* 0=Don''t take, 1=1-3 days/week, 2=4-6, 3=Every day');
INSERT INTO "topic" VALUES('Vitamins','Q5','VITAMINS and SUPPLEMENTS','Q41g_2','Q41 For how many years have you taken omega-3 fatty acids as a single supplement regularly (at least once a week)?','* 0=Less than 1 year, 1=1, 2=2, 3=3-4, 4=5-9, 5=10+');
INSERT INTO "topic" VALUES('Vitamins','Q5','VITAMINS and SUPPLEMENTS','Q41h_1','Q41 During the past year  how often have you taken soy pills as a single supplement regularly (at least once a week)?','* 0=Don''t take, 1=1-3 days/week, 2=4-6, 3=Every day');
INSERT INTO "topic" VALUES('Vitamins','Q5','VITAMINS and SUPPLEMENTS','Q41h_2','Q41 For how many years have you taken soy pills as a single supplement regularly (at least once a week)?','* 0=Less than 1 year, 1=1, 2=2, 3=3-4, 4=5-9, 5=10+');
INSERT INTO "topic" VALUES('Vitamins','Q5','VITAMINS and SUPPLEMENTS','Q41i_1','Q41 During the past year how often have you taken chondrotin and/or glucosamine as a single supplement regularly (at least once a week)?','* 0=Don''t take, 1=1-3 days/week, 2=4-6, 3=Every day');
INSERT INTO "topic" VALUES('Vitamins','Q5','VITAMINS and SUPPLEMENTS','Q41i_2','Q41 For how many years have you taken chondroitin and/or glucosamine as a single supplement regularly (at least once a week)?','* 0=Less than 1 year, 1=1, 2=2, 3=3-4, 4=5-9, 5=10+');
INSERT INTO "topic" VALUES('Vitamins','Q5','VITAMINS and SUPPLEMENTS','Q42','Q42 If you take vitamin D3 as a single supplement, how much vitamin d3 do you take each time you take it?','* 1=400 IU, 2=800-1000, 3=2000, 4=4000 or more');
INSERT INTO "topic" VALUES('Diet','Q1','DIET','VITNO','Q71 Have you ever taken vitamins regularly? NO','A=Yes');
INSERT INTO "topic" VALUES('Diet','Q1','DIET','VITMULTD','Q71 Have you ever taken multi-vitamins - days/wk?','A=Don''t take, B=1-3, C=4-6, D=Every day, Z=Problem');
INSERT INTO "topic" VALUES('Diet','Q1','DIET','VITMULTY','Q71 Have you ever taken multi-vitamins - years?','A=<1, B=1, C=2, D=3-4, E=5-9, F=10+, Z=Problem');
INSERT INTO "topic" VALUES('Diet','Q1','DIET','VITAD','Q71 Have you ever taken vitamin A reg - days/wk?','A=Don''t take, B=1-3, C=4-6, D=Every day, Z=Problem');
INSERT INTO "topic" VALUES('Diet','Q1','DIET','VITAY','Q71 Have you ever taken vitamin A reg - years?','A=<1, B=1, C=2, D=3-4, E=5-9, F=10+, Z=Problem');
INSERT INTO "topic" VALUES('Diet','Q1','DIET','VITBETAD','Q71 Have you ever taken beta-carotene - days/wk','A=Don''t take, B=1-3, C=4-6, D=Every day, Z=Problem');
INSERT INTO "topic" VALUES('Diet','Q1','DIET','VITBETAY','Q71 Have you ever taken beta-carotene - years?','A=<1, B=1, C=2, D=3-4, E=5-9, F=10+, Z=Problem');
INSERT INTO "topic" VALUES('Diet','Q1','DIET','VITCD','Q71 Have you ever taken vitamin C reg - days/wk?','A=Don''t take, B=1-3, C=4-6, D=Every day, Z=Problem');
INSERT INTO "topic" VALUES('Diet','Q1','DIET','VITCY','Q71 Have you ever taken vitamin C reg - years?','A=<1, B=1, C=2, D=3-4, E=5-9, F=10+, Z=Problem');
INSERT INTO "topic" VALUES('Diet','Q1','DIET','VITED','Q71 Have you ever taken vitamin E reg - days/wk?','A=Don''t take, B=1-3, C=4-6, D=Every day, Z=Problem');
INSERT INTO "topic" VALUES('Diet','Q1','DIET','VITEY','Q71 Have you ever taken vitamin E reg - years?','A=<1, B=1, C=2, D=3-4, E=5-9, F=10+, Z=Problem');
INSERT INTO "topic" VALUES('Diet','Q1','DIET','VITSELD','Q71 Have you ever taken selenium reg - days/wk?','A=Don''t take, B=1-3, C=4-6, D=Every day, Z=Problem');
INSERT INTO "topic" VALUES('Diet','Q1','DIET','VITSELY','Q71 Have you ever taken selenium reg - years?','A=<1, B=1, C=2, D=3-4, E=5-9, F=10+, Z=Problem');
INSERT INTO "topic" VALUES('Diet','Q1','DIET','VITABETA','Q72 How much vit A/beta-car taken (as pt of multi)?','A=5000 IU, B=6000, C=10000, D=20000+, *=Problem');
INSERT INTO "topic" VALUES('Diet','Q1','DIET','VITAONLY','Q72 How much vitamin A (only) do you take?','A=5000 IU, B=8000, C=10000, D=16000+, *=Problem');
INSERT INTO "topic" VALUES('Diet','Q1','DIET','VITBETA','Q72 How much beta-carotene (only) do you take?','A=6000 IU, B=10000, C=25000, D=50000+, *=Problem');
INSERT INTO "topic" VALUES('Diet','Q1','DIET','VITC','Q72 How much vitamin C do you take?','A=100 mg, B=250, C=500, D=750, E=1000, F=1500, G=2000, H=3000+, *=Problem');
INSERT INTO "topic" VALUES('Diet','Q1','DIET','VITE','Q72 How much vitamin E do you take?','A=50 mg, B=200, C=400, D=800, E=1000, F=2000+, *=Problem');
INSERT INTO "topic" VALUES('Diet','Q1','DIET','VITSELEN','Q72 How much selenium do you take?','A=10 mcg, B=15, C=20, D=30, E=40, F=50+, *=Problem');
INSERT INTO "topic" VALUES('Diet','Q1','DIET','SUMFAT','Q74 How often do you use fat/oil in cooking?','A=<1/wk, B=1-2, C=3-4, D=5-6, E=1/day,F=1 1/2, G=2, H=3, I=4+, Z=Problem');
INSERT INTO "topic" VALUES('Diet','Q1','DIET','SUMVEGE','Q74 How many servings of veges do you eat?','A=<1/wk, B=1-2, C=3-4, D=5-6, E=1/day,F=1 1/2, G=2, H=3, I=4+, Z=Problem');
INSERT INTO "topic" VALUES('Diet','Q1','DIET','SUMFRUIT','Q74 How many servings of fruit do you eat?','A=<1/wk, B=1-2, C=3-4, D=5-6, E=1/day,F=1 1/2, G=2, H=3, I=4+, Z=Problem');
INSERT INTO "topic" VALUES('Diet','Q1','DIET','SUMCEREL','Q74 How many servings of cold cereal do you eat?','A=<1/wk, B=1-2, C=3-4, D=5-6, E=1/day,F=1 1/2, G=2, H=3, I=4+, Z=Problem');
INSERT INTO "topic" VALUES('Diet','Q1','DIET','SUMMILK','Q74 How many glasses of milk do you drink?','A=<1/wk, B=1-2, C=3-4, D=5-6, E=1/day,F=1 1/2, G=2, H=3, I=4+, Z=Problem');
INSERT INTO "topic" VALUES('Diet','Q1','DIET','dt_kcal6','Q71-82 Total daily caloric intake','600.93-4999.19, .A=Entire section missing, .B=2-6 sections blank, .C=≥4*s, .D=Daily caloric take<600 kcal, .E=Daily caloric take>5000 kcal, .O=Invalid/missing');
INSERT INTO "topic" VALUES('Diet','Q1','DIET','factor1','Q71-82 diet pattern:factor score for plant-based pattern','-5.632857~10.305891, .A=Pattern NA due to excl');
INSERT INTO "topic" VALUES('Diet','Q1','DIET','factor2','Q71-82 diet pattern:factor score for high protein/fat pattern','-3.066223~13.519282, .A=Pattern NA due to excl');
INSERT INTO "topic" VALUES('Diet','Q1','DIET','factor3','Q71-82 diet pattern:factor scrore for high carb pattern','-5.141422~8.618776, .A=Pattern NA due to excl');
INSERT INTO "topic" VALUES('Diet','Q1','DIET','factor4','Q71-82 diet pattern:factor score for ethnic pattern','-4.877704~13.818143, .A=Pattern NA due to excl');
INSERT INTO "topic" VALUES('Diet','Q1','DIET','factor5','Q71-82 diet pattern:factor score for salad and wine pattern','-5.1086254~9.0384939, .A=Pattern NA due to excl');
INSERT INTO "topic" VALUES('Diet','Q1','DIET','vitgrp','Q71-72 multivit and single vit use variable','1-4, 1=Non-user, 2=Curr, Sing vit only, 3=Curr, Multvit only, 4=Curr, Both mult & sing vit use');
INSERT INTO "topic" VALUES('Diet','Q1','DIET','multpill','Q71-72 number of multivit pills per week','0=Non-user, 2=1-3 d/wk, 5=4-6 d/wk, 7=Everyday, .B=VitUseGrp Missing');
INSERT INTO "topic" VALUES('Diet','Q1','DIET','singpill','Q71-72 number of single vit pills per week','0-28, .B=VitUseGrp Missing');
INSERT INTO "topic" VALUES('Diet','Q1','DIET','multdur','Q71-72 duration in yr category of multivit use','1-6, 1=<1 yr, 2=1 yr, 3=2 yrs, 4=3-4 yrs, 5=5-9 yrs, 6=10+ yrs,.A=Non-user of that type, .B=VitUseGrp Missing, .C=Missing Duration ');
INSERT INTO "topic" VALUES('Diet','Q1','DIET','LOCHEESE','Q77 How often eat lo/nonfat version of - cheese?','A=Always low fat, B=Sometimes, C=Rarely, Z=Problem');
INSERT INTO "topic" VALUES('Diet','Q1','DIET','LOICECRM','Q77 How often lo/nonfat version - ice cream/yogurt?','A=Always low fat, B=Sometimes, C=Rarely, Z=Problem');
INSERT INTO "topic" VALUES('Diet','Q1','DIET','LOSALADD','Q77 How often lo/nonfat version - salad dressing?','A=Always low fat, B=Sometimes, C=Rarely, Z=Problem');
INSERT INTO "topic" VALUES('Diet','Q1','DIET','LOCAKE','Q77 How often lo/nonfat version - cake/cookies?','A=Always low fat, B=Sometimes, C=Rarely, Z=Problem');
INSERT INTO "topic" VALUES('Diet','Q1','DIET','ADDSALT','Q78 How often do you add salt to your food?','A=Seldom/Never, B=Sometimes, C=Often');
INSERT INTO "topic" VALUES('Diet','Q1','DIET','CHIKSKIN','Q79 How often do you eat the skin on chicken?','A=Seldom/Never, B=Sometimes, C=Often');
INSERT INTO "topic" VALUES('Diet','Q1','DIET','MEATFAT','Q80 How often do you eat the fat on meat?','A=Seldom/Never, B=Sometimes, C=Often');
INSERT INTO "topic" VALUES('Diet','Q1','DIET','MEATBRL','Q81 How often do you charbroil/fry your meat?','A=Seldom/Never, B=Sometimes, C=Often, Z=Problem');
INSERT INTO "topic" VALUES('Diet','Q1','DIET','MEATCOOK','Q82 How do you like your meat cooked?','A=Rare, B=Medium, C=Well done, Z=Problem');
INSERT INTO "topic" VALUES('Diet','Q1','DIET','dt_dfib2','Q71-82 Daily Dietary Fiber (grams)','0.243929-80.161185, .A=Entire section missing, .B=2-6 sections blank, .C=≥4*s, .D=Daily caloric take<600 kcal, .E=Daily caloric take>5000 kcal, .O=Invalid/missing');
INSERT INTO "topic" VALUES('Diet','Q1','DIET','dt_prot','Q71-82 Daily Dietary Protein','5.69-283.6,  .A=Entire section missing, .B=2-6 sections blank, .C=≥4*s, .D=Daily caloric take<600 kcal, .E=Daily caloric take>5000 kcal, .O=Invalid/missing');
INSERT INTO "topic" VALUES('Diet','Q1','DIET','dt_fat','Q71-82 Daily Dietary Fat','5.17-270.03,  .A=Entire section missing, .B=2-6 sections blank, .C=≥4*s, .D=Daily caloric take<600 kcal, .E=Daily caloric take>5000 kcal, .O=Invalid/missing');
INSERT INTO "topic" VALUES('Diet','Q1','DIET','dt_calc','Q71-82 Daily Dietary Calcium','47.87-4309.1, .A=Entire section missing, .B=2-6 sections blank, .C=≥4*s, .D=Daily caloric take<600 kcal, .E=Daily caloric take>5000 kcal, .O=Invalid/missing');
INSERT INTO "topic" VALUES('Diet','Q1','DIET','dt_sfat','Q71-82 Daily Dietary Saturated Fat','1.21-110.8, .A=Entire section missing, .B=2-6 sections blank, .C=≥4*s, .D=Daily caloric take<600 kcal, .E=Daily caloric take>5000 kcal, .O=Invalid/missing');
INSERT INTO "topic" VALUES('Diet','Q1','DIET','dt_olec','Q71-82 Daily Dietary Oleic Acid','1.22-114.9, .A=Entire section missing, .B=2-6 sections blank, .C=≥4*s, .D=Daily caloric take<600 kcal, .E=Daily caloric take>5000 kcal, .O=Invalid/missing');
INSERT INTO "topic" VALUES('Diet','Q1','DIET','dt_lin','Q71-82 Daily Dietary Linoleic Acid','0.49-62.84, .A=Entire section missing, .B=2-6 sections blank, .C=≥4*s, .D=Daily caloric take<600 kcal, .E=Daily caloric take>5000 kcal, .O=Invalid/missing');
INSERT INTO "topic" VALUES('Diet','Q1','DIET','dt_chol','Q71-82 Daily Cholesterol','0.78-1342.92, .A=Entire section missing, .B=2-6 sections blank, .C=≥4*s, .D=Daily caloric take<600 kcal, .E=Daily caloric take>5000 kcal, .O=Invalid/missing');
INSERT INTO "topic" VALUES('Diet','Q1','DIET','dt_fol','Q71-82 Daily Dietary Folate','14.88-1636.95, .A=Entire section missing, .B=2-6 sections blank, .C=≥4*s, .D=Daily caloric take<600 kcal, .E=Daily caloric take>5000 kcal, .O=Invalid/missing');
INSERT INTO "topic" VALUES('Diet','Q1','DIET','pctfat','Q71-82 % Calories from Fat','4.16-75.02, .A=Entire section missing, .B=2-6 sections blank, .C=≥4*s, .D=Daily caloric take<600 kcal, .E=Daily caloric take>5000 kcal, .O=Invalid/missing');
INSERT INTO "topic" VALUES('Diet','Q1','DIET','dt_carotenoids','Q71-82 dietary total carotenoids','12.96-46599.6, .A=Entire section missing, .B=2-6 sections blank, .C=≥4*s, .D=Daily caloric take<600 kcal, .E=Daily caloric take>5000 kcal, .O=Invalid/missing');
INSERT INTO "topic" VALUES('Diet','Q1','DIET','dt_carb2','Q71-82 Total grams per day of carbohydrate intake','9.67-698.04, .A=Entire section missing, .B=2-6 sections blank, .C=≥4*s, .D=Daily caloric take<600 kcal, .E=Daily caloric take>5000 kcal, .O=Invalid/missing');
INSERT INTO "topic" VALUES('Diet','Q1','DIET','gi','Q71-82 Average daily glycemic index (white bread as ref), GLYCLOADWB/DT_CARBS (without fiber)','33.56-98.11, .A=Entire section missing, .B=2-6 sections blank, .C=≥4*s, .D=Daily caloric take<600 kcal, .E=Daily caloric take>5000 kcal, .O=Invalid/missing');
INSERT INTO "topic" VALUES('Diet','Q1','DIET','gl','Q71-82 Average tot daily glycemic load (white bread as ref), sum: g/d * (carb-fiber)/100 * GI/100','3.85-566.83, .A=Entire section missing, .B=2-6 sections blank, .C=≥4*s, .D=Daily caloric take<600 kcal, .E=Daily caloric take>5000 kcal, .O=Invalid/missing');
INSERT INTO "topic" VALUES('Diet','Q1','ALCOHOL & TOBACCO USE','ALC18G','Q83 GRAMS PER DAY OF ALCOHOL, AGE 18-22','0-157.2, .F=All alcohol types missing, .G=1+ type was blank and 1+ was reported as "None", .H=any of the 3 types were set to Z, .I=age<30 and so the 30-35 section should not be filled out. .J=errors in alcohol section');
INSERT INTO "topic" VALUES('Diet','Q1','ALCOHOL & TOBACCO USE','ALC30G','Q83 GRAMS PER DAY OF ALCOHOL, AGE 30-35','0-157.2, .F=All alcohol types missing, .G=1+ type was blank and 1+ was reported as "None", .H=any of the 3 types were set to Z, .I=age<30 and so the 30-35 section should not be filled out. .J=errors in alcohol section');
INSERT INTO "topic" VALUES('Diet','Q1','ALCOHOL & TOBACCO USE','ALCYRG','Q83 GRAMS PER DAY OF ALCOHOL, PAST YEAR','0-157.2, .F=All alcohol types missing, .G=1+ type was blank and 1+ was reported as "None", .H=any of the 3 types were set to Z, .I=age<30 and so the 30-35 section should not be filled out. .J=errors in alcohol section');
INSERT INTO "topic" VALUES('Diet','Q1','ALCOHOL & TOBACCO USE','BEER18G','Q83 GRAMS PER DAY OF BEER, AGE 18-22','0-52.8, .F=All alcohol types missing, .G=1+ type was blank and 1+ was reported as "None", .H=any of the 3 types were set to Z, .I=age<30 and so the 30-35 section should not be filled out. .J=errors in alcohol section');
INSERT INTO "topic" VALUES('Diet','Q1','ALCOHOL & TOBACCO USE','WINE18G','Q83 GRAMS PER DAY OF WINE, AGE 18-22','0-44.4, .F=All alcohol types missing, .G=1+ type was blank and 1+ was reported as "None", .H=any of the 3 types were set to Z, .I=age<30 and so the 30-35 section should not be filled out. .J=errors in alcohol section');
INSERT INTO "topic" VALUES('Diet','Q1','ALCOHOL & TOBACCO USE','LIQU18G','Q83 GRAMS PER DAY OF LIQUOR, AGE 18-22','0-60, .F=All alcohol types missing, .G=1+ type was blank and 1+ was reported as "None", .H=any of the 3 types were set to Z, .I=age<30 and so the 30-35 section should not be filled out. .J=errors in alcohol section');
INSERT INTO "topic" VALUES('Diet','Q1','ALCOHOL & TOBACCO USE','BEER30G','Q83 GRAMS PER DAY OF BEER, AGE 30-35','0-52.8, .F=All alcohol types missing, .G=1+ type was blank and 1+ was reported as "None", .H=any of the 3 types were set to Z, .I=age<30 and so the 30-35 section should not be filled out. .J=errors in alcohol section');
INSERT INTO "topic" VALUES('Diet','Q1','ALCOHOL & TOBACCO USE','WINE30G','Q83 GRAMS PER DAY OF WINE, AGE 30-35','0-44.4, .F=All alcohol types missing, .G=1+ type was blank and 1+ was reported as "None", .H=any of the 3 types were set to Z, .I=age<30 and so the 30-35 section should not be filled out. .J=errors in alcohol section');
INSERT INTO "topic" VALUES('Diet','Q1','ALCOHOL & TOBACCO USE','LIQU30G','Q83 GRAMS PER DAY OF LIQUOR, AGE 30-35','0-60, .F=All alcohol types missing, .G=1+ type was blank and 1+ was reported as "None", .H=any of the 3 types were set to Z, .I=age<30 and so the 30-35 section should not be filled out. .J=errors in alcohol section');
INSERT INTO "topic" VALUES('Diet','Q1','ALCOHOL & TOBACCO USE','BEERYRG','Q83 GRAMS PER DAY OF BEER, PAST YEAR','0-52.8, .F=All alcohol types missing, .G=1+ type was blank and 1+ was reported as "None", .H=any of the 3 types were set to Z, .I=age<30 and so the 30-35 section should not be filled out. .J=errors in alcohol section');
INSERT INTO "topic" VALUES('Diet','Q1','ALCOHOL & TOBACCO USE','WINEYRG','Q83 GRAMS PER DAY OF WINE, PAST YEAR','0-44.4, .F=All alcohol types missing, .G=1+ type was blank and 1+ was reported as "None", .H=any of the 3 types were set to Z, .I=age<30 and so the 30-35 section should not be filled out. .J=errors in alcohol section');
INSERT INTO "topic" VALUES('Diet','Q1','ALCOHOL & TOBACCO USE','LIQUYRG','Q83 GRAMS PER DAY OF LIQUOR, PAST YEAR','0-60, .F=All alcohol types missing, .G=1+ type was blank and 1+ was reported as "None", .H=any of the 3 types were set to Z, .I=age<30 and so the 30-35 section should not be filled out. .J=errors in alcohol section');
INSERT INTO "topic" VALUES('Diet','Q1','ALCOHOL & TOBACCO USE','ALCELIG','Q83 ELIGIBLE FOR ALCOHOL ANALYSIS (RESTRICTIVE DEF)','0=No, 1=Yes,eligible for alcohol analysis');
INSERT INTO "topic" VALUES('Diet','Q1','ALCOHOL & TOBACCO USE','ALCYRC','Q83 CAT OF ALCOHOL G/D PAST YR FOR BC ANALYSIS','0-2, 0=None, 1=<20 g/d, 2=≥20 g/d');
INSERT INTO "topic" VALUES('Diet','Q4','DIET','VGSERV','Q34 During the past year, how many servings of vegetables (not counting salad or potatoes) did you usually eat? ','A=<1/wk, B= 1-2/wk, C=3-4/wk, D=5-6/wk, E=1/day, F= 1 1/2/day, G=2/day, H=3/day, I=4/day, X=Unable to resolve');
INSERT INTO "topic" VALUES('Diet','Q4','DIET','FTSERV','Q34 During the past year, how many servings of fruit (not counting juice) did you usually eat? ','A=<1/wk, B= 1-2/wk, C=3-4/wk, D=5-6/wk, E=1/day, F= 1 1/2/day, G=2/day, H=3/day, I=4/day, X=Unable to resolve');
INSERT INTO "topic" VALUES('Diet','Q4','DIET','CRSERV','Q34 During the past year, how many servings of cold cereal did you usually eat? ','A=<1/wk, B= 1-2/wk, C=3-4/wk, D=5-6/wk, E=1/day, F= 1 1/2/day, G=2/day, H=3/day, I=4/day, X=Unable to resolve');
INSERT INTO "topic" VALUES('Diet','Q4','DIET','LFCHEE','Q41 How often do you eat low-fat or non-fat cheese? ','A=Never or rarely, B=Sometimes, C=Always or often');
INSERT INTO "topic" VALUES('Diet','Q4','DIET','LFYOG','Q41 How often do you eat low-fat or non-fat yogurt?','A=Never or rarely, B=Sometimes, C=Always or often');
INSERT INTO "topic" VALUES('Diet','Q4','DIET','LFMAYO','Q41 How often do you eat low-fat or non-fat salad dressing or mayonnaise?','A=Never or rarely, B=Sometimes, C=Always or often');
INSERT INTO "topic" VALUES('Diet','Q4','DIET','LFICEC','Q41 How often do you eat low-fat or non-fat ice cream?','A=Never or rarely, B=Sometimes, C=Always or often');
INSERT INTO "topic" VALUES('Diet','Q4','DIET','LFCAKE','Q41 How often do you eat low-fat or non-fat cookies or cake?','A=Never or rarely, B=Sometimes, C=Always or often');
INSERT INTO "topic" VALUES('Diet','Q4','DIET','ADSUGR','Q41 How often do you add sugar to coffee or tea? ','A=Never or rarely, B=Sometimes, C=Always or often');
INSERT INTO "topic" VALUES('Diet','Q4','DIET','ADBUTV','Q41 How often do you add butter to vegetables or potatoes? ','A=Never or rarely, B=Sometimes, C=Always or often');
INSERT INTO "topic" VALUES('Diet','Q4','DIET','ADMARV','Q41 How often do you add margarine to vegetables or potatoes?','A=Never or rarely, B=Sometimes, C=Always or often');
INSERT INTO "topic" VALUES('Diet','Q4','DIET','ADBUTB','Q41 How often do you add butter to bread? ','A=Never or rarely, B=Sometimes, C=Always or often');
INSERT INTO "topic" VALUES('Diet','Q4','DIET','ADMARB','Q41 How often do you add margarine to bread? ','A=Never or rarely, B=Sometimes, C=Always or often');
INSERT INTO "topic" VALUES('Diet','Q4','DIET','MEATFT','Q41 How often do you eat the fat on meat? ','A=Never or rarely, B=Sometimes, C=Always or often');
INSERT INTO "topic" VALUES('Diet','Q4','DIET','CHIKFT','Q41 How often do you eat the skin on chicken? ','A=Never or rarely, B=Sometimes, C=Always or often');
INSERT INTO "topic" VALUES('Diet','Q4','DIET','dietelig','Q33-41 Indicator variable, whether eligible for dietary analyses','0=Ineligible, 1=Eligible');
INSERT INTO "topic" VALUES('Diet','Q4','VITAMIN SUPPLEMENTS','MVPST','Q42 During the past year, have you taken multivitamin pills regularly? (No, Yes (all year), or Yes (season only)','A=No, B=Yes all yr, C=Yes only in seasonally, X=Unable to resolve');
INSERT INTO "topic" VALUES('Diet','Q4','VITAMIN SUPPLEMENTS','VITAPST','Q42 During the past year, have you taken Vitamin A or beta-carotene (as a single supplement) regularly? [No, Yes (all year), or Yes (season only)]','A=No, B=Yes all yr, C=Yes only in seasonally, X=Unable to resolve');
INSERT INTO "topic" VALUES('Diet','Q4','VITAMIN SUPPLEMENTS','VITCPST','Q42 During the past year, have you taken Vitamin C (as a single supplement) regularly? [No, Yes (all year), or Yes (season only)]','A=No, B=Yes all yr, C=Yes only in seasonally, X=Unable to resolve');
INSERT INTO "topic" VALUES('Diet','Q4','VITAMIN SUPPLEMENTS','VITEPST','Q42 During the past year, have you taken Vitamin E (as a single supplement) regularly? [No, Yes (all year), or Yes (season only)]','A=No, B=Yes all yr, C=Yes only in seasonally, X=Unable to resolve');
INSERT INTO "topic" VALUES('Diet','Q4','VITAMIN SUPPLEMENTS','CALCPST','Q42 During the past year, have you taken Calcium, including Tums, Os Cal, etc. (with or without added Vitamin D)? [No, Yes (all year), or Yes (season only)]','A=No, B=Yes all yr, C=Yes only in seasonally, X=Unable to resolve');
INSERT INTO "topic" VALUES('Diet','Q4','VITAMIN SUPPLEMENTS','MVMINRAL','Q43 If you take multivitamins, do you usually take multivitamins that contain minerals? ','Y=Yes, N=No, X=Unable to resolve');
INSERT INTO "topic" VALUES('Diet','Q4','VITAMIN SUPPLEMENTS','MVANTIOX','Q43 If you take multivitamins, do you usually take multivitamins that contain extra antioxidents? ','Y=Yes, N=No, X=Unable to resolve');
INSERT INTO "topic" VALUES('Diet','Q4','VITAMIN SUPPLEMENTS','VITCM','Q44 If you take vitamin C as a single supplement, how much do you take each time you take it? ','A=250 mg or less, B=300-500 mg, C=600-1000 mg, D=More than 1000 mg, Z=Problem');
INSERT INTO "topic" VALUES('Diet','Q4','VITAMIN SUPPLEMENTS','VITEM','Q45 If you take vitamin E as a single supplement, how much do you take each time you take it? ','A=200 IU, B=250-400 IU, C=450-1000 IU, D=More than 1000 IU, Z=Problem');
INSERT INTO "topic" VALUES('Diet','Q4','VITAMIN SUPPLEMENTS','mvfreq','Q42 How often take multivitamins?','A=1-3, B=4-6, C=Every day, U=Blank Out The Data, W&X=Irresolvable');
INSERT INTO "topic" VALUES('Diet','Q4','VITAMIN SUPPLEMENTS','mvyear','Q42 How many years taken multivitamins?','A=<1 yr, B=1 yr, C=2 yrs, D=3-4 yrs, E=5-9 yrs, F=10+ yrs, U&V=Blank Out The Data, W&X=Irresolvable');
INSERT INTO "topic" VALUES('Diet','Q4','VITAMIN SUPPLEMENTS','vitafreq','Q42 How often take vitamin A or beta-carotene?','A=1-3, B=4-6, C=Every day, U=Blank Out The Data, W&X=Irresolvable');
INSERT INTO "topic" VALUES('Diet','Q4','VITAMIN SUPPLEMENTS','vitayear','Q42 How many years taken vitamin A or beta-carotene?','A=<1 yr, B=1 yr, C=2 yrs, D=3-4 yrs, E=5-9 yrs, F=10+ yrs, U&V=Blank Out The Data, W&X=Irresolvable');
INSERT INTO "topic" VALUES('Diet','Q4','VITAMIN SUPPLEMENTS','vitcfreq','Q42 How often take vitamin C?','A=1-3, B=4-6, C=Every day, U=Blank Out The Data, W&X=Irresolvable');
INSERT INTO "topic" VALUES('Diet','Q4','VITAMIN SUPPLEMENTS','vitcyear','Q42 How many years taken vitamin C?','A=<1 yr, B=1 yr, C=2 yrs, D=3-4 yrs, E=5-9 yrs, F=10+ yrs, U&V=Blank Out The Data, W&X=Irresolvable');
INSERT INTO "topic" VALUES('Diet','Q4','VITAMIN SUPPLEMENTS','vitefreq','Q42 How often take vitamin E?','A=1-3, B=4-6, C=Every day, U=Blank Out The Data, W&X=Irresolvable');
INSERT INTO "topic" VALUES('Diet','Q4','VITAMIN SUPPLEMENTS','viteyear','Q42 How many years taken vitamin E?','A=<1 yr, B=1 yr, C=2 yrs, D=3-4 yrs, E=5-9 yrs, F=10+ yrs, U&V=Blank Out The Data, W&X=Irresolvable');
INSERT INTO "topic" VALUES('Diet','Q4','VITAMIN SUPPLEMENTS','calcfreq','Q42 How often take calcium?','A=1-3, B=4-6, C=Every day, U=Blank Out The Data, W&X=Irresolvable');
INSERT INTO "topic" VALUES('Diet','Q4','VITAMIN SUPPLEMENTS','calcyear','Q42 How many years taken calcium?','A=<1 yr, B=1 yr, C=2 yrs, D=3-4 yrs, E=5-9 yrs, F=10+ yrs, U&V=Blank Out The Data, W&X=Irresolvable');
INSERT INTO "topic" VALUES('Diet','Q5','VITAMINS and SUPPLEMENTS','Q41a_1','Q41 During the  past year  how often have you taken multi-vitamin supplements regularly (at least once a week)?','* 0=Don''t take, 1=1-3 days/week, 2=4-6, 3=Every day');
INSERT INTO "topic" VALUES('Diet','Q5','VITAMINS and SUPPLEMENTS','Q41a_2','Q41 For how many years have you taken multi-vitamin supplements regularly (at least once a week)?','* 0=Less than 1 year, 1=1, 2=2, 3=3-4, 4=5-9, 5=10+');
INSERT INTO "topic" VALUES('Diet','Q5','VITAMINS and SUPPLEMENTS','Q41b_1','Q41 During the  past year how often have you taken vitamin B12 as a single supplement regularly (at least once a week)?','* 0=Don''t take, 1=1-3 days/week, 2=4-6, 3=Every day');
INSERT INTO "topic" VALUES('Diet','Q5','VITAMINS and SUPPLEMENTS','Q41b_2','Q41 For how many years have you taken vitamin B12 as a single supplement regularly (at least once a week)?','* 0=Less than 1 year, 1=1, 2=2, 3=3-4, 4=5-9, 5=10+');
INSERT INTO "topic" VALUES('Diet','Q5','VITAMINS and SUPPLEMENTS','Q41c_1','Q41 During the  past year  how often have you taken calcium and vitamin D as a single supplement regularly (at least once a week)?','* 0=Don''t take, 1=1-3 days/week, 2=4-6, 3=Every day');
INSERT INTO "topic" VALUES('Diet','Q5','VITAMINS and SUPPLEMENTS','Q41c_2','Q41 For how many years have you taken calcium and vitamin D as a single supplement regularly (at least once a week)?','* 0=Less than 1 year, 1=1, 2=2, 3=3-4, 4=5-9, 5=10+');
INSERT INTO "topic" VALUES('Diet','Q5','VITAMINS and SUPPLEMENTS','Q41d_1','Q41 During the  past year how often have you taken vitamin D3 as a single supplement regularly (at least once a week)?','* 0=Don''t take, 1=1-3 days/week, 2=4-6, 3=Every day');
INSERT INTO "topic" VALUES('Diet','Q5','VITAMINS and SUPPLEMENTS','Q41d_2','Q41 For how many years have you taken vitamin D3 as a single supplement regularly (at least once a week)?','* 0=Less than 1 year, 1=1, 2=2, 3=3-4, 4=5-9, 5=10+');
INSERT INTO "topic" VALUES('Diet','Q5','VITAMINS and SUPPLEMENTS','Q41e_1','Q41 During the past year  how often have you taken calcium as a single  supplement regularly (at least once a week)?','* 0=Don''t take, 1=1-3 days/week, 2=4-6, 3=Every day');
INSERT INTO "topic" VALUES('Diet','Q5','VITAMINS and SUPPLEMENTS','Q41e_2','Q41 For how many years have you taken calcium as a single supplement regularly (at least once a week)?','* 0=Less than 1 year, 1=1, 2=2, 3=3-4, 4=5-9, 5=10+');
INSERT INTO "topic" VALUES('Diet','Q5','VITAMINS and SUPPLEMENTS','Q41f_1','Q41 During the past year how often have you taken niacin as a single supplement regularly (at least once a week)?','* 0=Don''t take, 1=1-3 days/week, 2=4-6, 3=Every day');
INSERT INTO "topic" VALUES('Diet','Q5','VITAMINS and SUPPLEMENTS','Q41f_2','Q41 For how many years have you taken niacin as a single supplement regularly (at least once a week)?','* 0=Less than 1 year, 1=1, 2=2, 3=3-4, 4=5-9, 5=10+');
INSERT INTO "topic" VALUES('Diet','Q5','VITAMINS and SUPPLEMENTS','Q41g_1','Q41 During the past year how often have you taken omega-3 fatty acids as single supplement regularly (at least once a week)?','* 0=Don''t take, 1=1-3 days/week, 2=4-6, 3=Every day');
INSERT INTO "topic" VALUES('Diet','Q5','VITAMINS and SUPPLEMENTS','Q41g_2','Q41 For how many years have you taken omega-3 fatty acids as a single supplement regularly (at least once a week)?','* 0=Less than 1 year, 1=1, 2=2, 3=3-4, 4=5-9, 5=10+');
INSERT INTO "topic" VALUES('Diet','Q5','VITAMINS and SUPPLEMENTS','Q41h_1','Q41 During the past year  how often have you taken soy pills as a single supplement regularly (at least once a week)?','* 0=Don''t take, 1=1-3 days/week, 2=4-6, 3=Every day');
INSERT INTO "topic" VALUES('Diet','Q5','VITAMINS and SUPPLEMENTS','Q41h_2','Q41 For how many years have you taken soy pills as a single supplement regularly (at least once a week)?','* 0=Less than 1 year, 1=1, 2=2, 3=3-4, 4=5-9, 5=10+');
INSERT INTO "topic" VALUES('Diet','Q5','VITAMINS and SUPPLEMENTS','Q41i_1','Q41 During the past year how often have you taken chondrotin and/or glucosamine as a single supplement regularly (at least once a week)?','* 0=Don''t take, 1=1-3 days/week, 2=4-6, 3=Every day');
INSERT INTO "topic" VALUES('Diet','Q5','VITAMINS and SUPPLEMENTS','Q41i_2','Q41 For how many years have you taken chondroitin and/or glucosamine as a single supplement regularly (at least once a week)?','* 0=Less than 1 year, 1=1, 2=2, 3=3-4, 4=5-9, 5=10+');
INSERT INTO "topic" VALUES('Diet','Q5','VITAMINS and SUPPLEMENTS','Q42','Q42 If you take vitamin D3 as a single supplement, how much vitamin d3 do you take each time you take it?','* 1=400 IU, 2=800-1000, 3=2000, 4=4000 or more');
INSERT INTO "topic" VALUES('Alcohol use','Q1','ALCOHOL & TOBACCO USE','ALC18G','Q83 GRAMS PER DAY OF ALCOHOL, AGE 18-22','0-157.2, .F=All alcohol types missing, .G=1+ type was blank and 1+ was reported as "None", .H=any of the 3 types were set to Z, .I=age<30 and so the 30-35 section should not be filled out. .J=errors in alcohol section');
INSERT INTO "topic" VALUES('Alcohol use','Q1','ALCOHOL & TOBACCO USE','ALC30G','Q83 GRAMS PER DAY OF ALCOHOL, AGE 30-35','0-157.2, .F=All alcohol types missing, .G=1+ type was blank and 1+ was reported as "None", .H=any of the 3 types were set to Z, .I=age<30 and so the 30-35 section should not be filled out. .J=errors in alcohol section');
INSERT INTO "topic" VALUES('Alcohol use','Q1','ALCOHOL & TOBACCO USE','ALCYRG','Q83 GRAMS PER DAY OF ALCOHOL, PAST YEAR','0-157.2, .F=All alcohol types missing, .G=1+ type was blank and 1+ was reported as "None", .H=any of the 3 types were set to Z, .I=age<30 and so the 30-35 section should not be filled out. .J=errors in alcohol section');
INSERT INTO "topic" VALUES('Alcohol use','Q1','ALCOHOL & TOBACCO USE','BEER18G','Q83 GRAMS PER DAY OF BEER, AGE 18-22','0-52.8, .F=All alcohol types missing, .G=1+ type was blank and 1+ was reported as "None", .H=any of the 3 types were set to Z, .I=age<30 and so the 30-35 section should not be filled out. .J=errors in alcohol section');
INSERT INTO "topic" VALUES('Alcohol use','Q1','ALCOHOL & TOBACCO USE','WINE18G','Q83 GRAMS PER DAY OF WINE, AGE 18-22','0-44.4, .F=All alcohol types missing, .G=1+ type was blank and 1+ was reported as "None", .H=any of the 3 types were set to Z, .I=age<30 and so the 30-35 section should not be filled out. .J=errors in alcohol section');
INSERT INTO "topic" VALUES('Alcohol use','Q1','ALCOHOL & TOBACCO USE','LIQU18G','Q83 GRAMS PER DAY OF LIQUOR, AGE 18-22','0-60, .F=All alcohol types missing, .G=1+ type was blank and 1+ was reported as "None", .H=any of the 3 types were set to Z, .I=age<30 and so the 30-35 section should not be filled out. .J=errors in alcohol section');
INSERT INTO "topic" VALUES('Alcohol use','Q1','ALCOHOL & TOBACCO USE','BEER30G','Q83 GRAMS PER DAY OF BEER, AGE 30-35','0-52.8, .F=All alcohol types missing, .G=1+ type was blank and 1+ was reported as "None", .H=any of the 3 types were set to Z, .I=age<30 and so the 30-35 section should not be filled out. .J=errors in alcohol section');
INSERT INTO "topic" VALUES('Alcohol use','Q1','ALCOHOL & TOBACCO USE','WINE30G','Q83 GRAMS PER DAY OF WINE, AGE 30-35','0-44.4, .F=All alcohol types missing, .G=1+ type was blank and 1+ was reported as "None", .H=any of the 3 types were set to Z, .I=age<30 and so the 30-35 section should not be filled out. .J=errors in alcohol section');
INSERT INTO "topic" VALUES('Alcohol use','Q1','ALCOHOL & TOBACCO USE','LIQU30G','Q83 GRAMS PER DAY OF LIQUOR, AGE 30-35','0-60, .F=All alcohol types missing, .G=1+ type was blank and 1+ was reported as "None", .H=any of the 3 types were set to Z, .I=age<30 and so the 30-35 section should not be filled out. .J=errors in alcohol section');
INSERT INTO "topic" VALUES('Alcohol use','Q1','ALCOHOL & TOBACCO USE','BEERYRG','Q83 GRAMS PER DAY OF BEER, PAST YEAR','0-52.8, .F=All alcohol types missing, .G=1+ type was blank and 1+ was reported as "None", .H=any of the 3 types were set to Z, .I=age<30 and so the 30-35 section should not be filled out. .J=errors in alcohol section');
INSERT INTO "topic" VALUES('Alcohol use','Q1','ALCOHOL & TOBACCO USE','WINEYRG','Q83 GRAMS PER DAY OF WINE, PAST YEAR','0-44.4, .F=All alcohol types missing, .G=1+ type was blank and 1+ was reported as "None", .H=any of the 3 types were set to Z, .I=age<30 and so the 30-35 section should not be filled out. .J=errors in alcohol section');
INSERT INTO "topic" VALUES('Alcohol use','Q1','ALCOHOL & TOBACCO USE','LIQUYRG','Q83 GRAMS PER DAY OF LIQUOR, PAST YEAR','0-60, .F=All alcohol types missing, .G=1+ type was blank and 1+ was reported as "None", .H=any of the 3 types were set to Z, .I=age<30 and so the 30-35 section should not be filled out. .J=errors in alcohol section');
INSERT INTO "topic" VALUES('Alcohol use','Q1','ALCOHOL & TOBACCO USE','ALCELIG','Q83 ELIGIBLE FOR ALCOHOL ANALYSIS (RESTRICTIVE DEF)','0=No, 1=Yes,eligible for alcohol analysis');
INSERT INTO "topic" VALUES('Alcohol use','Q1','ALCOHOL & TOBACCO USE','ALCYRC','Q83 CAT OF ALCOHOL G/D PAST YR FOR BC ANALYSIS','0-2, 0=None, 1=<20 g/d, 2=≥20 g/d');
INSERT INTO "topic" VALUES('Smoking','Q1','ALCOHOL & TOBACCO USE','CIGFIRX','Q85 RECONSTITUTED - Age first smoked','10-70, .I=Invalid responses, .Z=Problem');
INSERT INTO "topic" VALUES('Smoking','Q1','ALCOHOL & TOBACCO USE','CIGLASX','Q85 RECONSTITUTED -Age last smoked','10-97, .I=Invalid responses, .Z=Problem');
INSERT INTO "topic" VALUES('Smoking','Q1','ALCOHOL & TOBACCO USE','LES','Q84-88 LIFETIME EXPOSURE TO SMOKE','0-184.05');
INSERT INTO "topic" VALUES('Smoking','Q1','ALCOHOL & TOBACCO USE','SMOKE','Q84-88 SMOKING GROUP','1-22, 1=NoExp, 2=POCO1P, 3=POCO2P, 4=POAO, 5=POCA1P, 6=POCA2P,7=FNR10NP, 8=FNR10C, 9=FNR10A, 10=FNR10B, 11=FGT10NP 12=FGT10C,13=FGT10A, 14=FGT10B, 15=CNR10NP, 16=CNR10C, 17=CNR10A, 18=CNR10B, 19=CGT10NP, 20=CGT10C, 21=CGT10A, 22=CGT10B, .Q=Q84Blnk, .R=Q84star, .S=Q878blnv, .T=Q878blcs, .U=Q878blfs, .V=Q878stnv, .W=Q878stcs, .X=Q878stfs, .Y=Q86Blnk, .Z=Q85neg');
INSERT INTO "topic" VALUES('Smoking','Q1','ALCOHOL & TOBACCO USE','LESQUIN','Q84-88 GROUPS: NO EXPOSURE, QUARTILES OF LES','0-4');
INSERT INTO "topic" VALUES('Smoking','Q1','ALCOHOL & TOBACCO USE','SMKGRP','Q84 SMOKING STATUS CATEGORIES','1-3, 1=Never, 2=Former, 3=Current');
INSERT INTO "topic" VALUES('Smoking','Q1','ALCOHOL & TOBACCO USE','SMKEXP','Q84, 87, 88 SMOKING EXPOSURE CATEGORIES','1-4, 1=NoExp, 2=Passive, 3=Former, 4=Current');
INSERT INTO "topic" VALUES('Smoking','Q1','ALCOHOL & TOBACCO USE','PASSEXP','Q84, 87, 88 PASSIVE SMOKE EXPOSURE CATEGORIES','1-4, 1=NoExp, 2=Child Only, 3=Adult Only, 4=Both CH/AD');
INSERT INTO "topic" VALUES('Smoking','Q1','ALCOHOL & TOBACCO USE','TYRSSMK','Q2, 84, 85 TOTAL YEARS SMOKED','0.5-75 ');
INSERT INTO "topic" VALUES('Smoking','Q1','ALCOHOL & TOBACCO USE','AVGCIGDY','Q84-86 AVG NUMBER OF CIGARETTES SMOKED PER DAY','0.5-40');
INSERT INTO "topic" VALUES('Smoking','Q1','ALCOHOL & TOBACCO USE','TPACKYRS','Q2, 84-86 TOTAL PACK YEARS OF SMOKING','0.0125-140');
INSERT INTO "topic" VALUES('Smoking','Q1','ALCOHOL & TOBACCO USE','TYRSQUIT','Q2, 84-85 TOTAL YEARS SINCE QUIT SMOKING','0.5-71');
INSERT INTO "topic" VALUES('Smoking','Q1','ALCOHOL & TOBACCO USE','SMKPREPRG','Q2, 28, 84, 85 TOTAL YEARS SMOKED PRIOR PREGNANCY','Jan-32');
INSERT INTO "topic" VALUES('Smoking','Q1','ALCOHOL & TOBACCO USE','SMKPSTPRG','Q2, 28, 84, 85 TOTAL YEARS SMOKED POST PREGNANCY','Jan-46');
INSERT INTO "topic" VALUES('Smoking','Q1','ALCOHOL & TOBACCO USE','SMKPREG','Q2, 28, 84, 85 SMOKING IN RELATION TO FIRST PREGNANCY CATEGORIES','1-4, 1=Never smoker, 2=Smoked postpartum, 3=Smoked prepartum <5y, 4=Smoked prepartum 5+yr');
INSERT INTO "topic" VALUES('Smoking','Q2','SECONDHAND SMOKE','chexp','Any age <20 exposure across any setting. Derived
variable for secondhand smoke section. Added
07052018','Y=Yes, N=None, U=Unknown,
E=Exposed other than age <20,
F=Unknown exposure in other
settings/time period');
INSERT INTO "topic" VALUES('Smoking','Q2','SECONDHAND SMOKE','adexp','Any age >=20 exposure across any setting. Derived
variable for secondhand smoke section. Added
07052018','Y=Yes, N=None, U=Unknown,
E=Exposed other than age >=20,
F=Unknown exposure in other
settings/time period');
INSERT INTO "topic" VALUES('Smoking','Q2','SECONDHAND SMOKE','chhous','Any household age <20 exposure. Derived variable
for secondhand smoke section. Added 07052018','Y=Yes, N=None, U=Unknown household
age <20 exposure, E=Exposed other
than household age <20, F=Unknown
exposure in other settings/time period');
INSERT INTO "topic" VALUES('Smoking','Q2','SECONDHAND SMOKE','adhous','Any household age >=20. Derived variable for
secondhand smoke section. Added 07052018','Y=Yes, N=None, U=Unknown household
age >=20 exposure, E=Exposed other
than household age >=20, F=Unknown
exposure in other settings/time period');
INSERT INTO "topic" VALUES('Smoking','Q2','SECONDHAND SMOKE','chwork','Any workplace age <20 exposure. Derived variable
for secondhand smoke section. Added 07052018','Y=Yes, N=None, U=Unknown workplace
age <20 exposure, E=Exposed other
than workplace age <20, F=Unknown
exposure in other settings/time period');
INSERT INTO "topic" VALUES('Smoking','Q2','SECONDHAND SMOKE','adwork','Any workplace age >=20 exposure. Derived variable
for secondhand smoke section. Added 07052018','Y=Yes, N=None, U=Unknown workplace
age >=20 exposure, E=Exposed other
than workplace age >=20, F=Unknown
exposure in other settings/time period');
INSERT INTO "topic" VALUES('Smoking','Q2','SECONDHAND SMOKE','chothr','Any social setting age <20 exposure. Derived
variable for secondhand smoke section. Added
07052018','Y=Yes, N=None, U=Unknown social
setting age <20 exposure, E=Exposed
other than social setting age <20,
F=Unknown exposure in other
settings/time period');
INSERT INTO "topic" VALUES('Smoking','Q2','SECONDHAND SMOKE','adothr','Any social setting age >=20 exposure. Derived
variable for secondhand smoke section. Added
07052018','Y=Yes, N=None, U=Unknown social
setting age >=20 exposure, E=Exposed
other than social setting age >=20,
F=Unknown exposure in other
settings/time period');
INSERT INTO "topic" VALUES('Smoking','Q2','SECONDHAND SMOKE','anyexp','Any lifetime exposure across any setting (home,
work, social) and time period (age<20 and age
>=20). Derived variable for secondhand smoke
section. Added 07052018','Y=Yes, N=None, U=Unknown');
INSERT INTO "topic" VALUES('Smoking','Q2','SECONDHAND SMOKE','anyhous','Any household lifetime exposure. Derived variable
for secondhand smoke section. Added 07052018','Y=Yes, N=None, E=Exposed in setting
other than household, F=Unknown
exposure in other settings, U=Unknown
household exposure');
INSERT INTO "topic" VALUES('Smoking','Q2','SECONDHAND SMOKE','anywork','Any workplace lifetime exposure. Derived variable for
secondhand smoke section. Added 07052018','Y=Yes, N=None, E=Exposed in setting
other than workplace, F=Unknown
exposure in other settings, U=Unknown
workplace exposure');
INSERT INTO "topic" VALUES('Smoking','Q2','SECONDHAND SMOKE','anyothr','Any social lifetime exposure. Derived variable for
secondhand smoke section. Added 07052018','Y=Yes, N=None, E=Exposued in setting
other than social setting, F=Unknown
exposure in other settings, U=Unknown
household exposure');
INSERT INTO "topic" VALUES('Smoking','Q2','SECONDHAND SMOKE','anyyrs','Cumulative lifetime years exposure. Derived variable
for secondhand smoke section. Added 07052018','0.5-204, 0=None, .=missing/unknown');
INSERT INTO "topic" VALUES('Smoking','Q2','SECONDHAND SMOKE','adyrs','Cumulative age >=20 across settings years
exposure. Derived variable for secondhand smoke
section. Added 07052018','0.5-163.5, 0=None,
.=missing/unknown at age >=20');
INSERT INTO "topic" VALUES('Smoking','Q2','SECONDHAND SMOKE','chyrs','Cumulative age <20 across settings years exposure.
Derived variable for secondhand smoke section.
Added 07052018','3.0-52.5, 0=None,
.=missing/unknown at age <20');
INSERT INTO "topic" VALUES('Smoking','Q2','SECONDHAND SMOKE','anysev','Cumulative lifetime intensity-years exposure. Derived
variable for secondhand smoke section. Added
07052018','0.5-604.5, 0=None,
.=missing/unknown');
INSERT INTO "topic" VALUES('Smoking','Q2','SECONDHAND SMOKE','adsev','Cumulative age >=20 intensity-years exposure.
Derived variable for secondhand smoke section.
Added 07052018','0.5-490.5, 0=None,
.=missing/unknown at age >=20');
INSERT INTO "topic" VALUES('Smoking','Q2','SECONDHAND SMOKE','chsev','Cumulative age <20 intensity-years exposure.
Derived variable for secondhand smoke section.
Added 07052018','3.0-157.5, 0=None,
.=missing/unknown at age <20');
INSERT INTO "topic" VALUES('Smoking','Q2','SECONDHAND SMOKE','anyintsum','Cumulative lifetime intensity exposure. Derived
variable for secondhand smoke section. Added
07052018','1.0-9.0, 0=None, .=missing/unknown');
INSERT INTO "topic" VALUES('Smoking','Q2','SECONDHAND SMOKE','adintsum','Cumulative age >=20 intensity-years exposure.
Derived variable for secondhand smoke section.
Added 07052018','1.0-9.0, 0=None, .=missing/unknown
at age >=20');
INSERT INTO "topic" VALUES('Smoking','Q2','SECONDHAND SMOKE','chintsum','Cumulative age <20 intensity exposure. Derived
variable for secondhand smoke section. Added
07052018','1.0-9.0, 0=None, .=missing/unknown
at age <20');
INSERT INTO "topic" VALUES('Smoking','Q4','SMOKING & PREGNANCY','SPOWNBX','Q46 GENERATED VARIABLE FOR Before preg cigs per day','A=Did not smoke, B=<10, C=10-19, D=20+, V=Questionnaire section blank, Z=Multiple responses');
INSERT INTO "topic" VALUES('Smoking','Q4','SMOKING & PREGNANCY','SPOWNDX','Q46 GENERATED VARIABLE FOR During preg cigs per day','A=Did not smoke, B=<10, C=10-19, D=20+, V=Questionnaire section blank, Z=Multiple responses');
INSERT INTO "topic" VALUES('Smoking','Q4','SMOKING & PREGNANCY','SPNOSMBX','Q46 GENERATED VARIABLE FOR No-one smoked around me before pregnancy','Y=Yes, U=Wrong page #12, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Smoking','Q4','SMOKING & PREGNANCY','SPNOSMDX','Q46 GENERATED VARIABLE FOR No-one smoked around me during pregnancy','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Smoking','Q4','SMOKING & PREGNANCY','SPHOMEBX','Q46 GENERATED VARIABLE FOR Others at home smoked before pregnancy','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Smoking','Q4','SMOKING & PREGNANCY','SPHOMEDX','Q46 GENERATED VARIABLE FOR Others at home smoked during pregnancy','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Smoking','Q4','SMOKING & PREGNANCY','SPWORKBX','Q46 GENERATED VARIABLE FOR Others at work smoked before pregnancy','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Smoking','Q4','SMOKING & PREGNANCY','SPWORKDX','Q46 GENERATED VARIABLE FOR Others at work smoked during pregnancy','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Smoking','Q4','SMOKING & PREGNANCY','SPOTHRBX','Q46 GENERATED VARIABLE FOR Others smoked around me before pregnancy','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Smoking','Q4','SMOKING & PREGNANCY','SPOTHRDX','Q46 GENERATED VARIABLE FOR Others smoked around me during pregnancy','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Smoking','Q4','SMOKING & PREGNANCY','SBPRG1X','Q46 GENERATED VARIABLE FOR Did first pregnancy result in a live birth?','Y=Yes, N=No, U=Unk, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Smoking','Q4','SMOKING & PREGNANCY','SBOWNBX','Q46 GENERATED VARIABLE FOR Own smokg before live birth cigs per day','A=Did not smoke, B=<10, C=10-19, D=20+, V=Questionnaire section blank, Z=Multiple responses');
INSERT INTO "topic" VALUES('Smoking','Q4','SMOKING & PREGNANCY','SBOWNDX','Q46 GENERATED VARIABLE FOR Own smokg during live birth cigs per day','A=Did not smoke, B=<10, C=10-19, D=20+, V=Questionnaire section blank, Z=Multiple responses');
INSERT INTO "topic" VALUES('Smoking','Q4','SMOKING & PREGNANCY','SBNOSMBX','Q46 GENERATED VARIABLE FOR No-one smoked before live birth','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Smoking','Q4','SMOKING & PREGNANCY','SBNOSMDX','Q46 GENERATED VARIABLE FOR No-one smoked during live birth','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Smoking','Q4','SMOKING & PREGNANCY','SBHOMEBX','Q46 GENERATED VARIABLE FOR Others at home smoked before live birth','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Smoking','Q4','SMOKING & PREGNANCY','SBHOMEDX','Q46 GENERATED VARIABLE FOR Others at home smoked during live birth','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Smoking','Q4','SMOKING & PREGNANCY','SBWORKBX','Q46 GENERATED VARIABLE FOR Others at work smoked before live birth','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Smoking','Q4','SMOKING & PREGNANCY','SBWORKDX','Q46 GENERATED VARIABLE FOR Others at work smoked during live birth','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Smoking','Q4','SMOKING & PREGNANCY','SBOTHRBX','Q46 GENERATED VARIABLE FOR Others smoked around me before live birth','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Smoking','Q4','SMOKING & PREGNANCY','SBOTHRDX','Q46 GENERATED VARIABLE FOR Others smoked around me during live birth','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Secondhand smoke','Q1','ALCOHOL & TOBACCO USE','PASSEXP','Q84, 87, 88 PASSIVE SMOKE EXPOSURE CATEGORIES','1-4, 1=NoExp, 2=Child Only, 3=Adult Only, 4=Both CH/AD');
INSERT INTO "topic" VALUES('Secondhand smoke','Q2','SECONDHAND SMOKE','chexp','Any age <20 exposure across any setting. Derived
variable for secondhand smoke section. Added
07052018','Y=Yes, N=None, U=Unknown,
E=Exposed other than age <20,
F=Unknown exposure in other
settings/time period');
INSERT INTO "topic" VALUES('Secondhand smoke','Q2','SECONDHAND SMOKE','adexp','Any age >=20 exposure across any setting. Derived
variable for secondhand smoke section. Added
07052018','Y=Yes, N=None, U=Unknown,
E=Exposed other than age >=20,
F=Unknown exposure in other
settings/time period');
INSERT INTO "topic" VALUES('Secondhand smoke','Q2','SECONDHAND SMOKE','chhous','Any household age <20 exposure. Derived variable
for secondhand smoke section. Added 07052018','Y=Yes, N=None, U=Unknown household
age <20 exposure, E=Exposed other
than household age <20, F=Unknown
exposure in other settings/time period');
INSERT INTO "topic" VALUES('Secondhand smoke','Q2','SECONDHAND SMOKE','adhous','Any household age >=20. Derived variable for
secondhand smoke section. Added 07052018','Y=Yes, N=None, U=Unknown household
age >=20 exposure, E=Exposed other
than household age >=20, F=Unknown
exposure in other settings/time period');
INSERT INTO "topic" VALUES('Secondhand smoke','Q2','SECONDHAND SMOKE','chwork','Any workplace age <20 exposure. Derived variable
for secondhand smoke section. Added 07052018','Y=Yes, N=None, U=Unknown workplace
age <20 exposure, E=Exposed other
than workplace age <20, F=Unknown
exposure in other settings/time period');
INSERT INTO "topic" VALUES('Secondhand smoke','Q2','SECONDHAND SMOKE','adwork','Any workplace age >=20 exposure. Derived variable
for secondhand smoke section. Added 07052018','Y=Yes, N=None, U=Unknown workplace
age >=20 exposure, E=Exposed other
than workplace age >=20, F=Unknown
exposure in other settings/time period');
INSERT INTO "topic" VALUES('Secondhand smoke','Q2','SECONDHAND SMOKE','chothr','Any social setting age <20 exposure. Derived
variable for secondhand smoke section. Added
07052018','Y=Yes, N=None, U=Unknown social
setting age <20 exposure, E=Exposed
other than social setting age <20,
F=Unknown exposure in other
settings/time period');
INSERT INTO "topic" VALUES('Secondhand smoke','Q2','SECONDHAND SMOKE','adothr','Any social setting age >=20 exposure. Derived
variable for secondhand smoke section. Added
07052018','Y=Yes, N=None, U=Unknown social
setting age >=20 exposure, E=Exposed
other than social setting age >=20,
F=Unknown exposure in other
settings/time period');
INSERT INTO "topic" VALUES('Secondhand smoke','Q2','SECONDHAND SMOKE','anyexp','Any lifetime exposure across any setting (home,
work, social) and time period (age<20 and age
>=20). Derived variable for secondhand smoke
section. Added 07052018','Y=Yes, N=None, U=Unknown');
INSERT INTO "topic" VALUES('Secondhand smoke','Q2','SECONDHAND SMOKE','anyhous','Any household lifetime exposure. Derived variable
for secondhand smoke section. Added 07052018','Y=Yes, N=None, E=Exposed in setting
other than household, F=Unknown
exposure in other settings, U=Unknown
household exposure');
INSERT INTO "topic" VALUES('Secondhand smoke','Q2','SECONDHAND SMOKE','anywork','Any workplace lifetime exposure. Derived variable for
secondhand smoke section. Added 07052018','Y=Yes, N=None, E=Exposed in setting
other than workplace, F=Unknown
exposure in other settings, U=Unknown
workplace exposure');
INSERT INTO "topic" VALUES('Secondhand smoke','Q2','SECONDHAND SMOKE','anyothr','Any social lifetime exposure. Derived variable for
secondhand smoke section. Added 07052018','Y=Yes, N=None, E=Exposued in setting
other than social setting, F=Unknown
exposure in other settings, U=Unknown
household exposure');
INSERT INTO "topic" VALUES('Secondhand smoke','Q2','SECONDHAND SMOKE','anyyrs','Cumulative lifetime years exposure. Derived variable
for secondhand smoke section. Added 07052018','0.5-204, 0=None, .=missing/unknown');
INSERT INTO "topic" VALUES('Secondhand smoke','Q2','SECONDHAND SMOKE','adyrs','Cumulative age >=20 across settings years
exposure. Derived variable for secondhand smoke
section. Added 07052018','0.5-163.5, 0=None,
.=missing/unknown at age >=20');
INSERT INTO "topic" VALUES('Secondhand smoke','Q2','SECONDHAND SMOKE','chyrs','Cumulative age <20 across settings years exposure.
Derived variable for secondhand smoke section.
Added 07052018','3.0-52.5, 0=None,
.=missing/unknown at age <20');
INSERT INTO "topic" VALUES('Secondhand smoke','Q2','SECONDHAND SMOKE','anysev','Cumulative lifetime intensity-years exposure. Derived
variable for secondhand smoke section. Added
07052018','0.5-604.5, 0=None,
.=missing/unknown');
INSERT INTO "topic" VALUES('Secondhand smoke','Q2','SECONDHAND SMOKE','adsev','Cumulative age >=20 intensity-years exposure.
Derived variable for secondhand smoke section.
Added 07052018','0.5-490.5, 0=None,
.=missing/unknown at age >=20');
INSERT INTO "topic" VALUES('Secondhand smoke','Q2','SECONDHAND SMOKE','chsev','Cumulative age <20 intensity-years exposure.
Derived variable for secondhand smoke section.
Added 07052018','3.0-157.5, 0=None,
.=missing/unknown at age <20');
INSERT INTO "topic" VALUES('Secondhand smoke','Q2','SECONDHAND SMOKE','anyintsum','Cumulative lifetime intensity exposure. Derived
variable for secondhand smoke section. Added
07052018','1.0-9.0, 0=None, .=missing/unknown');
INSERT INTO "topic" VALUES('Secondhand smoke','Q2','SECONDHAND SMOKE','adintsum','Cumulative age >=20 intensity-years exposure.
Derived variable for secondhand smoke section.
Added 07052018','1.0-9.0, 0=None, .=missing/unknown
at age >=20');
INSERT INTO "topic" VALUES('Secondhand smoke','Q2','SECONDHAND SMOKE','chintsum','Cumulative age <20 intensity exposure. Derived
variable for secondhand smoke section. Added
07052018','1.0-9.0, 0=None, .=missing/unknown
at age <20');
INSERT INTO "topic" VALUES('Secondhand smoke','Q4','SMOKING & PREGNANCY','SPNOSMBX','Q46 GENERATED VARIABLE FOR No-one smoked around me before pregnancy','Y=Yes, U=Wrong page #12, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Secondhand smoke','Q4','SMOKING & PREGNANCY','SPNOSMDX','Q46 GENERATED VARIABLE FOR No-one smoked around me during pregnancy','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Secondhand smoke','Q4','SMOKING & PREGNANCY','SPHOMEBX','Q46 GENERATED VARIABLE FOR Others at home smoked before pregnancy','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Secondhand smoke','Q4','SMOKING & PREGNANCY','SPHOMEDX','Q46 GENERATED VARIABLE FOR Others at home smoked during pregnancy','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Secondhand smoke','Q4','SMOKING & PREGNANCY','SPWORKBX','Q46 GENERATED VARIABLE FOR Others at work smoked before pregnancy','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Secondhand smoke','Q4','SMOKING & PREGNANCY','SPWORKDX','Q46 GENERATED VARIABLE FOR Others at work smoked during pregnancy','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Secondhand smoke','Q4','SMOKING & PREGNANCY','SPOTHRBX','Q46 GENERATED VARIABLE FOR Others smoked around me before pregnancy','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Secondhand smoke','Q4','SMOKING & PREGNANCY','SPOTHRDX','Q46 GENERATED VARIABLE FOR Others smoked around me during pregnancy','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Secondhand smoke','Q4','SMOKING & PREGNANCY','SBNOSMBX','Q46 GENERATED VARIABLE FOR No-one smoked before live birth','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Secondhand smoke','Q4','SMOKING & PREGNANCY','SBNOSMDX','Q46 GENERATED VARIABLE FOR No-one smoked during live birth','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Secondhand smoke','Q4','SMOKING & PREGNANCY','SBHOMEBX','Q46 GENERATED VARIABLE FOR Others at home smoked before live birth','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Secondhand smoke','Q4','SMOKING & PREGNANCY','SBHOMEDX','Q46 GENERATED VARIABLE FOR Others at home smoked during live birth','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Secondhand smoke','Q4','SMOKING & PREGNANCY','SBWORKBX','Q46 GENERATED VARIABLE FOR Others at work smoked before live birth','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Secondhand smoke','Q4','SMOKING & PREGNANCY','SBWORKDX','Q46 GENERATED VARIABLE FOR Others at work smoked during live birth','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Secondhand smoke','Q4','SMOKING & PREGNANCY','SBOTHRBX','Q46 GENERATED VARIABLE FOR Others smoked around me before live birth','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Secondhand smoke','Q4','SMOKING & PREGNANCY','SBOTHRDX','Q46 GENERATED VARIABLE FOR Others smoked around me during live birth','Y=Yes, V=Questionnaire section blank');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','EMPRET','Q2 Currently retired?','Y');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','EMPUN','Q2 Currently unemployed?','Y');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','EMPHOM','Q2 Currently homemaker?','Y');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','EMPDIS','Q2 Currently disabled?','Y');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','EMPFTT','Q2 Currently full time teaching?','Y');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','EMPPTT','Q2 Currently part time teaching?','Y');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','EMPFTO','Q2 Currently full time other school job?','Y');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','EMPPTO','Q2 Currently part time other school job?','Y');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','EMPFTE','Q2 Currently full time employmt not school?','Y');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','EMPPTE','Q2 Currently part time employmt not school?','Y');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','EMPSE','Q2 Currently self employed?','Y');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','LASTJOB','Q4 Number of years since last worked?','A=2yr or less, B=3-5, C=6-10, D=11-15, E=16+, Z=Unk');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','JOB1','Q5 Learn new things in current job?','A=Strongly disagree, B=Disagree, C=Agree, D=Strongly agree, Z=Unk');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','JOB2','Q5 Repetitive work in current job?','A=Strongly disagree, B=Disagree, C=Agree, D=Strongly agree, Z=Unk');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','JOB3','Q5 Creative in current job?','A=Strongly disagree, B=Disagree, C=Agree, D=Strongly agree, Z=Unk');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','JOB4','Q5 Make a lot of decisions in current job?','A=Strongly disagree, B=Disagree, C=Agree, D=Strongly agree, Z=Unk');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','JOB5','Q5 High level of skill in current job?','A=Strongly disagree, B=Disagree, C=Agree, D=Strongly agree, Z=Unk');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','JOB6','Q5 Little freedom in current job?','A=Strongly disagree, B=Disagree, C=Agree, D=Strongly agree, Z=Unk');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','JOB7','Q5 Do a variety of things in current job?','A=Strongly disagree, B=Disagree, C=Agree, D=Strongly agree, Z=Unk');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','JOB8','Q5 A lot of say in current job?','A=Strongly disagree, B=Disagree, C=Agree, D=Strongly agree, Z=Unk');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','JOB9','Q5 Opportunity to develop in current job?','A=Strongly disagree, B=Disagree, C=Agree, D=Strongly agree, Z=Unk');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','JOB10','Q5 Work fast in current job?','A=Strongly disagree, B=Disagree, C=Agree, D=Strongly agree, Z=Unk');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','JOB11','Q5 Work hard in current job?','A=Strongly disagree, B=Disagree, C=Agree, D=Strongly agree, Z=Unk');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','JOB12','Q5 Physical effort in current job?','A=Strongly disagree, B=Disagree, C=Agree, D=Strongly agree, Z=Unk');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','JOB13','Q5 Not excessive work in current job?','A=Strongly disagree, B=Disagree, C=Agree, D=Strongly agree, Z=Unk');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','JOB14','Q5 Enough time in current job?','A=Strongly disagree, B=Disagree, C=Agree, D=Strongly agree, Z=Unk');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','JOB15','Q5 Good job security in current job?','A=Strongly disagree, B=Disagree, C=Agree, D=Strongly agree, Z=Unk');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','JOB16','Q5 Feel safe in current job?','A=Strongly disagree, B=Disagree, C=Agree, D=Strongly agree, Z=Unk');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','JOB17','Q5 Free of conflicting demands?','A=Strongly disagree, B=Disagree, C=Agree, D=Strongly agree, Z=Unk');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','JOB18','Q5 Competent people in current job?','A=Strongly disagree, B=Disagree, C=Agree, D=Strongly agree, Z=Unk');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','JOB19','Q5 People take an interest in me in job?','A=Strongly disagree, B=Disagree, C=Agree, D=Strongly agree, Z=Unk');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','JOB20','Q5 Friendly people in current job?','A=Strongly disagree, B=Disagree, C=Agree, D=Strongly agree, Z=Unk');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','JOB21','Q5 Helpful people in current job?','A=Strongly disagree, B=Disagree, C=Agree, D=Strongly agree, Z=Unk');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','JOB22','Q5 Current supervisor concerned for staff?','A=Strongly disagree, B=Disagree, C=Agree, D=Strongly agree, E=N/A or DK');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','JOB23','Q5 Current supervisor pays attention?','A=Strongly disagree, B=Disagree, C=Agree, D=Strongly agree, E=N/A or DK');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','JOB24','Q5 Current supervisor helpful?','A=Strongly disagree, B=Disagree, C=Agree, D=Strongly agree, E=N/A or DK');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','JOB25','Q5 Current supervisor gets people together?','A=Strongly disagree, B=Disagree, C=Agree, D=Strongly agree, E=N/A or DK');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','JABSENT','Q6 Times ill from work in last year','A=Not working, B=No time, C=A few days, D=About a week, E=A few weeks, F=A month or more, Z=Unk');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','SOCREL','Q7 Number close relatives','A=0, B=1-2, C=3-5, D=6-9, E=10+, Z=Unk');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','SOCFRD','Q7 Number close friends','A=0, B=1-2, C=3-5, D=6-9, E=10+, Z=Unk');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','SOCSEE','Q7 Number social contacts see once a month','A=0, B=1-2, C=3-5, D=6-9, E=10+, Z=Unk');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','SOCTALK','Q7 Number contacts talk to once a month','A=0, B=1-2, C=3-5, D=6-9, E=10+, Z=Unk');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','SOCGOD','Q7 Times participate in religious groups','A=0, B=1-2, C=3-5, D=6-9, E=10+, Z=Unk');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','SOCGRP','Q7 Times participate in other groups','A=0, B=1-2, C=3-5, D=6-9, E=10+, Z=Unk');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','NUMHH','Q7 People in household (excl. self)','A=0, B=1-2, C=3-5, D=6-9, E=10+, Z=Unk');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','NUMKIDHH','Q7 Children 17 or younger in household','A=0, B=1-2, C=3-5, D=6-9, E=10+, Z=Unk');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','q3_marital_status','Q8 Current marital status','A=Married/living with partner
B=Divorced
C=Separated
D=Widowed
E=Never married
-88=Unable to assign value
-99=Missing');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','CARE1','Q9 How much partner care about you?','A=A lot, B=Some, C=A Little, D=Not at all, E=N/A, Z=Unk');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','CARE2','Q9 How much family care about you?','A=A lot, B=Some, C=A Little, D=Not at all, E=N/A, Z=Unk');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','CARE3','Q9 How much friends care about you?','A=A lot, B=Some, C=A Little, D=Not at all, E=N/A, Z=Unk');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','UNSTND1','Q9 How much partner understand you?','A=A lot, B=Some, C=A Little, D=Not at all, E=N/A, Z=Unk');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','UNSTND2','Q9 How much family understand you?','A=A lot, B=Some, C=A Little, D=Not at all, E=N/A, Z=Unk');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','UNSTND3','Q9 How much friends understand you?','A=A lot, B=Some, C=A Little, D=Not at all, E=N/A, Z=Unk');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','RELY1','Q9 How much can rely on partner for help?','A=A lot, B=Some, C=A Little, D=Not at all, E=N/A, Z=Unk');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','RELY2','Q9 How much can rely on family for help?','A=A lot, B=Some, C=A Little, D=Not at all, E=N/A, Z=Unk');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','RELY3','Q9 How much can rely on friends for help?','A=A lot, B=Some, C=A Little, D=Not at all, E=N/A, Z=Unk');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','OPEN1','Q9 How much can you open up to partner?','A=A lot, B=Some, C=A Little, D=Not at all, E=N/A, Z=Unk');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','OPEN2','Q9 How much can you open up to family?','A=A lot, B=Some, C=A Little, D=Not at all, E=N/A, Z=Unk');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','OPEN3','Q9 How much can you open up to friends?','A=A lot, B=Some, C=A Little, D=Not at all, E=N/A, Z=Unk');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','DEMD1','Q9 How often partner make demands on you?','A=A lot, B=Some, C=A Little, D=Not at all, E=N/A, Z=Unk');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','DEMD2','Q9 How often family make demands on you?','A=A lot, B=Some, C=A Little, D=Not at all, E=N/A, Z=Unk');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','DEMD3','Q9 How often friends make demands on you?','A=A lot, B=Some, C=A Little, D=Not at all, E=N/A, Z=Unk');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','CRIT1','Q9 How often does partner criticize you?','A=A lot, B=Some, C=A Little, D=Not at all, E=N/A, Z=Unk');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','CRIT2','Q9 How often does family criticize you?','A=A lot, B=Some, C=A Little, D=Not at all, E=N/A, Z=Unk');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','CRIT3','Q9 How often do friends criticize you?','A=A lot, B=Some, C=A Little, D=Not at all, E=N/A, Z=Unk');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','LTDWN1','Q9 How often does partner let you down?','A=A lot, B=Some, C=A Little, D=Not at all, E=N/A, Z=Unk');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','LTDWN2','Q9 How often does family let you down?','A=A lot, B=Some, C=A Little, D=Not at all, E=N/A, Z=Unk');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','LTDWN3','Q9 How often do friends let you down?','A=A lot, B=Some, C=A Little, D=Not at all, E=N/A, Z=Unk');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','ANNOY1','Q9 How often partner get on your nerves?','A=A lot, B=Some, C=A Little, D=Not at all, E=N/A, Z=Unk');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','ANNOY2','Q9 How often family get on your nerves?','A=A lot, B=Some, C=A Little, D=Not at all, E=N/A, Z=Unk');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','ANNOY3','Q9 How often friends get on your nerves?','A=A lot, B=Some, C=A Little, D=Not at all, E=N/A, Z=Unk');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','FEEL1','Q10 How often feel on top of the world?','A=Often, B=Sometimes, C=Rarely, D=Never, X=Problem');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','FEEL2','Q10 How often feel very unhappy?','A=Often, B=Sometimes, C=Rarely, D=Never, X=Problem');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','FEEL3','Q10 How often do you feel bored?','A=Often, B=Sometimes, C=Rarely, D=Never, X=Problem');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','FEEL4','Q10 How often do you feel excited?','A=Often, B=Sometimes, C=Rarely, D=Never, X=Problem');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','FEEL5','Q10 How often feel hard to be close?','A=Often, B=Sometimes, C=Rarely, D=Never, X=Problem');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','FEEL6','Q10 How often do you feel restless?','A=Often, B=Sometimes, C=Rarely, D=Never, X=Problem');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','FEEL7','Q10 How often do you feel left out?','A=Often, B=Sometimes, C=Rarely, D=Never, X=Problem');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','FEEL8','Q10 How often feel upset when criticized?','A=Often, B=Sometimes, C=Rarely, D=Never, X=Problem');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','FEEL9','Q10 How often do you feel very lonely?','A=Often, B=Sometimes, C=Rarely, D=Never, X=Problem');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','FEEL10','Q10 How often feel proud when complimented?','A=Often, B=Sometimes, C=Rarely, D=Never, X=Problem');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','FEEL11','Q10 How often feel keep people at distance?','A=Often, B=Sometimes, C=Rarely, D=Never, X=Problem');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','FEEL12','Q10 How often feel things going my way?','A=Often, B=Sometimes, C=Rarely, D=Never, X=Problem');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','FEEL13','Q10 How often pleased for accomplishment?','A=Often, B=Sometimes, C=Rarely, D=Never, X=Problem');
INSERT INTO "topic" VALUES('Happiness and social support','Q3','STRESS AND SOCIAL SUPPORT','HAPPY','Q11 How happy are you these days?','A=Very happy, B=Somewhat happy, C=Not very happy, Z=Unk');
INSERT INTO "topic" VALUES('Happiness and social support','Q5','HEALTH','Q32a','Q32 How often do you feel that you lack companionship? ','* 1=Hardly ever/never, 2=Some of the time, 3=Often');
INSERT INTO "topic" VALUES('Happiness and social support','Q5','HEALTH','Q32b','Q32 How often do you feel left out?','* 1=Hardly ever/never, 2=Some of the time, 3=Often');
INSERT INTO "topic" VALUES('Happiness and social support','Q5','HEALTH','Q32c','Q32 How often do you feel isolated from others?','* 1=Hardly ever/never, 2=Some of the time, 3=Often');
INSERT INTO "topic" VALUES('Happiness and social support','Q6','HAPPINESS','Q6Web_happiness','Overall happiness','-88 = Unable to assign value
0 = Skipped
1 = Very happy
2 = Somewhat happy
3 = Not very happy');
INSERT INTO "topic" VALUES('Happiness and social support','Q6','SOCIAL CONNECTION','Q6Web_lack_companionship','How often participant feels that she lacks companionship ','-88 = Unable to assign value
0 = Skipped
1 = Hardly ever or never
2 = Some of the time
3 = Often');
INSERT INTO "topic" VALUES('Happiness and social support','Q6','SOCIAL CONNECTION','Q6Web_feel_left_out','How often participant feels left out','-88 = Unable to assign value
0 = Skipped
1 = Hardly ever or never
2 = Some of the time
3 = Often');
INSERT INTO "topic" VALUES('Happiness and social support','Q6','SOCIAL CONNECTION','Q6Web_feel_isolated','How often participant feels isolated from others','-88 = Unable to assign value
0 = Skipped
1 = Hardly ever or never
2 = Some of the time
3 = Often');
INSERT INTO "topic" VALUES('Cognitive status','Q3','DRAWING AND WRITING','LRHAND','Q27 Write with left or right hand?','A=Right, B=Left, *=Prob');
INSERT INTO "topic" VALUES('Sleep habits','Q5','SLEEP HABITS','Q5','Q5 During the past month, how would you rate your sleep quality overall?','1=Very good, 2=Fairly good, 3=Fairly bad, 4=Very bad');
INSERT INTO "topic" VALUES('Sleep habits','Q5','SLEEP HABITS','Q6','Q6 During the past month, on average how long has it usually taken you to fall asleep each night?','1=<15 minutes, 2=16-30, 3=31-60, 4=>60');
INSERT INTO "topic" VALUES('Sleep habits','Q5','SLEEP HABITS','Q7','Q7 During the past month, on average how many hours of actual sleep did you get each night?','1=<5 hours, 2=5-6, 3=7, 4=8, 5=9+');
INSERT INTO "topic" VALUES('Sleep habits','Q5','SLEEP HABITS','Q8','Q8 During the past month, on average how often have you had trouble sleeping because you either couldn’t fall asleep within a half hour or woke up in the middle of the night or early morning and had difﬁculty falling back to sleep?','0=Not during past month, 1=<1 time/week, 2=1-2 time/week, 3=3+ times/week');
INSERT INTO "topic" VALUES('Sleep habits','Q5','SLEEP HABITS','Q9a','Q9 Are the sleep habits you reported in questions 5-8 typical of your sleep habits  in general over the last year?','1=Yes, 0=No');
INSERT INTO "topic" VALUES('Sleep habits','Q5','SLEEP HABITS','Q9b','Q9 Are the sleep habits you reported in questions 5-8 typical of your sleep habits  in general 2-5 years ago?','1=Yes, 0=No');
INSERT INTO "topic" VALUES('Sleep habits','Q5','SLEEP HABITS','Q9c','Q9 Are the sleep habits you reported in questions 5-8 typical of your sleep habits  in general 6-10 years ago?','1=Yes, 0=No');
INSERT INTO "topic" VALUES('Sleep habits','Q5','SLEEP HABITS','Q9d','Q9 Are the sleep habits you reported in questions 5-8 typical of your sleep habits  in general 11 or more years ago?','1=Yes, 0=No');
INSERT INTO "topic" VALUES('Sleep habits','Q5','SLEEP HABITS','Q10','Q10 During the past month, on average how often have you taken medicine (prescribed or “over the counter”)to help you sleep (such as Tylenol PM, melatonin,Sleep-Ez,Ambien, or Lunesta)?','0=Not during past month, 1=<1 time/week, 2=1-2 time/week, 3=3+ times/week');
INSERT INTO "topic" VALUES('Sleep habits','Q5','SLEEP HABITS','Q11a','Q11 One hears about “morning” and “evening” types of people. Which of these types did you consider yourself to be in your teens/in college?','1=Morning type, 2=More morning than evening type, 3=Neither morning/evening type, 4=More evening than morning type, 5=Evening type');
INSERT INTO "topic" VALUES('Sleep habits','Q5','SLEEP HABITS','Q11b','Q11 One hears about “morning” and “evening” types of people. Which of these types did you consider yourself to be in your 30''s-40''s?','1=Morning type, 2=More morning than evening type, 3=Neither morning/evening type, 4=More evening than morning type, 5=Evening type');
INSERT INTO "topic" VALUES('Sleep habits','Q5','SLEEP HABITS','Q11c','Q11 One hears about “morning” and “evening” types of people. Which of these types did you consider yourself to be now?','1=Morning type, 2=More morning than evening type, 3=Neither morning/evening type, 4=More evening than morning type, 5=Evening type');
INSERT INTO "topic" VALUES('Sleep habits','Q6','SLEEP HABITS','Q6Web_snores','Does participant snore','-88 = Unable to assign value
0 = Skipped
1 = Yes
2 = No');
INSERT INTO "topic" VALUES('Sleep habits','Q6','SLEEP HABITS','Q6Web_fatigued_day','Participant feels tired, fatigued, or sleepy during daytime','-88 = Unable to assign value
0 = Skipped
1 = Yes
2 = No');
INSERT INTO "topic" VALUES('Sleep habits','Q6','SLEEP HABITS','Q6Web_stop_breath_night','Someone has observed participant stop breathing during sleep','-88 = Unable to assign value
0 = Skipped
1 = Yes
2 = No');
INSERT INTO "topic" VALUES('Sleep habits','Q6','SLEEP HABITS','Q6Web_difficult_fall_asleep','Participant has had difficulty falling asleep, staying asleep or waking up too early in past 2 weeks','-88 = Unable to assign value
0 = Skipped
1 = Yes
2 = No');
INSERT INTO "topic" VALUES('Sleep habits','Q6','SLEEP HABITS','Q6Web_severe_diff_fall_asleep','Rate the severity: difficulty falling asleep ','-88 = Unable to assign value
0 = Skipped
1 = None
2 = Mild
3 = Moderate
4 = Severe
5 = Extreme');
INSERT INTO "topic" VALUES('Sleep habits','Q6','SLEEP HABITS','Q6Web_severe_diff_stay_asleep','Rate the severity: difficulty staying asleep ','-88 = Unable to assign value
0 = Skipped
1 = None
2 = Mild
3 = Moderate
4 = Severe
5 = Extreme');
INSERT INTO "topic" VALUES('Sleep habits','Q6','SLEEP HABITS','Q6Web_wake_too_early','Rate the severity: problem waking up too early ','-88 = Unable to assign value
0 = Skipped
1 = None
2 = Mild
3 = Moderate
4 = Severe
5 = Extreme');
INSERT INTO "topic" VALUES('Sleep habits','Q6','SLEEP HABITS','Q6Web_satisfied_sleep_pattern','How satisfied/dissatisfied is participant with her current sleep pattern','-88 = Unable to assign value
0 = Skipped
1 = Very satisfied
2 = Satisfied
3 = Moderately satisfied
4 = Dissatisfied 
5 = Very dissatisfied ');
INSERT INTO "topic" VALUES('Sleep habits','Q6','SLEEP HABITS','Q6Web_sleep_interfere_day_life','Sleep problem interferes with participant''s daily functioning ','-88 = Unable to assign value
0 = Skipped
1 = Not at all interfering
2 = A little interfering
3 = Somewhat interfering
4 = Much interfering
5 = Very much interfering');
INSERT INTO "topic" VALUES('Sleep habits','Q6','SLEEP HABITS','Q6Web_noticeable_sleep_problem','How noticeable is sleep problem','-88 = Unable to assign value
0 = Skipped
1 = Not at all noticeable 
2 = A little noticeable 
3 = Somewhat noticeable 
4 = Much noticeable 
5 = Very much noticeable');
INSERT INTO "topic" VALUES('Sleep habits','Q6','SLEEP HABITS','Q6Web_worry_abt_sleep_problem','How worried/distressed is participant about sleep problem','-88 = Unable to assign value
0 = Skipped
1 = Not at all worried
2 = A little 
3 = Somewhat 
4 = Much 
5 = Very much worried ');
INSERT INTO "topic" VALUES('Sleep habits','Q6','SLEEP HABITS','Q6Web_chronic_sleep_problem','Participant has had sleep problems at least 3 times a week for over a month','-88 = Unable to assign value
0 = Skipped
1 = Yes
2 = No');
INSERT INTO "topic" VALUES('Medicinal cannabis','Q6','MEDICINAL CANNABIS','Q6Web_ever_used_med_cannabis','Has participant ever used cannabis for medical purposes','-88 = Unable to assign value
0 = Skipped
1 = Yes 
2 = No 
3 = Prefer not to answer');
INSERT INTO "topic" VALUES('Medicinal cannabis','Q6','MEDICINAL CANNABIS','Q6Web_medical_cannabis_method','How participant consumed cannabis the last time she used for medicinal purposes','-88 = Unable to assign value
0 = Skipped
1 = Smoking
2 = Vaporizing 
3 = Eating 
4 = Drinking
5 = Other
6 = Prefer not to answer
7 = Cream');
INSERT INTO "topic" VALUES('Medicinal cannabis','Q6','MEDICINAL CANNABIS','Q6Web_cannabis_reason_anxiety','Used medicinal cannabis to relieve anxiety or panic','-88 = Unable to assign value
0 = Skipped
1 = Yes 
2 = No 
3 = Prefer not to answer');
INSERT INTO "topic" VALUES('Medicinal cannabis','Q6','MEDICINAL CANNABIS','Q6Web_cannabis_reason_pain','Used medicinal cannabis to relieve pain','-88 = Unable to assign value
0 = Skipped
1 = Yes 
2 = No 
3 = Prefer not to answer');
INSERT INTO "topic" VALUES('Medicinal cannabis','Q6','MEDICINAL CANNABIS','Q6Web_cannabis_reason_sleep','Used medicinal cannabis to improve sleep','-88 = Unable to assign value
0 = Skipped
1 = Yes 
2 = No 
3 = Prefer not to answer');
INSERT INTO "topic" VALUES('Medicinal cannabis','Q6','MEDICINAL CANNABIS','Q6Web_cannabis_reason_relax','Used medicinal cannabis to relax','-88 = Unable to assign value
0 = Skipped
1 = Yes 
2 = No 
3 = Prefer not to answer');
INSERT INTO "topic" VALUES('Medicinal cannabis','Q6','MEDICINAL CANNABIS','Q6Web_cannabis_reason_other','Used medicinal cannabis for another reason','-88 = Unable to assign value
0 = Skipped
1 = Yes 
2 = No 
3 = Prefer not to answer');
INSERT INTO "topic" VALUES('Medicinal cannabis','Q6','MEDICINAL CANNABIS','Q6Web_medi_cannabis_as_Rx_med','Ever used medicinal cannabis as substitute for prescription medication','-88 = Unable to assign value
0 = Skipped
1 = Yes
2 = No
3 = Prefer not to answer');
INSERT INTO "topic" VALUES('Financial stress','Q6','FINANCIAL STRESS','Q6Web_worry_retirement_money','How worried is participant about not having enough money for retirement ','-88 = Unable to assign value
0 = Skipped
1 = Very worried
2 = Moderately worried
3 = Not too worried
4 = Not worried at all
5 = Prefer not to answer
6 = Don''t know');
INSERT INTO "topic" VALUES('Financial stress','Q6','FINANCIAL STRESS','Q6Web_worry_serious_ill_cost','How worried is participant about not being able to pay medical costs of a serious illness or accident','-88 = Unable to assign value
0 = Skipped
1 = Very worried
2 = Moderately worried
3 = Not too worried
4 = Not worried at all
5 = Prefer not to answer
6 = Don''t know');
INSERT INTO "topic" VALUES('Financial stress','Q6','FINANCIAL STRESS','Q6Web_unpaid_medbills_past_yr','In the past 12 months, did participant or anyone in household have problems paying or were unable to pay any medical bills. Includes bills for doctors, dentists, hospitals, therapists, medication, equipment, nursing home or home care.','-88 = Unable to assign value
0 = Skipped
1 = Yes 
2 = No
3 = Prefer not to answer
4 = Don''t know');
INSERT INTO "topic" VALUES('Financial stress','Q6','FINANCIAL STRESS','Q6Web_pay_medbills_over_time','Does participant or anyone in household currently have any medical bills that are being paid off over time. This could include medical bills being paid off with a credit card, through personal loans, or bill paying arrangements with hospitals or other providers. The bills can be from earlier years as well as this year.','-88 = Unable to assign value
0 = Skipped
1 = Yes 
2 = No
3 = Prefer not to answer
4 = Don''t know');
INSERT INTO "topic" VALUES('Financial stress','Q6','FINANCIAL STRESS','Q6Web_unable_pay_medical_bills','Does participant or does anyone in household currently have any medical bills that they are unable to pay at all','-88 = Unable to assign value
0 = Skipped
1 = Yes 
2 = No
3 = Prefer not to answer
4 = Don''t know');
COMMIT;
