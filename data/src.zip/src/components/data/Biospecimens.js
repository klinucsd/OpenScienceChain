import React from 'react';
import 'antd/dist/antd.css';
import './index.css';
import './cancer_endpoint.css';
import Typography from '@material-ui/core/Typography/index';
import {Card, Input, Button, Modal} from 'antd';
import { EditOutlined, ReloadOutlined  } from '@ant-design/icons';

import {Typography as AntTypography} from 'antd';
import axios from "axios";

const {Text} = AntTypography;

const {TextArea} = Input;

const root_style = {
    width: '100%',
}

class Biospecimens extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            biospecimen: null,
            biospecimen_form_url: null
        }
    }

    componentDidMount() {
        if (this.props.project && this.props.project.biospecimen_info) {
            let biospecimen_info = JSON.parse(this.props.project.biospecimen_info);
            let biospecimen_form_url = this.props.project.biospecimen_form_url;
            if (biospecimen_info) {
                this.setState({
                    biospecimen: biospecimen_info.biospecimen,
                    biospecimen_form_url
                })
            }
        }
    }

    static getTitle = () => {
        return 'Enter biospecimen information';
    }

    static isComplete = (state) => {
        return state.biospecimen_info !== undefined &&
            state.biospecimen_info !== null &&
            state.biospecimen_info.biospecimen !== null &&
            state.biospecimen_info.biospecimen !== undefined &&
            state.biospecimen_info.biospecimen.trim().length !== 0;
    }

    static getSummary = (project, index) => {
        return (
            <Card key={'module-' + index}
                  size="small"
                  title={'Biospecimen Information'}
                  headStyle={{backgroundColor: 'rgb(216, 236, 243)'}}
                  style={{width: '100%', margin: index > 0 ? '20pt 0pt 0pt 0pt' : '0pt'}}>

		  <div style={{ margin: '10pt 20pt 10pt 20pt'}}>
                    <div dangerouslySetInnerHTML={{
                        __html: (
                            project.biospecimen_info === undefined ||
                            project.biospecimen_info === null ||
                            JSON.parse(project.biospecimen_info).biospecimen === null ||
                            JSON.parse(project.biospecimen_info).biospecimen === undefined ||
                            JSON.parse(project.biospecimen_info).biospecimen.trim().length === 0 ?
                                '<div style="padding: 10pt; color: brown;">No biospecimen information available.</div>'
                                :
                                JSON.parse(project.biospecimen_info).biospecimen
                        )
                    }}>
                    </div>
                </div>
            </Card>
        )
    }

    reset = () => {
        this.setState({
            biospecimen: null,
        });
    }

    onChangeBiospecimen = (e) => {
        this.setState({
            biospecimen: e.target.value,
        }, this.saveBiospecimenInformation);
    }

    saveBiospecimenInformation = () => {
        let obj = {
            biospecimen: this.state.biospecimen,
        }
        this.props.save_biospecimen_info(obj);
    }

    reloadBiospecimenFromSalesforce = () => {
        let info = Modal.info(
            {
                title: 'Refresh Biospecimen Summary',
                content: ` Please wait for reloading the biospecimen summary from Salesforce.`
            });
        let theState = this;
        axios({
            url: `/api/load_biospecimen_from_salesforce/${this.props.project.project_number}/`,
            method: 'GET'
        }).then((response) => {
            theState.props.save_biospecimen_info({
                biospecimen: response.data.info
            });
            info.destroy();
            Modal.success(
                {
                    title: 'Refresh Done',
                    content: `Reloading the biospecimen summary from Salesforce was completed.`
                });
        }).catch( (error) => {
            console.error(error) ;
        });

    }

    render() {
        return (
            <div style={root_style}>
                <Typography style={{padding: '10pt 10pt 0pt 10pt', width: '100%'}}>
                    This is the biospecimen information you provided.
                    If you have any edits, click the Edit button below
                    and a new tab will open. You may be prompted to log in.
                    Make your changes in that tab, save them, then
                    click Refresh to continue.
                </Typography>

                <div style={{
                    margin: '10pt 60pt 10pt 20pt',
                    padding: '10pt 80pt 30pt 30pt',
                    borderRadius: '25px',
                    border: '1px solid lightgray',
                    position: 'relative'
                }}

                >
                    <div dangerouslySetInnerHTML={{
                        __html: (
                            this.state.biospecimen ?
                                this.state.biospecimen :
                                '<div style="padding: 10pt; color: brown;">No biospecimen information available.</div>')
                    }}>
                    </div>
                    <div style={{position: 'absolute', bottom:10, right:30}}>
                        <Button icon={<EditOutlined />}
                                onClick={() => window.open(
                                    this.state.biospecimen_form_url, "_edit_case"
                                )}>
                            Edit
                        </Button>
                        <Button icon={<ReloadOutlined />}
                                style={{marginLeft: '6pt'}}
                                onClick={this.reloadBiospecimenFromSalesforce}
                        >
                            Refresh
                        </Button>
                    </div>

                    {/*
                    <TextArea rows={6}
                              value={this.state.biospecimen}
                              onChange={this.onChangeBiospecimen}
                              allowClear/>
                     */}
                </div>

            </div>
        );
    }

}

export default Biospecimens;
