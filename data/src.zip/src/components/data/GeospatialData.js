import React from 'react';
import 'antd/dist/antd.css';
import './index.css';
import './cancer_endpoint.css';
import Typography from '@material-ui/core/Typography/index';
import {Card, Input, Button, Modal} from 'antd';
import { EditOutlined, ReloadOutlined  } from '@ant-design/icons';
import {Typography as AntTypography} from 'antd';
import axios from "axios";

const {Text} = AntTypography;
const {TextArea} = Input;

const root_style = {
    width: '100%',
}

class GeospatialData extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            geospatial_data: null,
            geospatial_form_url: null,
        }
    }

    componentDidMount() {
        if (this.props.project && this.props.project.geospatial_info) {
            let geospatial_info = JSON.parse(this.props.project.geospatial_info);
            let geospatial_form_url = this.props.project.geospatial_form_url;
            if (geospatial_info) {
                this.setState({
                    geospatial_data: geospatial_info.geospatial_data,
                    geospatial_form_url
                })
            }
        }
    }

    static getTitle = () => {
        return 'Enter geospatial information';
    }

    static isComplete = (state) => {
        return state.geospatial_info !== undefined &&
            state.geospatial_info !== null &&
            state.geospatial_info.geospatial_data !== null &&
            state.geospatial_info.geospatial_data.trim().length !== 0;
    }

    static getSummary = (project, index) => {
        return (
            <Card key={'module-' + index}
                  size="small"
                  title={'Geospatial Information'}
                  headStyle={{backgroundColor: 'rgb(216, 236, 243)'}}
                  style={{width: '100%', margin: index > 0 ? '20pt 0pt 0pt 0pt' : '0pt'}}>
		<div style={{ margin: '10pt 20pt 10pt 20pt'}}>
                    <div dangerouslySetInnerHTML={{
                        __html: (
                            project.geospatial_info === undefined ||
                            project.geospatial_info === null ||
                            JSON.parse(project.geospatial_info).geospatial_data === null ||
                            JSON.parse(project.geospatial_info).geospatial_data.trim().length === 0 ?
                                '<div style="padding: 10pt; color: brown;">No geospatial_data information available.</div>'
                                :
                                JSON.parse(project.geospatial_info).geospatial_data
                        )
                    }}>
                    </div>
                </div>
            </Card>
        )
    }

    reset = () => {
        this.setState({
            geospatial_data: null
        });
    }

    onChangeGeospatialData = (e) => {
        this.setState({
            geospatial_data: e.target.value,
        }, this.saveGeospatialInformation);
    }

    saveGeospatialInformation = () => {
        let obj = {
            geospatial_data: this.state.geospatial_data,
        }
        this.props.save_geospatial_info(obj);
    }

    reloadGeospatialFromSalesforce = () => {
        let theState = this;
        let info = Modal.info(
            {
                title: 'Refresh Geospatial Summary',
                content: ` Please wait for reloading the geospatial summary from Salesforce.`
            });
        axios({
            url: `/api/load_geospatial_from_salesforce/${this.props.project.project_number}/`,
            method: 'GET'
        }).then((response) => {
            theState.props.save_geospatial_info({
                geospatial_data: response.data.info
            });
            info.destroy();
            Modal.success(
                {
                    title: 'Refresh Done',
                    content: `Reloading the geospatial summary from Salesforce was completed.`
                });
        }).catch( (error) => {
            console.error(error) ;
        });
    }

    render() {
        return (
            <div style={root_style}>
                <Typography style={{padding: '10pt 10pt 0pt 10pt', width: '100%'}}>
                    This is the geospatial information you provided.
                    If you have any edits, click the Edit button below and
                    a new tab will open. You may be prompted to log in.
                    Make your changes in that tab, save them, then click Refresh to continue.
                </Typography>

                {/*
                <div style={{padding: '10pt 80pt 10pt 30pt'}}>
                    <TextArea rows={6}
                              value={this.state.geospatial_data}
                              onChange={this.onChangeGeospatialData}
                              allowClear/>
                </div>
                */}

                <div style={{
                    margin: '10pt 60pt 10pt 20pt',
                    padding: '10pt 80pt 30pt 30pt',
                    borderRadius: '25px',
                    border: '1px solid lightgray',
                    position: 'relative'
                }}

                >
                    <div dangerouslySetInnerHTML={{
                        __html: (
                            this.state.geospatial_data ?
                                this.state.geospatial_data :
                                '<div style="padding: 10pt; color: brown;">No geospatial information available.</div>')
                    }}>
                    </div>
                    <div style={{position: 'absolute', bottom:10, right:30}}>
                        <Button icon={<EditOutlined />}
                                onClick={() => window.open(
                                    this.state.geospatial_form_url, "_edit_case"
                                )}>
                            Edit
                        </Button>
                        <Button icon={<ReloadOutlined />}
                                style={{marginLeft: '6pt'}}
                                onClick={this.reloadGeospatialFromSalesforce}
                        >
                            Refresh
                        </Button>
                    </div>

                </div>

            </div>
        );
    }

}

export default GeospatialData;
