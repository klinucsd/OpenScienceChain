var ldap = require('ldapjs');
var assert = require('assert');

const server = "ad-onprem.s2.internal";
const userPrincipalName = "klin1@s2.internal";
const password = "sin(PI/2)=cos(0)";
const adSuffix = "dc=s2,dc=internal";

let format_date = (string) => {

    let year = string.substring(0,4);
    let month = string.substring(4,6);
    let day = string.substring(6, 8);
    let hour = string.substring(8, 10);
    let minute = string.substring(10, 12);
    let second = string.substring(12, 14);
    return year + "-" + month + "-" + day + "T" + hour + ":" + minute + ":" + second+"Z";
}

let check_users_from_ad = (User) => {

    var client = ldap.createClient({
        url: `ldap://${server}`
    });

    console.log(`create client: ldap://${server} `);

    client.bind(userPrincipalName, password, err => {
        //assert.ifError(err);
    });

    console.log('-----------------------------------------');
    console.log("ldap client bind done");

    const options = {
        scope: 'sub',
        //filter: `(userPrincipalName=${userPrincipalName})`
        paged: true,
        sizeLimit: 500,
        filter: "(objectClass=person)"
    }

    let all_users = [];

    let updateContact = (conn, email, mft, user) => {
        conn.query(
            `SELECT Id FROM Contact WHERE Email='${email}'`,
        ).then(
            function (result) {
                if (result.records.length === 1) {
                    let id = result.records[0].Id;
		    /*
		    console.log(`------------------------`);
                    console.log(`Found SalesForce Contact id: ${id} for email: ${email} ${JSON.stringify(user)}`);
		    console.log(`Update Salesforce: ${JSON.stringify({
                        Id: id,
                        RDS_Account_Status__c: "Active",
		        RDS_User_Role__c: user.ad_role,
			RDS_Account_Status__c: user.ad_status,
                        File_Transfer_Permission_Status__c: mft === true ? "File transfer permitted" : "File transfer not permitted",
			RDS_Username__c: user.user_name,
   			RDS_Account_Created_Date__c: user.whenCreated
                    }, null, 2)}`);
		    */
                    conn.sobject("Contact").update({
                        Id: id,
                        RDS_Account_Status__c: "Active",
		        RDS_User_Role__c: user.ad_role,
			RDS_Account_Status__c: user.ad_status,
                        File_Transfer_Permission_Status__c: mft === true ? "File transfer permitted" : "File transfer not permitted",
			RDS_Username__c: user.user_name,
   			RDS_Account_Created_Date__c: user.whenCreated
                    }, function (err, ret) {
                        if (err || !ret.success) {
                            return console.error(err, ret);
                        }
                        console.log('Updated Contact Successfully : ' + ret.id);
                    });
                }
            },
            function (err) {
                if (err) {
                    return console.error(err);
                }
            });
    }

    client.search(adSuffix, options, (err, res) => {

        //assert.ifError(err);

        res.on('searchEntry', entry => {

            if (entry.object.memberOf) {
                //console.log("---------------------");
                //console.log(`entry.object: ${JSON.stringify(entry.object, null, 2)} \nentry.object.memberOf: ${entry.object.memberOf} \nentry.object.dn: ${entry.object.dn}`);

                let found = false;
                let mft = false;
                let ad_role = null;
		let ad_status = 'Not Created';

		if (entry.object.dn) {
		    let dns = entry.object.dn.split(',');
		    for (var j=0; j<dns.length; j++) {
			//console.log("====> dn: " + dns[j]);
			if (dns[j] === 'OU=Limbo Accounts' ) {
			    ad_status = 'Disabled';
			} else if (dns[j] === 'OU=COH Accounts' && ad_status === 'Not Created') {
			    ad_status = 'Active';
			} 
		    }

		    //console.log("====>check dn: " + entry.object.dn);
		}

                if (entry.object.memberOf.length < 20) {
                    for (var i = 0; i < entry.object.memberOf.length; i++) {
                        let group = entry.object.memberOf[i];
                        //console.log(`group: ${group}`)
                        if (group.startsWith('CN=COH-')) {
                            found = true;
                            //break;
                        }
                        if (group.startsWith('CN=COH-MFT-PROD-GRP')) {
                            mft = true;
                        }
			if (group.startsWith('CN=COH-ANALYST-GRP')) {
                            ad_role = 'Analyst';
                        }
			if (group.startsWith('CN=COH-RESEARCHER-GRP')) {
                            ad_role = 'Researcher';
                        }
			if (group.startsWith('CN=COH-MANAGER-GRP')) {
                            ad_role = 'Manager';
                        }

                    }

                    if (found) {
                        //console.log("\n-----------------------------------");
                        //console.log(JSON.stringify(entry.object));
                    }
                } else {
                    //console.log("======== OOPS");
                }


                /*
                if (found) {
                  console.log("====================");
                  console.log("mail: " + entry.object.mail);
                  console.log("name: " + entry.object.userPrincipalName);
                  console.log("cn: " + entry.object.cn);
                  console.log("sn: " + entry.object.sn);
                  console.log("givenName: " + entry.object.givenName);
                }
                */


                if (found && entry.object.givenName) {

                    let person = {
                        //user_name: entry.object.userPrincipalName,
                        first_name: entry.object.givenName,
                        last_name: entry.object.sn,
                        email: entry.object.mail && entry.object.mail !== 'noemail_' ? entry.object.mail : entry.object.userPrincipalName,
                        role: 'user',
                        mft: mft,
			ad_role: ad_role,
			ad_status: ad_status,
                        user_name: entry.object.sAMAccountName,
                        whenCreated: format_date(entry.object.whenCreated),
                    };

                    /*
                     if (!person.email.endsWith('@s2.internal')) {
                         all_users.push(person);
                         //console.log(JSON.stringify(person));
                     }
                    */
                    all_users.push(person);
                }
            }
        });

        res.on('searchReference', referral => {
            console.log('referral: ' + referral.uris.join());
        });

        res.on('error', function (err) {
            console.log('ERROR 200: ' + err.message);
            client.unbind();
        });

        res.on('end', function (result) {
            //console.log('status: ' + result.status  );
            client.unbind();

            all_users.forEach(user => {
                //console.log(JSON.stringify(user, null, 2));

                let query = {
                    where: {
                        email: user.email,
                    }
                };
                User.findOne(query)
                    .then(user2 => {
                        console.log(`Found: ${user.email}`);
			if (!user.user_name.startsWith("testaccount")) {
                            user2.update(user)
                                .then(function (updated_user) {
                                     //console.log(`updated user ${JSON.stringify(updated_user, null, 2)}`);
                                });
			}
                    })
                    .catch(err => {
                        console.log(`Not Found: ${user.email}`);
			if (!user.user_name.startsWith("testaccount")) {
                            User.create(user);
                        }
                    });

            });

            try {
                var jsforce = require('jsforce');
                var conn = new jsforce.Connection({loginUrl: 'https://login.salesforce.com'});
                //conn.login('klin@cts.org.dev', 'ucsd92037ssQmwFlL0Oa4FOnF3o19a4Bj', function (err, userInfo) {
		//conn.login('klin@cts.org', 'lajolla92037YQmFkWX2uAobg77F9coCGYS5P', function (err, userInfo) {
		conn.login('ssapintegration@cts.org', 'geon20095co9fw5C0KBjbyNXqZJGpFMi', function (err, userInfo) {
                    if (err) {
                        return console.error(err);
                    }
                    all_users.forEach(user => {
                        try {
			    if (!user.user_name.startsWith("testaccount")) {
                                updateContact(conn, user.email, user.mft, user);
                            }
                        } catch (ee) {
                            console.error(ee);
                        }
                    });
                });
            } catch (e) {
                console.error(e);
            }

        });

    });

    client.unbind(err => {
        //assert.ifError(err);
    });


}

module.exports = check_users_from_ad;