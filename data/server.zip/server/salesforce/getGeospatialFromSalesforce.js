

let getGeospatialFromSalesforce = (project_number, response) => {
    try {
        var jsforce = require('jsforce');
        var conn = new jsforce.Connection({loginUrl: 'https://login.salesforce.com'});
        //conn.login('klin@cts.org.dev', 'ucsd92037ssQmwFlL0Oa4FOnF3o19a4Bj', function (err, userInfo) {
	//conn.login('klin@cts.org', 'lajolla92037YQmFkWX2uAobg77F9coCGYS5P', function (err, userInfo) {
 	conn.login('ssapintegration@cts.org', 'geon20095co9fw5C0KBjbyNXqZJGpFMi', function (err, userInfo) {
            if (err) {
                return console.error(err);
            }
            conn.query(
		/*
                `
                SELECT Id,
                        Analysis_Abbreviation__c,
                        Analysis_Name__c,
                        Analysis_Number__c,
                        RecordTypeId,  
                        Biospecimen_Form_URL__c,
                        Geospatial_Form_URL__c,
                        Biospecimen_Summary__c,
                        Data_Sharing_Summary__c,
                        Geospatial_Summary__c
                   FROM Case
                  WHERE RecordTypeId = '012q00000001qe0AAA'      
                `
		*/
		`
                SELECT Id,
                        Analysis_Abbreviation__c,
                        Analysis_Name__c,
                        Analysis_Number__c,
                        RecordTypeId,  
                        Biospecimen_Form_URL__c,
                        Geospatial_Form_URL__c,
                        Biospecimen_Summary__c,
                        Data_Sharing_Summary__c,
                        Geospatial_Summary__c
                   FROM Case
                  WHERE RecordTypeId = '012q00000001qe0AAA'      
                `
            ).then(ssap_cases => {
                ssap_cases.records.map((ssap_case, i) => {
                    if (Number(ssap_case.Analysis_Number__c) === Number(project_number)) {
                        response.json({info: ssap_case.Geospatial_Summary__c});
                    }
                });
            }).catch(error => {
                console.log(JSON.stringify(error));
            });
        });
    } catch (e) {
        console.log(e);
    }

}

module.exports = getGeospatialFromSalesforce;