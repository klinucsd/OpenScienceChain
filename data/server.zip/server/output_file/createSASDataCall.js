
const fs = require('fs');
const path = require('path');
const sas_data_call_template = '/OutputData/Code/Internal/Template\ -\ SAS\ Data\ Call.sas';
const alt_sas_data_call_template = '/OutputData/Code/Internal/Template\ -\ Alternate\ SAS\ Data\ Call.sas';

function createSASDataCall(project, dir, filename, shared_dir) {

    let template = null;
    if (project.study_design === 'Cohort' && project.endpoint === 'Cancer') {
	template = sas_data_call_template;
    } else {
	template = alt_sas_data_call_template;
    }

    let data = fs.readFileSync(template, 'UTF-8');
    data = data.replace(
        '${FILE PATH\\ASSIGN DATA TYPE FILE NAME.sas}',
        `${dir.replace(/\//g, '\\').replace('\\OutputData', 'O:')}\\${filename}_assign_data_type_code.sas`);

    var sasOutputFile = fs.createWriteStream(`${shared_dir}/${filename}_SAS_data_call.sas`);
    sasOutputFile.write(data);
    sasOutputFile.end();

}

module.exports = createSASDataCall;


