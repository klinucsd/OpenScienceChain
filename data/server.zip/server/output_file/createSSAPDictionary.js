const fs = require('fs');
const parse = require('csv-parse');
const path = require('path');
const {Parser} = require('json2csv');
const sas_data_type_format = '/OutputData/Code/Internal/MASTER\ SSAP\ Dictionary\ for\ users\ 08282020.csv';

const convertCsvToXlsx = require('@aternus/csv-to-xlsx');

function createSSAPDictionary(project, final_columns, dir, filename, shared_dir) {

    //console.log(`createSSAPDictionary start`);

    fs.readFile(sas_data_type_format, function (err, fileData) {
        parse(fileData, {columns: true, trim: true}, function(err, rows) {

            //console.log(`--------------------------------`);
            //console.log(JSON.stringify(rows, null, 2));
	    //console.log(`--------------------------------`);
	    //console.log(`createSSAPDictionary final_columns: ${JSON.stringify(final_columns)}`);

            var csvFile = fs.createWriteStream(`${shared_dir}/${filename}_dictionary.csv`);
            const json2csv = new Parser();

            let first = true;
            for (var i=0; i<rows.length; i++) {
                if (final_columns.includes(rows[i]["Variable name"]) || rows[i]["Variable name"] === 'participant_key') {
                    let csv = json2csv.parse(rows[i]);
		    //console.log(`createSSAPDictionary csv: ${csv}`);

                    if (!first) {
                        let csv_array = csv.split('\n');
                        for (var j=1; j<csv_array.length; j++) {
                            csvFile.write(csv_array[j] + '\n');
                        }
                        //csv = csv.split('\n')[1];
                    } else {
                        csvFile.write(csv + '\n');
			first = false;
                    }

                    //csvFile.write(csv + '\n');
                }
            }

            csvFile.on('finish', () => {
                try {
                    convertCsvToXlsx(`${shared_dir}/${filename}_dictionary.csv`,
                        `${shared_dir}/${filename}_dictionary.xlsx`);
                    fs.unlinkSync(`${shared_dir}/${filename}_dictionary.csv`);
                } catch (e) {
                }
            });
            csvFile.end();


        })
    })
}

module.exports = createSSAPDictionary;




