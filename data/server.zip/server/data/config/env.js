
const env = {
    DATABASE_DIALECT: 'sqlite',
    DATABASE_STORAGE: './cts.sqlite'
}

module.exports = env;